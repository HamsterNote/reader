// Public headless schema3 API. Historical math remains private and independently tested.
export * from '../model/document';
export * from '../model/documentReader';
export * from './layeredEditorController';
export * from './layeredInputMode';
export * from './freehandSession';
export * from './layeredToolSession';
export * from './layeredTextEditSession';
export * from './layeredObjectQuery';
export * from '../geometry/freehand';
export * from '../geometry/freehandCache';
export * from '../geometry/affine';
export * from '../geometry/shape';
export * from '../geometry/worldBounds';
export * from '../viewport';

export { migrateLegacyDocument } from '../model/legacyDocumentMigration';
export * from '../geometry/pageCoordinates';
