export * from './freehandWebAdapter';
