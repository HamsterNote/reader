import type { DrawingPoint, DrawingStroke } from './model/geometryTypes';
import type { SelectionBox } from './utils';
export type RotationCenter = Readonly<Pick<DrawingPoint, 'x' | 'y'>>;
export type SelectionFrame = {
    readonly center: DrawingPoint;
    readonly width: number;
    readonly height: number;
    readonly rotationRad: number;
};
export declare function rotatePointAroundCenter(point: DrawingPoint, center: RotationCenter, rotationRad: number): DrawingPoint;
export declare function rotateStrokeAroundSelection(stroke: DrawingStroke, center: RotationCenter, rotationRad: number): DrawingStroke;
export declare function selectionFrameFromBox(box: SelectionBox): SelectionFrame;
export declare function selectionFrameFromLocalBox(box: SelectionBox, orientation: Readonly<Pick<SelectionFrame, 'center' | 'rotationRad'>>): SelectionFrame;
export declare function selectionFrameLocalBox(frame: SelectionFrame): SelectionBox;
export declare function isPointInsideSelectionFrame(point: DrawingPoint, frame: SelectionFrame): boolean;
export declare function selectionFrameBoundingBox(frame: SelectionFrame): SelectionBox;
//# sourceMappingURL=selectionRotation.d.ts.map