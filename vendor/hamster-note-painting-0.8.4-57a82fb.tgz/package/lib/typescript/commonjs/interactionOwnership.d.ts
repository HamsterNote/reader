import { type DrawingSurfaceVirtualPaperInteraction } from './virtualPaperOptions';
export type InteractionOwner = 'ruler' | 'virtual-paper' | 'drawing' | 'none';
export type InteractionInputMethod = 'touch' | 'mouse' | 'pen';
export type PointerInteractionInput = {
    readonly kind: 'pointer';
    readonly target: EventTarget | null;
    /** Pointer coordinates hit the screen-space ruler, even when its visual overlay is pointer-inert. */
    readonly hitsRuler?: boolean;
    readonly pointerType?: string;
    readonly button?: number;
    readonly ctrlKey?: boolean;
    readonly metaKey?: boolean;
    readonly altKey?: boolean;
    readonly pointerId?: number;
};
export type WheelInteractionInput = {
    readonly kind: 'wheel';
    readonly target: EventTarget | null;
    readonly ctrlKey?: boolean;
    readonly metaKey?: boolean;
};
export type InteractionInput = PointerInteractionInput | WheelInteractionInput;
export type PointerInteractionEvent = Event & {
    readonly clientX: number;
    readonly clientY: number;
    readonly pointerType?: string;
    readonly button?: number;
    readonly ctrlKey?: boolean;
    readonly metaKey?: boolean;
    readonly altKey?: boolean;
    readonly pointerId?: number;
};
export type ClassifyInteractionOptions = {
    readonly input: InteractionInput;
    readonly isDrawingEnabled: boolean;
    readonly isRulerEnabled: boolean;
    readonly virtualPaperEnabled: boolean;
    readonly allowedDrawingInputMethods: readonly InteractionInputMethod[];
    readonly virtualPaperInteractions?: readonly DrawingSurfaceVirtualPaperInteraction[];
    readonly activeTouchPointers?: number;
};
export declare function buildPointerInteractionInput(event: PointerInteractionEvent, buttonOverride?: number): PointerInteractionInput;
export declare function classifyInteraction(options: ClassifyInteractionOptions): InteractionOwner;
export type GestureOwner = {
    readonly startPointer: (options: ClassifyInteractionOptions) => InteractionOwner;
    readonly getPointerOwner: (pointerId: number) => InteractionOwner;
    readonly endPointer: (pointerId: number) => InteractionOwner;
    readonly reset: () => void;
};
export declare function createGestureOwner(): GestureOwner;
export declare function getResolvedVirtualPaperInteractions(interactions: readonly DrawingSurfaceVirtualPaperInteraction[] | undefined): readonly DrawingSurfaceVirtualPaperInteraction[];
export declare function isSafeInteractiveTarget(target: EventTarget | null): boolean;
//# sourceMappingURL=interactionOwnership.d.ts.map