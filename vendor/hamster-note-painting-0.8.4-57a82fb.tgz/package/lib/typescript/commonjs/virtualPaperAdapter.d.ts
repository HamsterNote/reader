import type { DrawingSurfaceVirtualPaperOptions } from './virtualPaperOptions';
export declare function isVirtualPaperEnabled(virtualPaper?: boolean | DrawingSurfaceVirtualPaperOptions): boolean;
//# sourceMappingURL=virtualPaperAdapter.d.ts.map