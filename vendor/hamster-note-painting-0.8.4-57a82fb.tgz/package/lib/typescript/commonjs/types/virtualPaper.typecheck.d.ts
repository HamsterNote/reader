import { type DrawingSurfaceProps } from '../index';
export declare const virtualPaperPublicApiTypecheck: DrawingSurfaceProps[];
//# sourceMappingURL=virtualPaper.typecheck.d.ts.map