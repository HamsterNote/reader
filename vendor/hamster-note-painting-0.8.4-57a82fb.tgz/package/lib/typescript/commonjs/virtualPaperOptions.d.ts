export type DrawingSurfaceVirtualPaperInteraction = 'mouseWheelZoom' | 'mouseDragPan' | 'trackpadScrollPan' | 'mouseWheelCtrlZoom' | 'touchSingleFingerPan' | 'touchTwoFingerPan' | 'touchTwoFingerZoom' | 'penPan';
export type DrawingSurfaceVirtualPaperOptions = {
    readonly enabled?: boolean;
    readonly initialPlacement?: 'top-left' | 'top-center' | 'center';
    readonly minScale?: number;
    readonly maxScale?: number;
    readonly enabledInteractions?: readonly DrawingSurfaceVirtualPaperInteraction[];
};
export declare const SAFE_DEFAULT_VIRTUAL_PAPER_INTERACTIONS: readonly ["trackpadScrollPan", "mouseWheelCtrlZoom", "touchSingleFingerPan", "touchTwoFingerZoom"];
//# sourceMappingURL=virtualPaperOptions.d.ts.map