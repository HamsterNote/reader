import { type EditorDocument } from './document';
import { type DocumentReadResult } from './documentReader';
/**
 * Explicit, all-or-nothing upgrade of DrawingValue/schema 1 or 2 to schema 3.
 * No IO, source mutation, generated random IDs, silent filtering or downgrade.
 * Schema 3 is accepted too, so retrying a completed upgrade is value-idempotent.
 * Legacy pen samples use the current freehand geometry (not the retired SVG renderer).
 */
export declare function migrateLegacyDocument(input: unknown): DocumentReadResult<EditorDocument>;
//# sourceMappingURL=legacyDocumentMigration.d.ts.map