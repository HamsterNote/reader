export declare const DEFAULT_TEXT_FONT_SIZE = 24;
export declare const DEFAULT_TEXT_BOX_WIDTH = 160;
export declare const MIN_TEXT_BOX_WIDTH = 24;
export declare const TEXT_LINE_HEIGHT = 1.2;
export type TextBoxPoint = Readonly<{
    x: number;
    y: number;
}>;
export type TextBox = Readonly<{
    x: number;
    y: number;
    width: number;
    height: number;
}>;
export declare function resolveTextFontSize(fontSize: number | undefined): number;
export declare function textBoxFromPoints(points: readonly TextBoxPoint[]): TextBox | null;
export declare function createTextBoxPoints(origin: TextBoxPoint, fontSize: number): [TextBoxPoint, TextBoxPoint];
export declare function resolveTextBoxHeight(text: string, fontSize: number, width: number, measuredHeight?: number): number;
export declare function resizeTextBoxHeight(points: readonly TextBoxPoint[], height: number): TextBoxPoint[];
//# sourceMappingURL=text.d.ts.map