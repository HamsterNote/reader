/**
 * schemaVersion 3 分层编辑器文档的只读 reader 与 JSON 序列化/反序列化。
 *
 * 职责边界：
 * - 只依赖 model/document.ts 的冻结类型与常量；不 import PF / DOM / Skia / V2 / controller。
 * - 只做白名单深拷贝：仅复制契约内的持久字段，剥除预测点、插值、outline、strokePoints、
 *   cache、session、dashPen、pressureMultiplier 等未知/派生字段。
 * - 只接受 schemaVersion 3；不提供 schema migration、旧 schema fallback、磁盘 IO 或导出。
 * - 输入对象永不被改写；拷贝结果递归冻结。
 * - 失败以 Result 返回（不抛业务异常），路径指向首个非法字段。
 *
 * 注意：documentRevision 只是文档单调修订号，reader 不据此推断“undo 可回退到底”，
 * 也不向 controller 暗示任何历史可逆性；它仅做非负安全整数校验后原样保存。
 */
import { type EditorDocument } from './document';
/** reader 失败原因：JSON 文本本身非法，或结构不符合 schema3 契约。 */
export type DocumentReadError = Readonly<{
    code: 'invalid-json' | 'invalid-document';
    /** 首个非法位置的路径，例如 `$.objects[0].transform.a`。 */
    path: string;
}>;
/** reader 结果：成功携带冻结文档，失败携带错误原因。 */
export type DocumentReadResult<T> = Readonly<{
    ok: true;
    value: T;
}> | Readonly<{
    ok: false;
    error: DocumentReadError;
}>;
/**
 * 从内存值读取 schema3 文档。
 * 成功返回白名单深拷贝并递归冻结的文档；失败返回首个非法路径，不抛业务异常。
 */
export declare function readLayeredDocument(value: unknown): DocumentReadResult<EditorDocument>;
/**
 * 从 JSON 文本解析 schema3 文档。
 * 非字符串或 JSON.parse 失败返回 invalid-json（不抛出）；结构非法返回 invalid-document。
 */
export declare function parseLayeredDocument(json: string): DocumentReadResult<EditorDocument>;
/**
 * 序列化任意值为 schema3 文档 JSON。
 * 先经 read 白名单拷贝校验（剥除 extras），再对冻结副本 JSON.stringify；
 * 绝不直接序列化 caller 原值。失败返回对应 Result。
 */
export declare function serializeLayeredDocument(value: unknown): DocumentReadResult<string>;
//# sourceMappingURL=documentReader.d.ts.map