import { type DrawingStrokeV2, type DrawingValueV2 } from './strokes';
type ValueLike = {
    readonly strokes?: readonly unknown[];
};
type NormalizedDrawingValue<T extends object> = Omit<T, 'schemaVersion' | 'strokes'> & DrawingValueV2;
export declare function migrateStroke(stroke: unknown): DrawingStrokeV2 | null;
export declare function normalizeDrawingValue(value: null | undefined): DrawingValueV2;
export declare function normalizeDrawingValue<T extends ValueLike & object>(value: T): NormalizedDrawingValue<T>;
export {};
//# sourceMappingURL=strokeMigration.d.ts.map