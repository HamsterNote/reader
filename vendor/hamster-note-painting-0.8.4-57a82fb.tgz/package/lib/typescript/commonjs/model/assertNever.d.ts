export declare function assertNever(x: never): never;
//# sourceMappingURL=assertNever.d.ts.map