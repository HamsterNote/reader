export declare const DRAWING_STROKE_SCHEMA_VERSION: 2;
export type DrawingPointV2 = {
    x: number;
    y: number;
    pressure?: number;
};
export type DrawingStrokeToolV2 = 'pen' | 'line' | 'rect' | 'ellipse' | 'polygon' | 'bezier' | 'text' | 'image';
/** 连续指针交互使用的工具模式；图片通过一次性导入动作创建。 */
export type DrawingToolModeV2 = Exclude<DrawingStrokeToolV2, 'image'> | 'eraser' | 'lasso';
type DrawingStrokeBaseV2<Tool extends DrawingStrokeToolV2> = {
    schemaVersion: typeof DRAWING_STROKE_SCHEMA_VERSION;
    id: string;
    tool: Tool;
    points: DrawingPointV2[];
    strokeColor?: string;
    strokeWidth?: number;
    dashArray?: number[];
    dashOffset?: number;
    fillColor?: string;
    fillOpacity?: number;
    rotationRad?: number;
};
export type PenStrokeV2 = DrawingStrokeBaseV2<'pen'>;
export type LineStrokeV2 = DrawingStrokeBaseV2<'line'>;
export type RectStrokeV2 = DrawingStrokeBaseV2<'rect'>;
export type EllipseStrokeV2 = DrawingStrokeBaseV2<'ellipse'>;
export type PolygonStrokeV2 = DrawingStrokeBaseV2<'polygon'>;
export type BezierStrokeV2 = DrawingStrokeBaseV2<'bezier'>;
export type TextStrokeV2 = DrawingStrokeBaseV2<'text'> & {
    text: string;
    fontSize: number;
};
export type ImageStrokeV2 = DrawingStrokeBaseV2<'image'> & {
    /** 可选的宿主资源表标识；旧文档仍仅使用必填的 src。 */
    resourceId?: string;
    src: string;
};
export type DrawingStrokeV2 = PenStrokeV2 | LineStrokeV2 | RectStrokeV2 | EllipseStrokeV2 | PolygonStrokeV2 | BezierStrokeV2 | TextStrokeV2 | ImageStrokeV2;
export type DrawingValueV2 = {
    schemaVersion: typeof DRAWING_STROKE_SCHEMA_VERSION;
    strokes: DrawingStrokeV2[];
};
export {};
//# sourceMappingURL=strokes.d.ts.map