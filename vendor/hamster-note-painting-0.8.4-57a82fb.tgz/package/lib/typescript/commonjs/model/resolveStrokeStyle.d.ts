export type StrokeStyleFields = {
    strokeColor?: string;
    strokeWidth?: number;
    dashArray?: number[];
    dashOffset?: number;
    fillColor?: string;
    fillOpacity?: number;
};
export type ResolveStrokeStyleOptions = {
    isClosedShape?: boolean;
    fallbackColor: string;
    fallbackWidth: number;
};
export type ResolvedStrokeStyle = {
    stroke?: string;
    strokeWidth?: number;
    strokeDasharray?: string;
    strokeDashoffset?: number;
    fill: string;
    fillOpacity?: number;
};
export declare function resolveStrokeStyle(style: StrokeStyleFields, options: ResolveStrokeStyleOptions): ResolvedStrokeStyle;
//# sourceMappingURL=resolveStrokeStyle.d.ts.map