import type { DrawingPoint } from '../model/geometryTypes';
import type { DrawingViewport } from '../viewport';
export type FitImageIntoViewportOptions = {
    readonly naturalWidth: number;
    readonly naturalHeight: number;
    readonly containerWidth: number;
    readonly containerHeight: number;
    readonly viewport: DrawingViewport;
};
/**
 * 按图片固有宽高比放入当前可见区域中央。
 * 尺寸约束在屏幕坐标中计算，确保缩放画布后仍以容器的一半为上限。
 */
export declare function fitImageIntoViewport({ naturalWidth, naturalHeight, containerWidth, containerHeight, viewport, }: FitImageIntoViewportOptions): [DrawingPoint, DrawingPoint];
//# sourceMappingURL=image.d.ts.map