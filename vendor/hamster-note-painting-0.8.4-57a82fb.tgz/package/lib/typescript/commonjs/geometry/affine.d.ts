/**
 * 纯仿射几何 helper（Task 5.2 基础）
 *
 * 只依赖 `model/document.ts` 的 `AffineTransform` / `Point` / `Bounds` 类型契约：
 * - 屏幕空间约定：x' = a*x + c*y + tx，y' = b*x + d*y + ty。
 * - 每个函数运行时安全：非法 / 缺失 / 非有限输入一律返回 `null`，**不 throw**。
 * - 变换六分量必须有限且行列式有限非 0；正负镜像（det<0）允许；不引入任意 epsilon / clamp。
 * - 常量时间直接算术，无 DOM / PF / V2 / Skia import。
 */
import type { AffineTransform, Bounds, Point } from '../model/document';
/** 应用仿射到点；变换/点非法或结果非有限返回 `null`。 */
export declare function applyAffine(transform: AffineTransform, point: Point): Point | null;
/**
 * 复合仿射 `parent ∘ child`（先应用 child 再应用 parent）。
 * 任一变换非法、输出分量非有限、或输出行列式非有限非 0 时返回 `null`。
 */
export declare function composeAffine(parent: AffineTransform, child: AffineTransform): AffineTransform | null;
/**
 * 求逆仿射。变换非法、行列式为 0、逆分量非有限或逆行列式非有限非 0 时返回 `null`
 * （极小/极大数值导致的非有限结果也失败，不做 clamp）。
 */
export declare function invertAffine(transform: AffineTransform): AffineTransform | null;
/**
 * 变换 bounds 得到**保守 AABB**：变换四角后取包围盒（不是 ellipse/cubic 精确 bounds）。
 * bounds 四分量必须有限且有序（允许 zero-area）；任一变换后角点非有限返回 `null`。
 */
export declare function transformBounds(transform: AffineTransform, bounds: Bounds): Bounds | null;
//# sourceMappingURL=affine.d.ts.map