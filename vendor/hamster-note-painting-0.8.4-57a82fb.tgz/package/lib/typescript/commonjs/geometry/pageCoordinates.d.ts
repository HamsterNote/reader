import type { AffineTransform, Point } from '../model/document';
/** Stable page DIP dimensions; transform maps page DIP to overlay-local CSS pixels. */
export type PageGeometry = Readonly<{
    width: number;
    height: number;
    pageToSurface: AffineTransform;
}>;
export type PageCoordinateSpace = Readonly<{
    pageToSurface: AffineTransform;
    surfaceToPage: AffineTransform;
    toSurface(point: Point): Point | null;
    toPage(point: Point): Point | null;
}>;
export type PageViewportTransform = readonly [number, number, number, number, number, number];
/** pdf.js-compatible transforms. The reference is the viewport used by saved coordinates. */
export declare function createPageGeometry(options: {
    width: number;
    height: number;
    viewportTransform: PageViewportTransform;
    referenceTransform: PageViewportTransform;
}): PageGeometry | null;
/** Invalid/singular/overflowing geometry is rejected; no clamping or identity fallback. */
export declare function createPageCoordinateSpace(geometry: PageGeometry): PageCoordinateSpace | null;
/** Snapshot per input batch; callers read current page container bounds (scroll-safe). */
export type ClientToLocal = (point: Point) => Point | null;
export type GetClientToLocal = () => ClientToLocal;
//# sourceMappingURL=pageCoordinates.d.ts.map