/**
 * 世界坐标 bounds 派生（Task 5.2 基础）
 *
 * 纯派生：把 `DocumentObject` 的 local 几何经对象 transform 映射到世界坐标，产出
 * `worldBounds`（精确几何 AABB）与 `visualWorldBounds`（含描边宽度的保守包络）。
 * - 无新 cache / docstore，不修改 caller；不依赖 V2 / DOM / Skia。
 * - 复用共享 `geometry/affine.ts`、`geometry/shape.ts`、`geometry/freehandCache.ts`。
 * - 非 query、非完整 5.2：仅提供 broadphase 世界 bounds。
 */
import type { Bounds, DocumentObject } from '../model/document';
import type { FreehandGeometryCache } from './freehandCache';
/** 世界坐标 bounds 结果：精确几何 bounds 与保守视觉 bounds。 */
export type LayeredWorldBounds = Readonly<{
    worldBounds: Bounds;
    visualWorldBounds: Bounds;
}>;
/**
 * 派生对象的世界坐标 bounds。
 *
 * - 运行时校验已知 kind、finite nonsingular transform；不支持/非法/溢出返回 null。
 * - freehand 复用 `cache.getPresentation(...,'final')` 的实际 transformedPolygon worldBounds；
 *   geometry 与 visual 同为 filled bounds（轮廓已含宽度）。
 * - image/text 用 localBounds 四角精确变换，视觉同几何。
 * - shape 几何 bounds 精确；visual 在几何外按 `halfWidth * 最大奇异值` 保守外扩
 *   （round join/cap 包络，仅 broadphase，不宣称 dash 细判）。
 * - 输出深冻结，不修改 caller。
 */
export declare function deriveLayeredWorldBounds(object: DocumentObject, freehandCache: FreehandGeometryCache): LayeredWorldBounds | null;
//# sourceMappingURL=worldBounds.d.ts.map