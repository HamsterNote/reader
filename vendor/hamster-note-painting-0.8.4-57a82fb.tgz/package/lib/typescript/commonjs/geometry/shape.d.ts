/**
 * 形状几何派生（Task 5.1 基础）
 *
 * 只依赖 `model/document.ts` 的 `ShapeObject` / `ShapeStyle` / `ShapeType` / `Bounds` / `Point`
 * 类型契约；无 DOM / PF / V2 / Skia import，不依赖 controller。
 *
 * - 输出为直接 M/L/C/E/Z 命令（单一实现，无自主平滑/圆整）；不 begin/fill/stroke（渲染调用方负责）。
 * - 仅 local 几何，不 apply 对象 transform。
 * - 任何运行时非法 / 缺失 / 非有限 / 不支持 / 派生溢出输入返回 `null`，不 mutation、不 throw。
 * - 所有输出深冻结。
 */
import type { Bounds, ShapeObject } from '../model/document';
/** 形状 path 命令；ellipse 为完整 2π 椭圆（Canvas 语义），SVG 序列化时展开为两段圆弧。 */
export type ShapeCommand = Readonly<{
    type: 'moveTo';
    x: number;
    y: number;
}> | Readonly<{
    type: 'lineTo';
    x: number;
    y: number;
}> | Readonly<{
    type: 'bezierCurveTo';
    cp1x: number;
    cp1y: number;
    cp2x: number;
    cp2y: number;
    x: number;
    y: number;
}> | Readonly<{
    type: 'ellipse';
    cx: number;
    cy: number;
    rx: number;
    ry: number;
}> | Readonly<{
    type: 'closePath';
}>;
/**
 * 结构化回放目标：Canvas2D context 与 `Path2D` 都可满足（**无 beginPath**）。
 * 与 `geometry/closedPath.ts` 的 `ClosedPathTarget` 同风格，回放不负责重置路径。
 */
export interface ShapePathTarget {
    moveTo(x: number, y: number): void;
    lineTo(x: number, y: number): void;
    bezierCurveTo(cp1x: number, cp1y: number, cp2x: number, cp2y: number, x: number, y: number): void;
    ellipse(x: number, y: number, rx: number, ry: number, rotation: number, startAngle: number, endAngle: number, anticlockwise?: boolean): void;
    closePath(): void;
}
/** 派生形状几何：local 命令与 bounds。 */
export type DerivedShapeGeometry = Readonly<{
    commands: readonly ShapeCommand[];
    localBounds: Bounds;
    visualLocalBounds: Bounds;
}>;
/**
 * 派生形状几何：命令 + local bounds + 保守视觉 bounds（width/2 外扩）。
 * 运行时非法 / 缺失 / 非有限 / 不支持类型 / 派生溢出返回 null；不 mutation。
 */
export declare function deriveShapeGeometry(shape: ShapeObject): DerivedShapeGeometry | null;
/**
 * 序列化命令为 SVG path `d`。
 *
 * - 与 Canvas replay 共享同一命令序列（M/L/C/E/Z）。
 * - `ellipse` 只输出两段 large-arc 圆弧（**不额外 M/Z**；周边 moveTo/closePath 命令已提供），
 *   sweep=1 对应 Canvas `ellipse(...,0,2π,false)` 的顺时针方向，避免与 dash 方向不一致。
 * - 假定输入为 known valid commands（内部派生消费者，非 arbitrary parser）。
 */
export declare function shapeCommandsToSvgPath(commands: readonly ShapeCommand[]): string;
/**
 * 回放命令到结构化 target（Canvas2D context / `Path2D`）。
 *
 * - **不调用 `beginPath`**，也不 fill/stroke（渲染调用方负责）。
 * - `ellipse` 命令一命令一语义：只调用 target.ellipse(...,0,2π,false)，
 *   不自主 moveTo/closePath（序列中已有单独命令提供）。
 */
export declare function replayShapeCommands(target: ShapePathTarget, commands: readonly ShapeCommand[]): void;
//# sourceMappingURL=shape.d.ts.map