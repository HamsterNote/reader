/**
 * 自由笔几何派生（Task 2.4）。
 *
 * 设计约束（design.md 决策 3 / spec freehand-geometry-pressure）：
 * - 本模块是纯几何：只依赖冻结的 `model/document.ts` 契约与 `perfect-freehand`；
 *   不依赖 controller、DOM、Canvas、Skia 或 legacy。
 * - PF 生成的内部合成点、轮廓点只属于派生几何，**绝不写回 object**；本模块不修改入参。
 * - real 使用真实压力；simulated 与 constant 的派生压力固定 0.5，避免 mouse/pen 原值影响
 *   PF 模拟 seed / 宽度；模式在 begin 锁定，不由 `p > 0` 或变化率推断。
 * - release 收尾：up 阶段压力 0 使用之前最后有效接触压力，普通 down/move 的 0 保留。
 * - 本轮不做几何缓存（2.6 后续）；revision 仅用于未来失效，不作为持久事实。
 */
import type { Bounds, FreehandObject, Point } from '../model/document';
import { type ClosedPathCommand } from './closedPath';
/**
 * 几何算法 + preset revision。
 * 包含精确 PF 版本，避免库更新后缓存/数据未失效。
 */
export declare const FREEHAND_ALGORITHM_REVISION: "pf@1.2.3:preset1";
/** active / final 两种派生状态；final 采用结束收尾。 */
export type FreehandGeometryState = 'active' | 'final';
/** 派生几何输出；全部只读且已冻结。 */
export type DerivedFreehandGeometry = Readonly<{
    polygon: readonly Point[];
    commands: readonly ClosedPathCommand[];
    localBounds: Bounds;
    geometryRevision: string;
}>;
/** PF 显式派生输入：坐标 + 数值压力（缺失/越界已在本模块归一化）。 */
export type PressureSample = Readonly<{
    x: number;
    y: number;
    pressure: number;
}>;
/**
 * 只读派生 PF 输入（显式 xy + 数值 pressure）。
 *
 * - real：真实压力 + release 收尾规则。
 * - simulated / constant：全部固定 0.5，与输入压力无关。
 *
 * 原始 `object.samples` 不被修改；越界/缺失只在派生视图归一化。
 */
export declare function derivePressureSamples(object: FreehandObject): readonly PressureSample[];
/**
 * 派生自由笔几何（active 或 final）。
 *
 * - 只读：不修改 object / samples / brush，不写入插值、预测点或 PF 内部点。
 * - 空 samples 或 size<=0 → 空 polygon/commands + 退化 bounds。
 * - 返回对象深冻结；每点/每条命令冻结以便安全比较与缓存。
 */
export declare function deriveFreehandGeometry(object: FreehandObject, state: FreehandGeometryState): DerivedFreehandGeometry;
//# sourceMappingURL=freehand.d.ts.map