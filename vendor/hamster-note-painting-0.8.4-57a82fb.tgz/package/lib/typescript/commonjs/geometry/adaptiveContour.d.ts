/**
 * 自适应轮廓扁平化（Task 5.2 后续基础）
 *
 * 把 cubic / ellipse 的 local 参数曲线按世界空间误差预算切成折线，输出**平行的**
 * `localPoints` 与 `worldPoints`（同一索引对应同一点）及固定 `maxDeviation` 上界。
 *
 * - 只依赖 `model/document.ts` 类型与共享 `geometry/affine.ts`（applyAffine）；
 *   无 DOM / V2 / PF / polygonBoolean / store / cache。
 * - 固定内部目标 MAX_WORLD_DEVIATION = 0.125 DIP（为中心线 + 帽误差合计 <= 0.25 预留预算），
 *   无 public options；最多 65536 段、最大 depth 32。
 * - 非法输入 invalid-input；finite 输入但变换/中间算术非有限 geometry-failed；
 *   深度/段数耗尽 budget-exceeded。整体失败绝不 partial。
 * - `maxDeviation` 返回固定上限，不宣称真正测得误差。
 */
import type { AffineTransform, Point } from '../model/document';
/** 扁平化错误码。 */
export type AdaptiveContourErrorCode = 'invalid-input' | 'geometry-failed' | 'budget-exceeded';
/** 统一 Result；value/error 只读。 */
export type AdaptiveContourResult<T> = Readonly<{
    ok: true;
    value: T;
}> | Readonly<{
    ok: false;
    error: Readonly<{
        code: AdaptiveContourErrorCode;
    }>;
}>;
/** 自适应轮廓：平行 local/world 点序列与固定误差上界。 */
export type AdaptiveContour = Readonly<{
    localPoints: readonly Point[];
    worldPoints: readonly Point[];
    maxDeviation: number;
}>;
/**
 * 扁平化带 transform 的 cubic：四 local 控制点 `[P0, C1, C2, P3]`。
 *
 * 世界 de Casteljau 递归细分并同步 local 分割；对 **world 弦段** 距离 <= 0.125 才接受
 * （P0=P3 / 共线但 CP 越出端点不会假直线）。
 */
export declare function flattenLayeredCubic(points: readonly Point[], transform: AffineTransform): AdaptiveContourResult<AdaptiveContour>;
/**
 * 扁平化带 transform 的椭圆弧。
 *
 * - `rx/ry >= 0` 允许退化；signed span `|endAngle-startAngle| <= 2π`，零 span 合法为单点。
 * - 世界点由 local 点经 `applyAffine` 得到，保持 local/world 一一对应。
 * - full arc 先分四象限确保起终相同不误判；signed span 顺序与 Canvas 一致。
 */
export declare function flattenLayeredEllipse(center: Point, rx: number, ry: number, transform: AffineTransform, startAngle: number, endAngle: number): AdaptiveContourResult<AdaptiveContour>;
//# sourceMappingURL=adaptiveContour.d.ts.map