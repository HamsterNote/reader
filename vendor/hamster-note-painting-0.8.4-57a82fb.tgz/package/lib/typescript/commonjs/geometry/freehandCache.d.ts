/**
 * 自由笔几何 / 呈现缓存（Task 2.6）。
 *
 * 设计约束（design.md 决策 3 / spec freehand-geometry-pressure）：
 * - **headless 且 instance-scoped**：本模块只依赖冻结的 `model/document.ts` 契约与
 *   `geometry/freehand.ts` 的纯派生函数，不依赖 controller、DOM、Canvas、SVG、Skia 或 legacy。
 * - **只缓存派生几何/呈现**：缓存对象绝不为文档数据，也不写回 object；`samples`、`brushSnapshot`
 *   与文档对象始终只读，缓存不进入任何序列化结果。
 * - **几何 key 必须同时包含版本与对象身份**：仅相同 `objectId` + 相同 revision 不足以复用——
 *   当 `samples` / `brushSnapshot` 的**引用身份**变化时（即使 revision 未变）必须重算，避免
 *   文档替换或 undo/redo 快照复用到 stale outline。
 * - **transform 只影响呈现**：`getGeometry` 不含 transform；`getPresentation` 的 key 含
 *   `transformRevision` 与 transform 数值，`transformRevision` 变化即失效呈现，几何、raw
 *   samples 与 brush 引用保持不变。
 * - **active / final 分开 key**：同一对象两种派生状态各自独立缓存，互不复用。
 * - 变换要求各分量有限且矩阵非奇异；无法求逆的变换在此拒绝，避免未来几何 query/inverse 出错。
 *   本模块不生成任何 history/undo entry。
 */
import type { Bounds, EditorDocument, FreehandObject, Point, ResolvedPressureMode } from '../model/document';
import { type DerivedFreehandGeometry, type FreehandGeometryState } from './freehand';
/** 每个对象每种状态最多保留的几何条目数（当前 + 一步 undo/redo 复用）。 */
export declare const FREEHAND_CACHE_MAX_ENTRIES_PER_STATE = 2;
/** 每个对象最多保留的呈现条目数（覆盖若干 transform 版本，避免无界增长）。 */
export declare const FREEHAND_CACHE_MAX_PRESENTATIONS = 4;
/**
 * 世界坐标呈现结果。
 * - `worldBounds`：由 outline 顶点精确仿射变换后求包围盒得到。
 * - `transformedPolygon`：outline 顶点经 transform 后的世界坐标序列（本地几何的变换视图）。
 */
export type FreehandPresentation = Readonly<{
    worldBounds: Bounds;
    transformedPolygon: readonly Point[];
}>;
/**
 * 几何缓存 key 的版本输入。
 *
 * 注意：引用身份（`samples` / `brushSnapshot` 的 `===`）不能表示为字符串，由缓存内部的
 * `isSameGeometryInput` 额外守护；本函数只负责可序列化的版本部分，便于测试与调试。
 */
export type FreehandGeometryKeyInput = Readonly<{
    objectId: string;
    state: FreehandGeometryState;
    samplesRevision: number;
    brushRevision: number;
    presetRevision: number;
    mode: ResolvedPressureMode;
    /** 仅参与 key；实际派生始终使用当前 `FREEHAND_ALGORITHM_REVISION` 对应的实现。 */
    algorithmRevision: string;
}>;
/**
 * 组装几何缓存版本 key（纯函数，不含引用身份）。
 *
 * algorithm revision 是 key 的一部分：算法/preset 升级后必须视为不同条目。当前生产只传入
 * 常量 `FREEHAND_ALGORITHM_REVISION`，本函数不改变派生实现，也不提供人为的算法开关。
 */
export declare function buildFreehandGeometryCacheKey(input: FreehandGeometryKeyInput): string;
/**
 * headless 自由笔几何/呈现缓存。
 *
 * 每个实例独立持有缓存；同一文档同一对象在 key 不变时复用派生结果，key 变化时重算。
 * 缓存槽由 `syncDocument` 按当前文档的 freehand objectId 保留/删除，生命周期与文档对象对齐。
 */
export declare class FreehandGeometryCache {
    private readonly objects;
    /** 按当前文档清理不再存在的 freehand 对象缓存槽；不做任何重算。 */
    syncDocument(document: EditorDocument): void;
    /**
     * 取对象在指定状态下的派生几何（active / final 分开缓存）。
     *
     * key 同时要求版本相等与 `samples` / `brushSnapshot` 引用身份相等；文档替换或 undo/redo
     * 带来的新引用（即使 revision 未变）会触发重算，绝不返回 stale outline。
     */
    getGeometry(object: FreehandObject, state: FreehandGeometryState): DerivedFreehandGeometry;
    /**
     * 取对象在指定状态下的世界坐标呈现（bounds + 变换后 polygon）。
     *
     * 呈现 key = 几何身份 + `transformRevision` + transform 数值；`transformRevision` 变化即失效
     * （即使数值相同），与 design.md「世界 bounds 由 transformRevision 失效」一致。几何缓存被复用，
     * raw samples / brush 不被改写。非有限、奇异或溢出 transform 在此拒绝并抛错，不产生任何 history。
     */
    getPresentation(object: FreehandObject, state: FreehandGeometryState): FreehandPresentation;
    /** 清空全部缓存槽；不触碰任何文档数据。 */
    clear(): void;
    /** 懒创建对象缓存槽。 */
    private ensureSlot;
}
//# sourceMappingURL=freehandCache.d.ts.map