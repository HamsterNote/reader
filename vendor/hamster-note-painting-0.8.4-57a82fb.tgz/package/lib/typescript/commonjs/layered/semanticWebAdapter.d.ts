import type { GetClientToLocal } from '../geometry/pageCoordinates';
import type { LayeredEditorController } from '../core/layeredEditorController';
import type { Point } from '../model/document';
import type { WebFreehandPolicy } from '../input/web/freehandWebAdapter';
import { type GestureTraceObserver } from '../input/web/gestureTrace';
/** Object identity is for ordinary hover/click only; captured trajectories use geometry. */
export declare function resolveObjectId(target: EventTarget | null): string | null;
export declare function createSemanticWebAdapter(options: {
    host: HTMLElement;
    controller: LayeredEditorController;
    allocateId: () => string;
    policy?: WebFreehandPolicy;
    onText: (point: Point) => void;
    onImage?: (point: Point) => void;
    onError: (error: unknown) => void;
    beforeGesture?: () => void;
    onTrace?: GestureTraceObserver;
    listen?: boolean;
    getClientToLocal?: GetClientToLocal;
    canNavigate?: () => boolean;
}): {
    cancel: () => boolean;
    dispatch(event: PointerEvent): void;
    destroy(): void;
};
//# sourceMappingURL=semanticWebAdapter.d.ts.map