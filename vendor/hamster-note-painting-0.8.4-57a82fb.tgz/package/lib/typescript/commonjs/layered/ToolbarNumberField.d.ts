import { type CSSProperties } from 'react';
/** Keep incomplete typing (e.g. "1" on the way to 125%) out of the controller. */
export declare function ToolbarNumberField({ label, value, min, max, step, style, apply, }: {
    label: string;
    value: number;
    min: number;
    max: number;
    step: number;
    style?: CSSProperties;
    /** Returns the authoritative value, including when the controller refuses the change. */
    apply: (value: number) => number;
}): import("react").JSX.Element;
//# sourceMappingURL=ToolbarNumberField.d.ts.map