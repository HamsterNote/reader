import type { LayeredEditorController } from '../core/layeredEditorController';
import { FreehandGeometryCache } from '../geometry/freehandCache';
import type { DocumentObject } from '../model/document';
import type { PresentationCoordinator } from './PresentationCoordinator';
export type RenderObserver = (scope: 'display' | 'object', objectId?: string) => void;
export declare const ObjectNode: import("react").NamedExoticComponent<{
    object: DocumentObject;
    cache: FreehandGeometryCache;
    onRender?: RenderObserver;
}>;
export declare function DisplayLayer({ controller, presentation, onRender, historyReadyDelayMs, interactive, }: {
    controller: LayeredEditorController;
    presentation: PresentationCoordinator;
    onRender?: RenderObserver;
    historyReadyDelayMs?: number;
    interactive?: boolean;
}): import("react").JSX.Element;
//# sourceMappingURL=DisplayLayer.d.ts.map