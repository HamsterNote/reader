import type { LayeredEditorChannel, LayeredEditorController, LayeredEditorSnapshotMap } from '../core/layeredEditorController';
export declare function useEditorSnapshot<C extends Exclude<LayeredEditorChannel, 'interaction'>>(controller: LayeredEditorController, channel: C): LayeredEditorSnapshotMap[C];
//# sourceMappingURL=useEditorSnapshot.d.ts.map