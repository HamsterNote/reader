import type { LayeredEditorController } from '../core/layeredEditorController';
export declare function NavigationOverlay({ controller }: {
    controller: LayeredEditorController;
}): import("react").JSX.Element;
export declare function VirtualPaper({ controller }: {
    controller: LayeredEditorController;
}): import("react").JSX.Element | null;
//# sourceMappingURL=NavigationOverlay.d.ts.map