import { type LayeredInputMode } from '../core/layeredInputMode';
export declare const INPUT_MODE_PREFERENCE_KEY = "hamster-note.painting.input-mode.v1";
type PreferenceStorage = Pick<Storage, 'getItem' | 'setItem'>;
export declare function readInputModePreference(getStorage?: () => PreferenceStorage | undefined): LayeredInputMode | undefined;
export declare function writeInputModePreference(mode: LayeredInputMode, getStorage?: () => PreferenceStorage | undefined): void;
export {};
//# sourceMappingURL=inputModePreference.d.ts.map