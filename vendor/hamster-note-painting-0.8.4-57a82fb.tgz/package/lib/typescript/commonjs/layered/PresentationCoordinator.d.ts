import type { LayeredEditorController, LayeredPresentationIdentity } from '../core/layeredEditorController';
import type { FreehandObject } from '../model/document';
import { type GestureTraceObserver } from '../input/web/gestureTrace';
export interface HistoryPresentationNode {
    setVisible(visible: boolean): void;
    matches?(identity: LayeredPresentationIdentity): boolean;
}
/** Web-internal ownership only. An ACK proves mounted content, never physical paint. */
export declare class PresentationCoordinator {
    private readonly controller;
    private readonly onTrace?;
    private readonly pending;
    private readonly nodes;
    private readonly native;
    private objects;
    private repaint;
    private readonly unsubscribe;
    constructor(controller: LayeredEditorController, onTrace?: GestureTraceObserver | undefined);
    setRepaint(repaint: () => void): () => void;
    private syncDocument;
    getPending(): readonly FreehandObject[];
    holdNative(commitId: string, ready: () => void): void;
    hasNativePreview(commitId: string): boolean;
    retireNative(commitId: string): void;
    getIdentity(objectId: string): LayeredPresentationIdentity | undefined;
    isHidden(objectId: string): boolean;
    mount(objectId: string, node: HistoryPresentationNode): () => void;
    confirmMounted(): boolean;
    acknowledge(identity: LayeredPresentationIdentity): boolean;
    private flushReady;
    private updateVisibility;
    destroy(): void;
}
//# sourceMappingURL=PresentationCoordinator.d.ts.map