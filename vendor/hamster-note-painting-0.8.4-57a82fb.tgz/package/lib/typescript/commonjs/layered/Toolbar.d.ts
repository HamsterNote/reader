import { type PaneToolbarLayout, type ToolbarFileNavigationProps, type ToolbarOccupiedSpace } from '../toolbar';
import type { LayeredEditorController } from '../core/layeredEditorController';
export type ToolbarProps = ToolbarFileNavigationProps & {
    layout?: PaneToolbarLayout;
    onOccupiedSpaceChange?: (space: ToolbarOccupiedSpace) => void;
    controller: LayeredEditorController;
    /** floating is positioned within the nearest positioned parent (normally PaintingBoard). */
    placement?: 'inline' | 'floating';
    /** Use page controls instead of focus-triggered native select/color pickers. */
    inlinePickers?: boolean;
};
/** Low-frequency channels only; raw input never renders the toolbar. */
export declare function Toolbar({ controller, placement, inlinePickers, layout, onOccupiedSpaceChange, ...fileNavigation }: ToolbarProps): import("react").JSX.Element | null;
//# sourceMappingURL=Toolbar.d.ts.map