import type { LayeredEditorController } from '../core/layeredEditorController';
import type { Point } from '../model/document';
export declare function createZoomFeedback(controller: LayeredEditorController, view: Window): {
    show(scale: number, point: Point): void;
    clear: () => void;
};
//# sourceMappingURL=zoomFeedback.d.ts.map