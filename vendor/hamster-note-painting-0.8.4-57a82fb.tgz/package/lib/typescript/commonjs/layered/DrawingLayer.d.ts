export { DrawingLayer } from './DrawingLayer.web';
export type { DrawingLayerProps } from './DrawingLayer.web';
//# sourceMappingURL=DrawingLayer.d.ts.map