import type { ComponentProps } from 'react';
import { ToolbarPopover } from '../toolbar/ToolbarPopover';
export declare function ToolbarPanel(props: ComponentProps<typeof ToolbarPopover>): import("react").JSX.Element;
//# sourceMappingURL=ToolbarPanel.d.ts.map