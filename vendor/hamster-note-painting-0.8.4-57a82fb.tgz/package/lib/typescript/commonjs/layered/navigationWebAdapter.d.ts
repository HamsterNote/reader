import type { LayeredEditorController } from '../core/layeredEditorController';
import type { LayeredInputResetReason } from '../core/layeredInputArbitration';
import { type GestureTraceObserver } from '../input/web/gestureTrace';
/** Touch navigation owns a fixed pair; ignored contacts never become a deferred gesture. */
export declare function createNavigationWebAdapter(host: HTMLElement, controller: LayeredEditorController, _touchDraw?: boolean, onTrace?: GestureTraceObserver, options?: {
    listen?: boolean;
    canNavigate?: () => boolean;
}): {
    targetRole(event: PointerEvent): "ruler" | undefined;
    cancel(reason?: LayeredInputResetReason): boolean;
    begin(events: readonly PointerEvent[]): void;
    dispatch(event: PointerEvent): void;
    destroy(): void;
};
//# sourceMappingURL=navigationWebAdapter.d.ts.map