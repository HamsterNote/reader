import type { LayeredEditorController } from '../core/layeredEditorController';
import type { PresentationCoordinator } from './PresentationCoordinator';
/** Controller owns the raw append buffer. This driver reads it at most once per frame. */
export declare function createDrawingCanvas(canvas: HTMLCanvasElement, controller: LayeredEditorController, presentation: PresentationCoordinator): {
    paintNow: () => void;
    destroy(): void;
};
//# sourceMappingURL=drawingCanvas.d.ts.map