export { DrawingLayer } from './DrawingLayer.web';
export type { DrawingLayerProps } from './DrawingLayer.web';
//# sourceMappingURL=DrawingLayer.ios.d.ts.map