import type { LayeredEditorController } from '../core/layeredEditorController';
import { type Point } from '../model/document';
/** Only decoded, current imports enter the document; data URLs survive save and undo/redo. */
export declare function useImageImport(controller: LayeredEditorController, allocateId: () => string): {
    openAt: (point: Point) => void;
    element: import("react").JSX.Element;
};
//# sourceMappingURL=useImageImport.d.ts.map