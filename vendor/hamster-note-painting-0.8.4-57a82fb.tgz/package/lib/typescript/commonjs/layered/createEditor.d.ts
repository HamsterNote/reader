import type { EditorDocument } from '../model/document';
import type { LayeredInputMode } from '../core/layeredInputMode';
export declare function createEditor(document?: EditorDocument, options?: {
    inputMode?: LayeredInputMode;
}): import(".").LayeredEditorController;
//# sourceMappingURL=createEditor.d.ts.map