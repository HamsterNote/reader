import type { LayeredEditorController } from '../core/layeredEditorController';
import { type Point } from '../model/document';
export declare function TextEditor({ controller, point, allocateId, close, }: {
    controller: LayeredEditorController;
    point: Point;
    allocateId: () => string;
    close: () => void;
}): import("react").JSX.Element | null;
//# sourceMappingURL=TextEditor.d.ts.map