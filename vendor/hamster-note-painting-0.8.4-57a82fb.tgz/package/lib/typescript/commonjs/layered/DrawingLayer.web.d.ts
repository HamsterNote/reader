import type { LayeredEditorController } from '../core/layeredEditorController';
import type { PresentationCoordinator } from './PresentationCoordinator';
export type DrawingLayerProps = {
    controller: LayeredEditorController;
    presentation: PresentationCoordinator;
};
export declare function DrawingLayer({ controller, presentation }: DrawingLayerProps): import("react").JSX.Element;
//# sourceMappingURL=DrawingLayer.web.d.ts.map