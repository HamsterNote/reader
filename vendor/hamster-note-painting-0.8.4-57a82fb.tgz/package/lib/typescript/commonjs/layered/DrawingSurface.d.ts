import { type CSSProperties } from 'react';
import type { LayeredEditorController } from '../core/layeredEditorController';
import { type WebFreehandPolicy } from '../input/web/freehandWebAdapter';
import { type RenderObserver } from './DisplayLayer';
import { type PageGeometry } from '../geometry/pageCoordinates';
import type { DrawingSurfaceVirtualPaperOptions } from '../virtualPaperOptions';
import { type GestureTraceObserver } from '../input/web/gestureTrace';
import { type PencilkitDemoConnection } from '../input/native/pencilkitDemoBridge';
export type LayeredDrawingSurfaceProps = {
    controller: LayeredEditorController;
    /** Disabling cancels unfinished input and lets the underlying page receive events. */
    enabled?: boolean;
    inputPolicy?: WebFreehandPolicy;
    style?: CSSProperties;
    onRender?: RenderObserver;
    historyReadyDelayMs?: number;
    virtualPaper?: boolean | DrawingSurfaceVirtualPaperOptions;
    onGestureTrace?: GestureTraceObserver;
    nativePencilExperiment?: PencilkitDemoConnection;
    /** Prefer PageDrawingSurface for externally navigated document pages. */
    page?: PageGeometry;
};
/** Surface owns DOM resources only. Document, input, settings and viewport live in the controller. */
export declare function LayeredDrawingSurface({ controller, enabled, inputPolicy, style, onRender, historyReadyDelayMs, virtualPaper, onGestureTrace, nativePencilExperiment, page, }: LayeredDrawingSurfaceProps): import("react").JSX.Element;
export type PageDrawingSurfaceProps = Omit<LayeredDrawingSurfaceProps, 'page' | 'virtualPaper' | 'nativePencilExperiment'> & {
    pageId: string;
    geometry: PageGeometry;
};
/** One controller per page. Navigation belongs to the host PDF/document viewer. */
export declare function PageDrawingSurface({ pageId, geometry, ...props }: PageDrawingSurfaceProps): import("react").JSX.Element;
//# sourceMappingURL=DrawingSurface.d.ts.map