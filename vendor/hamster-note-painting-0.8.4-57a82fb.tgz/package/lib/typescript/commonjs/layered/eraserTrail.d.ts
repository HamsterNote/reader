import type { LayeredEditorController } from '../core/layeredEditorController';
import type { Point } from '../model/document';
/** Local visual feedback only. CSS handles fading; one-shot timers retire each sampled segment. */
export declare function createEraserTrail(host: HTMLElement, controller: LayeredEditorController): {
    begin(point: Point): void;
    append: (points: readonly Point[]) => void;
    finish(action: () => void): void;
    clear: () => void;
    destroy(): void;
};
//# sourceMappingURL=eraserTrail.d.ts.map