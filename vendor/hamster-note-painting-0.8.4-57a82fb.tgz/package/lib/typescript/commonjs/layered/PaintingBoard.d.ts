import type { ToolbarFileNavigationProps, PaneToolbarLayout } from '../toolbar';
import type { LayeredDrawingSurfaceProps } from './DrawingSurface';
export type LayeredPaintingBoardProps = LayeredDrawingSurfaceProps & ToolbarFileNavigationProps & {
    layout?: PaneToolbarLayout;
    toolbar?: boolean;
    /** Keep keyboard focus in the page on hosts that open native pickers on focus. */
    toolbarInlinePickers?: boolean;
};
export declare function LayeredPaintingBoard({ toolbar, toolbarInlinePickers, files, currentFileKey, paneId, busy, onSelectFile, onRequestRemove, layout, ...props }: LayeredPaintingBoardProps): import("react").JSX.Element;
//# sourceMappingURL=PaintingBoard.d.ts.map