import type { LayeredEditorController } from '../core/layeredEditorController';
import type { WebFreehandPolicy } from '../input/web/freehandWebAdapter';
/** SSR emits no interactive controls; restoration precedes client input listeners. */
export declare function useInputInitialization(controller: LayeredEditorController, policy?: WebFreehandPolicy, surface?: boolean): boolean;
//# sourceMappingURL=useInputInitialization.d.ts.map