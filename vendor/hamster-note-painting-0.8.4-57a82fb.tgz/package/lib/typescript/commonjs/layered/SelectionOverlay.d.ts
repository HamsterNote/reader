import type { LayeredEditorController } from '../core/layeredEditorController';
export declare function SelectionOverlay({ controller }: {
    controller: LayeredEditorController;
}): import("react").JSX.Element | null;
//# sourceMappingURL=SelectionOverlay.d.ts.map