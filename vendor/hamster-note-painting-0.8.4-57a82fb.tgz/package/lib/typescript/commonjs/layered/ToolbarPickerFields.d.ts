/** WKWebView can open a native picker merely from select.focus(). */
export declare function ToolbarChoiceField({ label, ariaLabel, inline, value, options, onChange, }: {
    label: string;
    ariaLabel?: string;
    inline: boolean;
    value: string;
    options: readonly (readonly [string, string])[];
    onChange: (value: string) => void;
}): import("react").JSX.Element;
/** An ordinary text editor keeps the keyboard in WebKit, without a color sheet. */
export declare function ToolbarHexColorField({ value, onChange, }: {
    value: string;
    onChange: (value: string) => void;
}): import("react").JSX.Element;
//# sourceMappingURL=ToolbarPickerFields.d.ts.map