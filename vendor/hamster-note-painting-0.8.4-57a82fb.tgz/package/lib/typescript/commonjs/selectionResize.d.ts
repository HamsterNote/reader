import type { DrawingStroke } from './model/geometryTypes';
import { type SelectionFrame } from './selectionRotation';
export type SelectionResizeAxis = {
    readonly anchor: number;
    readonly scale: number;
};
export type SelectionResizeTransform = {
    readonly frame: SelectionFrame;
    readonly xAxis: SelectionResizeAxis;
    readonly yAxis: SelectionResizeAxis;
};
export declare function resizeStrokeInSelectionFrame(stroke: DrawingStroke, transform: SelectionResizeTransform): DrawingStroke;
//# sourceMappingURL=selectionResize.d.ts.map