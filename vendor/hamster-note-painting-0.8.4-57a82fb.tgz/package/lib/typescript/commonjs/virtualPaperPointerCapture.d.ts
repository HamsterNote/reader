export declare const POINTER_DOWN_CAPTURE_OPTIONS: {
    readonly capture: true;
};
export declare function shouldCaptureVirtualPaperPointerDown(listenerTarget: EventTarget, host: HTMLElement, virtualPaperEnabled: boolean): boolean;
//# sourceMappingURL=virtualPaperPointerCapture.d.ts.map