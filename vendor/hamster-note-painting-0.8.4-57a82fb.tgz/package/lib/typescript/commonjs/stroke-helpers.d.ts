import type { DrawingPoint, DrawingStroke, DrawingStrokeStyle, DrawingTool, DrawingValue } from './model/geometryTypes';
export declare function generateStrokeId(): string;
export declare function createStroke(tool: DrawingTool, style?: DrawingStrokeStyle): DrawingStroke;
export declare function createStroke(tool: DrawingTool, strokeColor?: string, strokeWidth?: number): DrawingStroke;
export declare function appendPoint(stroke: DrawingStroke, point: DrawingPoint): DrawingStroke;
export declare function isValidStroke(stroke: DrawingStroke): boolean;
export declare function pointsToPolyline(points: DrawingPoint[]): string;
export declare function createDrawingValue(strokes: DrawingStroke[]): DrawingValue;
export type DrawingStrokeSmoothingOptions = {
    enabled?: boolean;
    strength?: number;
    density?: number;
    velocityThreshold?: number;
    minSegmentLength?: number;
    maxSegmentLength?: number;
    maxInterpolatedPoints?: number;
};
export type TimedDrawingPoint = DrawingPoint & {
    timestamp?: number;
};
export declare function resolveStrokeSmoothingOptions(input?: boolean | DrawingStrokeSmoothingOptions): Required<DrawingStrokeSmoothingOptions>;
export declare function getPointVelocity(previous: TimedDrawingPoint, current: TimedDrawingPoint): number;
export declare function getAdaptiveInterpolationCount(previous: TimedDrawingPoint, current: TimedDrawingPoint, options?: DrawingStrokeSmoothingOptions): number;
export declare function interpolateCatmullRomPoint(p0: DrawingPoint, p1: DrawingPoint, p2: DrawingPoint, p3: DrawingPoint, t: number, strength?: number): DrawingPoint;
export declare function createVelocityAdaptivePoints(rawPoints: TimedDrawingPoint[], options?: DrawingStrokeSmoothingOptions): DrawingPoint[];
export declare function pointsToSvgPath(points: DrawingPoint[]): string;
//# sourceMappingURL=stroke-helpers.d.ts.map