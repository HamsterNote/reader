import type { DrawingPoint, DrawingStroke, DrawingValue } from './model/geometryTypes';
import type { DrawingStrokeV2 } from './model/strokes';
type PickableStroke = DrawingStroke | DrawingStrokeV2;
export type RenderedStrokeHitTestOptions = {
    eraserRadius: number;
    openFallbackWidth: number;
    closedFallbackWidth: number;
    pressureMultiplier: number;
};
export type LassoSelectionOptions = {
    ellipseSegments?: number;
    bezierSegments?: number;
};
export type SelectionBox = {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
};
type SnapOptions = {
    enabled: boolean;
    endpoints: boolean;
    lines: boolean;
    radius?: number;
};
type SnapKind = 'endpoint' | 'line';
type SnapCandidate = {
    canvas: DrawingPoint;
    kind: SnapKind;
    strokeId?: string;
};
export type SnapPointResult = SnapCandidate | null;
export declare const SELECTION_BOX_PADDING = 8;
export declare function resolveSnapPoint(point: DrawingPoint, strokes: readonly DrawingStroke[], options: SnapOptions, viewportScale?: number): SnapPointResult;
export declare function addStroke(value: DrawingValue, stroke: DrawingStroke): DrawingValue;
export declare function removeStroke(value: DrawingValue, strokeId: string): DrawingValue;
export declare function removeStrokes(value: DrawingValue, strokeIds: readonly string[]): DrawingValue;
export declare function updateStroke(value: DrawingValue, stroke: DrawingStroke): DrawingValue;
export declare function updateStrokes(value: DrawingValue, strokes: readonly DrawingStroke[]): DrawingValue;
/**
 * 计算选中 strokes 的原始几何边界，不包含描边宽度和选区 padding。
 * 缩放手势以此边界为锚点，保证拖动控制点时图形端点准确跟随指针。
 */
export declare function computeSelectionGeometryBox(strokes: readonly (DrawingStroke | DrawingStrokeV2)[], selectedIds: readonly string[], options?: LassoSelectionOptions): SelectionBox | null;
/**
 * 计算当前选中 strokes 的画布坐标选区框。
 *
 * 复用套索命中的 geometry 采样规则，确保 rect/ellipse/polygon/bezier 的边界
 * 与渲染和套索选择使用同一套几何语义。每条 stroke 先按自身 strokeWidth/2
 * 外扩，再把所有有效选中 stroke 合并并追加固定选区 padding。
 */
export declare function computeSelectionBox(strokes: readonly (DrawingStroke | DrawingStrokeV2)[], selectedIds: readonly string[], options?: LassoSelectionOptions): SelectionBox | null;
export declare function selectStrokesIntersectingLasso(strokes: readonly DrawingStroke[], lassoPoints: readonly DrawingPoint[], options?: LassoSelectionOptions): string[];
export declare function clearStrokes(value: DrawingValue): DrawingValue;
/**
 * Returns the stroke closest to `point`, or `null` when `strokes` is empty.
 *
 * Distance semantics per tool:
 * - pen: minimum distance to polyline segments
 * - line: minimum distance to open line segments
 * - rect: distance to axis-aligned bounding rectangle (0 when inside)
 *
 * @param maxDistance - Optional maximum distance threshold. If the closest stroke
 *   is farther than this distance, returns `null`. Used for object eraser radius.
 */
export declare function pick<TStroke extends PickableStroke>(point: DrawingPoint, strokes: TStroke[], maxDistance?: number): TStroke | null;
export declare function pickTextStrokeAtPoint(point: DrawingPoint, strokes: readonly DrawingStroke[]): DrawingStroke | null;
export declare function pickImageStrokeAtPoint(point: DrawingPoint, strokes: readonly DrawingStroke[]): DrawingStroke | null;
/**
 * Samples along the eraser sweep so hit testing can reuse `distanceSqPointToStroke`,
 * including per-tool dispatch, fill short-circuiting, and Bezier sampling, without
 * duplicating that logic for each tool. `pickStep = max(0.5, radius / 4)` keeps
 * samples at most about a quarter radius apart so intersecting objects cannot slip
 * between samples. Equal-distance hits prefer the earlier stroke index across the
 * whole sweep, matching `pick()` even when that stroke is sampled later.
 */
export declare function pickStrokeIntersectingSegment<TStroke extends PickableStroke>(start: DrawingPoint, end: DrawingPoint, strokes: TStroke[], radius: number): TStroke | null;
/**
 * Returns the first/closest stroke intersected by an eraser sweep while accounting
 * for the target's rendered stroke width. `targetHalfWidth` means half of the
 * width actually painted for the target stroke: non-pressure strokes use
 * `max(0, stroke.strokeWidth ?? fallbackWidth) / 2`; pressure pen segments use
 * `baseWidth * max(normalizePointPressure(a), normalizePointPressure(b)) *
 * pressureMultiplier / 2`. A hit occurs when the centerline/outline distance is
 * `<= eraserRadius + targetHalfWidth`; filled rect/ellipse/polygon interiors
 * keep distance 0 so fill-aware erasing is preserved.
 */
export declare function pickRenderedStrokeIntersectingSegment<TStroke extends PickableStroke>(start: DrawingPoint, end: DrawingPoint, strokes: TStroke[], options: RenderedStrokeHitTestOptions): TStroke | null;
export declare function pickStrokeIntersectingPolyline<TStroke extends PickableStroke>(points: DrawingPoint[], strokes: TStroke[], radius: number): TStroke | null;
/**
 * Sweeps an eraser polyline using rendered-width-aware thresholds. For each
 * sampled eraser point, `targetHalfWidth` is added to `eraserRadius`; for
 * pressure pen segments, `targetHalfWidth` is recalculated per target segment
 * from the rendered formula `baseWidth * max(segment endpoint pressure) *
 * pressureMultiplier / 2`. Filled closed-shape interiors remain distance 0;
 * unfilled closed shapes use outline distance plus their rendered half-width.
 */
export declare function pickRenderedStrokeIntersectingPolyline<TStroke extends PickableStroke>(points: DrawingPoint[], strokes: TStroke[], options: RenderedStrokeHitTestOptions): TStroke | null;
export {};
//# sourceMappingURL=utils.d.ts.map