import type { LayeredEditorController } from '../../core/layeredEditorController';
import type { PresentationCoordinator } from '../../layered/PresentationCoordinator';
import type { createLayeredInputArbiter } from '../web/layeredInputArbiter';
import { type PencilkitDemoMessage, type PencilkitDemoReply, type PencilkitDemoState } from './pencilkitDemoContract';
export type PencilkitDemoConnection = {
    onState: (state: PencilkitDemoState) => void;
    onReply: (reply: PencilkitDemoReply) => void;
    register: (receiver: ((message: PencilkitDemoMessage) => void) | undefined) => void;
};
/** Bounded feasibility bridge. The controller remains the only document/history owner. */
export declare function connectPencilkitDemo(options: {
    host: HTMLElement;
    controller: LayeredEditorController;
    presentation: PresentationCoordinator;
    arbiter: ReturnType<typeof createLayeredInputArbiter>;
    connection: PencilkitDemoConnection;
}): () => void;
//# sourceMappingURL=pencilkitDemoBridge.d.ts.map