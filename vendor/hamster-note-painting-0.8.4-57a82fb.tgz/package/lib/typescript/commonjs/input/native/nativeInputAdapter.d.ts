import type { NormalizedPointerInput, TargetRole } from '../../core/internal';
/** RNGH touch callback 中单个触点所需的最小、无运行时依赖的数据结构。 */
export type NativeTouchSample = Readonly<{
    id: string | number;
    x: number;
    y: number;
}>;
/**
 * RNGH 2.32 `TouchEventType` 的数值表示，以及便于不导入 RNGH 的调用方/测试使用的等价字符串。
 * `x`/`y` 已是 gesture view-local 坐标；adapter 有意不声明或读取 absolute 坐标。
 */
export type NativeTouchEvent = Readonly<{
    eventType: number | 'TOUCHES_DOWN' | 'TOUCHES_MOVE' | 'TOUCHES_UP' | 'TOUCHES_CANCELLED';
    pointerType: string;
    changedTouches: readonly NativeTouchSample[];
}>;
/** RNGH finalize 回调所需的最小状态形状；RNGH State.END 的数值是 5。 */
export type NativeFinalizeEvent = Readonly<{
    state: number | string;
}>;
export type NativeInputAdapter = Readonly<{
    handleTouches: (event: NativeTouchEvent) => void;
    handleFinalize: (event: NativeFinalizeEvent, success: boolean) => void;
    destroy: () => void;
    getActivePointerIds: () => readonly (string | number)[];
}>;
export type CreateNativeInputAdapterOptions = Readonly<{
    onInput: (input: NormalizedPointerInput) => void;
    resolveTargetRole: (hostLocalPoint: Readonly<{
        x: number;
        y: number;
    }>) => TargetRole | unknown;
    toHostLocal?: (viewLocalPoint: Readonly<{
        x: number;
        y: number;
    }>) => Readonly<{
        x: number;
        y: number;
    }>;
    now?: () => number;
}>;
/**
 * 将 RNGH touch callbacks 翻译为 core 输入。该层不依赖 React、React Native、RNGH 或
 * Reanimated；外层需在 JS 上调用它，以便维持可测试、不可变的离散 pointer 生命周期。
 */
export declare function createNativeInputAdapter(options: CreateNativeInputAdapterOptions): NativeInputAdapter;
//# sourceMappingURL=nativeInputAdapter.d.ts.map