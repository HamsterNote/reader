import type { BrushSnapshot } from '../../model/document';
/** Opt-in G2/G3 experiment, not the production semantic protocol. */
export type PencilkitDemoSample = Readonly<{
    seq: number;
    phase: 'down' | 'move' | 'up' | 'cancel';
    kind: 'main' | 'coalesced';
    x: number;
    y: number;
    tabs: number;
    f: number;
    mf: number;
    p: number | null;
}>;
export type PencilkitDemoStroke = Readonly<{
    id: number;
    cancelled: boolean;
    overflow: boolean;
    samples: readonly PencilkitDemoSample[];
}>;
type Envelope = Readonly<{
    protocolVersion: 1;
    messageId: number;
    contextKey: string;
    id: number;
}>;
export type PencilkitDemoMessage = Envelope & ({
    type: 'begin';
    sample: PencilkitDemoSample;
} | {
    type: 'stroke';
    stroke: PencilkitDemoStroke;
} | {
    type: 'retired';
} | {
    type: 'reset';
});
export type PencilkitDemoReply = Readonly<{
    messageId?: number;
    id: number;
    contextKey: string;
    status: 'accepted' | 'cancelled' | 'committed' | 'retire' | 'visible' | 'rejected' | 'reset';
    reason?: string;
}>;
export type PencilkitDemoState = Readonly<{
    protocolVersion: 1;
    contextKey: string;
    enabled: boolean;
    frame: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    exclusions: readonly {
        x: number;
        y: number;
        width: number;
        height: number;
    }[];
    brush: BrushSnapshot;
    scale: number;
}>;
export declare function isPencilkitDemoSample(value: unknown): value is PencilkitDemoSample;
export declare function isPencilkitDemoStroke(value: unknown): value is PencilkitDemoStroke;
export {};
//# sourceMappingURL=pencilkitDemoContract.d.ts.map