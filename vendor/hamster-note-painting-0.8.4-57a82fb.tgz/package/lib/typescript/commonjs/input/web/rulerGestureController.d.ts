import { type GestureRulerState } from '../../core/gesture/session';
import type { Point } from '../../core/input';
import { type GestureTraceObserver } from './gestureTrace';
type RulerDomState = Readonly<{
    center: Point;
    rotationRad?: number;
}>;
export type RulerGestureControllerOptions = Readonly<{
    host: HTMLElement;
    listenerTarget: EventTarget;
    getRulerState: () => RulerDomState | null;
    getRotationPivot: (state: GestureRulerState) => Point;
    hitTest: (event: PointerEvent) => boolean;
    toLocalPoint: (event: PointerEvent) => Point;
    onState: (state: GestureRulerState) => void;
    onActiveChange: (active: boolean) => void;
    onTrace?: GestureTraceObserver;
    onRotationFeedback: (feedback: Readonly<{
        rotationRad: number;
        point: Point;
        state: GestureRulerState;
    }> | null) => void;
}>;
export type RulerGestureController = Readonly<{
    cancel: (options?: {
        releaseContacts?: boolean;
    }) => void;
    dispose: () => void;
}>;
/**
 * DOM 尺子输入。它只负责 pointer capture、几何分类与宿主 content-box DIP 归一化；
 * 所有尺子位姿均由 core GestureSession 计算。不会伪造 DOM 事件或调用 multi-drag API。
 */
export declare function createRulerGestureController(options: RulerGestureControllerOptions): RulerGestureController;
export {};
//# sourceMappingURL=rulerGestureController.d.ts.map