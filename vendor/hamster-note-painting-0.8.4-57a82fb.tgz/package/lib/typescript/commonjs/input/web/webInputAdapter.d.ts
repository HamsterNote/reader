import type { NormalizedPointerInput } from '../../core/internal';
import type { NormalizePointerInputOptions } from './normalizePointerInput';
export type WebInputAdapter = Readonly<{
    destroy: () => void;
    getActivePointerIds: () => readonly number[];
}>;
export type CreateWebInputAdapterOptions = Readonly<Omit<NormalizePointerInputOptions, 'host'> & {
    host: HTMLElement;
    onInput: (input: NormalizedPointerInput) => void;
}>;
/**
 * Web 平台的 pointer 生命周期边界。此层只追踪已规范化的浏览器 pointer，不参与 core 的
 * ownership 或 GestureSession 决策，因此 move 命中的角色可以如实变化并由 core 锁定 owner。
 */
export declare function createWebInputAdapter(options: CreateWebInputAdapterOptions): WebInputAdapter;
//# sourceMappingURL=webInputAdapter.d.ts.map