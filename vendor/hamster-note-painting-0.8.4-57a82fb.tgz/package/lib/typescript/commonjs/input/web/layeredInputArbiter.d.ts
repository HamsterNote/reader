import type { GetClientToLocal } from '../../geometry/pageCoordinates';
import type { LayeredEditorController } from '../../core/layeredEditorController';
import type { NormalizedPointerInput, TargetRole } from '../../core/input';
import { type LayeredInputResetReason } from '../../core/layeredInputArbitration';
export type LayeredInputPort = {
    dispatch(event: PointerEvent): void;
    cancel(reason?: LayeredInputResetReason): boolean;
};
export declare function createLayeredInputArbiter(options: {
    host: HTMLElement;
    controller: LayeredEditorController;
    tool: LayeredInputPort;
    navigation: LayeredInputPort & {
        begin(events: readonly PointerEvent[]): void;
    };
    targetRole?: (event: PointerEvent) => TargetRole | undefined;
    getClientToLocal?: GetClientToLocal;
    onDiagnostic?: (message: string) => void;
}): {
    setNativePencilGuard(guard: ((input: NormalizedPointerInput) => void) | undefined): void;
    claimNativePencil(input: NormalizedPointerInput, cancel: () => boolean): boolean;
    releaseNativePencil(): void;
    isWriting: () => boolean;
    destroy(): void;
};
//# sourceMappingURL=layeredInputArbiter.d.ts.map