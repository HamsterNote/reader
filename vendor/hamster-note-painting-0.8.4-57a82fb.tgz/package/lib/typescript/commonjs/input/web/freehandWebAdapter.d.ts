import type { GetClientToLocal } from '../../geometry/pageCoordinates';
/**
 * Web 自由笔输入 adapter（Task 4.1 / 4.2 / 4.3 集成边界）。
 *
 * 职责：把宿主 `HTMLElement` 上的 pointer 生命周期归一化为 begin/update/end/cancel，
 * 转换为 screen 坐标 batch 后交给 `LayeredEditorController`。**controller 是唯一真源**：
 * 本 adapter 不持有第二份 document/history/viewport，只保留一个本地 transport owner 与计数器。
 *
 * 边界：
 * - 只监听 window 的 move/up/cancel（down 在 host），不重复注册；只用父 move/up 与非空
 *   coalesced 列表（按提供顺序消费，不追加父 event、不排序、不按值去重）。
 * - 不读 predicted events，不监听 rawupdate，不读旧 normalizePointerInput（它会滤掉越界 pressure）。
 * - 不实现 pan / 非笔过程反馈；不改 host 样式（touch-action 由 surface 后续负责）。
 * - DOM mock 不等于真机 / 像素验证。
 */
import type { LayeredCommitReceipt, LayeredEditorController, LayeredEditorResult } from '../../core/layeredEditorController';
import type { FreehandCandidate } from '../../core/freehandSession';
import type { PressureCapability } from '../../model/document';
import { type GestureTraceObserver } from './gestureTrace';
/** 本 adapter 支持的指针来源；未知来源一律拒绝。 */
export type WebFreehandSource = 'mouse' | 'touch' | 'pen';
/** 每来源绘图政策；默认三者皆 draw，none 不启笔。 */
export type WebFreehandPolicy = Readonly<Record<WebFreehandSource, 'draw' | 'none'>>;
/** 端到端可观测通知；result 对应 controller 返回（commit 阶段为 commit receipt）。 */
export type FreehandWebAdapterNotice = Readonly<{
    phase: 'begin' | 'update' | 'end' | 'cancel' | 'commit';
    sessionId: string;
    commitId: string;
    result: LayeredEditorResult<void | FreehandCandidate | LayeredCommitReceipt>;
}>;
/** 创建选项。 */
export type CreateFreehandWebAdapterOptions = Readonly<{
    host: HTMLElement;
    controller: LayeredEditorController;
    createSessionId: () => string;
    createCommitId: () => string;
    policy?: WebFreehandPolicy;
    listen?: boolean;
    getClientToLocal?: GetClientToLocal;
    pressureCapabilityForSource?: (source: WebFreehandSource, event: PointerEvent) => PressureCapability;
    onResult?: (notice: FreehandWebAdapterNotice) => void;
    onTrace?: GestureTraceObserver;
}>;
/** 适配器接口。 */
export interface FreehandWebAdapter {
    destroy(): void;
    dispatch(event: PointerEvent): void;
    cancel(): boolean;
    getActivePointerIds(): readonly number[];
    retryCommit(commitId: string): LayeredEditorResult<LayeredCommitReceipt>;
}
/**
 * 创建 Web 自由笔 adapter。controller 是唯一真源；本函数只做事件归一化、坐标转换与生命周期。
 */
export declare function createFreehandWebAdapter(options: CreateFreehandWebAdapterOptions): FreehandWebAdapter;
//# sourceMappingURL=freehandWebAdapter.d.ts.map