/** Opt-in diagnostics. Entries contain metadata, never document/text/image contents. */
export type GestureTraceEntry = Readonly<{
    scope: 'event' | 'freehand' | 'navigation' | 'semantic' | 'presentation';
    action: string;
    reason?: string;
    pointerId?: number | string;
    source?: string;
    ownerPointerId?: number;
    sessionId?: string;
    commitId?: string;
    objectId?: string;
    tool?: string;
    target?: string;
    timeStamp?: number;
    trusted?: boolean;
    buttons?: number;
    pressure?: number;
    x?: number;
    y?: number;
    movementX?: number;
    movementY?: number;
    coalescedCount?: number;
    samplePointerId?: number;
    sampleSource?: string;
    operating?: boolean;
    destroyed?: boolean;
    destroyRequested?: boolean;
    lastSample?: Readonly<{
        x: number;
        y: number;
        time: number;
        phase: string;
    }>;
    captured?: boolean;
    defaultPrevented?: boolean;
    cancelable?: boolean;
    touchAction?: string;
    sampleCount?: number;
    batchSequence?: number;
    viewportRevision?: number;
    documentRevision?: number;
    pendingCount?: number;
    ok?: boolean;
}>;
export type GestureTraceObserver = (entry: GestureTraceEntry) => void;
export declare function traceGesture(observer: GestureTraceObserver | undefined, entry: GestureTraceEntry): void;
/** Observe before routing, including up outside the host and capture transfer. */
export declare function observeGestureEvents(host: HTMLElement, observer: GestureTraceObserver): () => void;
//# sourceMappingURL=gestureTrace.d.ts.map