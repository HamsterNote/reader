import { type DrawingViewport, type GestureInteractionPolicy, type Point, type TargetRole, type ViewportScaleLimits, type ViewportTransformIntent } from '../../core/internal';
export type ViewportGestureRequest = Readonly<{
    phase: 'preview' | 'commit';
    source: 'wheel' | 'touch' | 'pointer';
    intent: ViewportTransformIntent;
    viewport: DrawingViewport;
}>;
export type ViewportZoomFeedback = Readonly<{
    source: 'wheel' | 'touch' | 'pointer';
    /** 手势当前可见焦点；zoom-only intent 的固定 focal 不可用于触摸反馈定位。 */
    point: Point;
    focal: Point;
    scale: number;
}>;
export type ViewportWheelOptions = Readonly<{
    /** 缺省时启用 wheel；接入方可显式关闭。 */
    enabled?: boolean;
    /** 在读取坐标前过滤 wheel；用于区分普通 wheel zoom、Ctrl zoom 与 trackpad pan。 */
    shouldHandle?: (event: WheelEvent) => boolean;
    /** Ctrl 或 Cmd 才缩放，适配浏览器 pinch-to-wheel 的平台行为。 */
    requireCtrlOrMeta?: boolean;
    /** 将单个 wheel 样本转换为缩放比例；非法比例会安全忽略。 */
    getScaleRatio?: (event: WheelEvent) => number;
    /** 将 wheel 转成平移/缩放 intent 的当前焦点；省略时固定 focal zoom。 */
    getCurrentFocal?: (event: WheelEvent, focal: Point) => Point;
}>;
export type ViewportGestureControllerOptions = Readonly<{
    host: HTMLElement;
    listenerTarget: EventTarget;
    getRenderedViewport: () => DrawingViewport | null;
    scaleLimits?: ViewportScaleLimits;
    interactionPolicy?: GestureInteractionPolicy;
    /** 只在 pointerdown 调用，返回的角色会由 core 锁定到该 pointer 的生命周期结束。 */
    getTargetRole: (event: PointerEvent, point: Point) => TargetRole;
    toLocalPoint: (event: PointerEvent | WheelEvent) => Point;
    onViewportRequest: (request: ViewportGestureRequest) => void;
    onZoomFeedback?: (feedback: ViewportZoomFeedback | null) => void;
    onActiveChange?: (active: boolean) => void;
    wheel?: ViewportWheelOptions;
}>;
export type ViewportGestureController = Readonly<{
    cancel: () => void;
    dispose: () => void;
}>;
/**
 * legacy DOM viewport 接缝：DOM 只负责输入生命周期、capture 与 ownership gate。所有 pointer
 * 手势的导航 intent 都由 core GestureSession 产生，再以手势开始时的 rendered viewport 为基准
 * 应用。它不接入任何渲染 Frame，也不会维护未经 controlled 父级确认的 viewport truth。
 */
export declare function createViewportGestureController(options: ViewportGestureControllerOptions): ViewportGestureController;
//# sourceMappingURL=viewportGestureController.d.ts.map