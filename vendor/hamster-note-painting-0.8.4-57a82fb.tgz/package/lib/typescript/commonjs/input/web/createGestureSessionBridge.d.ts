import { type GestureSession, type GestureSessionEffect, type NormalizedPointerInput } from '../../core/internal';
export type GestureSessionBridge = Readonly<{
    handleInput: (input: NormalizedPointerInput) => void;
    getSession: () => GestureSession;
    reset: () => void;
}>;
export type CreateGestureSessionBridgeOptions = Readonly<{
    createSession: () => GestureSession;
    onEffects?: (effects: readonly GestureSessionEffect[]) => void;
}>;
/**
 * 将已规范化的输入顺序交给纯 core session。它不导入 DOM；为使 reset 能安全结束每一个
 * owner，保留每个 pointer 最后的完整样本并把该样本改写为 cancel 后再交给 reducer。
 */
export declare function createGestureSessionBridge(options: CreateGestureSessionBridgeOptions): GestureSessionBridge;
//# sourceMappingURL=createGestureSessionBridge.d.ts.map