import type { NormalizedPointerInput, Point, TargetRole } from '../../core/internal';
export type NormalizePointerInputOptions = Readonly<{
    host: HTMLElement;
    now?: () => number;
    /** legacy capture 接缝已完成 content-box 转换时传入，避免重复读取/解释 DOM rect。 */
    point?: Point;
    /** 手势 controller 在 down-time 完成业务命中后可传入明确 core role。 */
    targetRole?: TargetRole | unknown;
    /** lost capture 等非标准 DOM 生命周期可安全映射为既有 core phase。 */
    phase?: NormalizedPointerInput['phase'];
    resolveTargetRole?: (eventTarget: EventTarget | null, host: HTMLElement) => TargetRole | unknown;
}>;
/**
 * 提取不依赖 DOM 事件对象的 core 输入。任何不能完整表达为 `NormalizedPointerInput` 的平台
 * 样本都被拒绝，而不是以猜测值进入 reducer。
 */
export declare function normalizePointerInput(event: PointerEvent, options: NormalizePointerInputOptions): NormalizedPointerInput | null;
//# sourceMappingURL=normalizePointerInput.d.ts.map