export * from './freehandWebAdapter';
//# sourceMappingURL=index.d.ts.map