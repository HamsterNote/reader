import type { TargetRole } from '../../core/internal';
/**
 * 将宿主内 DOM 命中转换为 core 的有限角色集合。
 *
 * 优先级刻意固定：尺子覆盖选框与安全控件，选框覆盖其内部可能出现的交互元素；只有宿主内
 * 且未命中这些对象的位置才是 paper。非 Element（例如 Text 节点）不做猜测。
 */
export declare function resolveTargetRole(eventTarget: EventTarget | null, host: HTMLElement): TargetRole;
//# sourceMappingURL=resolveTargetRole.d.ts.map