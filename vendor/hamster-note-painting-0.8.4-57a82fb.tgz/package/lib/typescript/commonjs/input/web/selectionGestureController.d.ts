import { type SelectionGestureDescriptor, type SelectionIntent } from '../../core/internal';
import type { Point } from '../../core/input';
export type SelectionGestureControllerOptions = Readonly<{
    host: HTMLElement;
    listenerTarget: EventTarget;
    toLocalPoint: (event: PointerEvent) => Point;
    /** 返回 null 即不接管，调用方在此复用工具、输入方法、owner 与 ruler 命中 gate。 */
    describe: (event: PointerEvent, point: Point) => SelectionGestureDescriptor | null;
    onPreview: (intent: SelectionIntent) => void;
    onCommit: (intent: SelectionIntent) => void;
    onStart: () => void;
    onEnd: (committed: boolean) => void;
}>;
export type SelectionGestureController = Readonly<{
    cancel: () => void;
    dispose: () => void;
}>;
/**
 * legacy DOM 选区接缝：只执行 capture 分类、宿主本地 DIP 转换和 pointer lifecycle；所有
 * move/resize/rotate intent 均由 core GestureSession 推导。它不伪造事件也不调用 multi-drag。
 */
export declare function createSelectionGestureController(options: SelectionGestureControllerOptions): SelectionGestureController;
//# sourceMappingURL=selectionGestureController.d.ts.map