export type PointerInputController = {
    destroy: () => void;
    getActivePointerCount: () => number;
};
export declare function createPointerInputController(element: HTMLElement): PointerInputController;
//# sourceMappingURL=pointerInputController.d.ts.map