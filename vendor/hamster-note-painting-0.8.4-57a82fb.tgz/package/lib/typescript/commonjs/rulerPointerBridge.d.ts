type RulerPointerBridgeOptions = {
    readonly listenerTarget: EventTarget;
    readonly onPointerDown: (event: PointerEvent) => void;
};
export declare function installCapturePhaseRulerPointerBridge(options: RulerPointerBridgeOptions): () => void;
export {};
//# sourceMappingURL=rulerPointerBridge.d.ts.map