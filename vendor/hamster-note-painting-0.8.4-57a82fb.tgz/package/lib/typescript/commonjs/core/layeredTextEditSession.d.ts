/**
 * 纯文本编辑会话状态机（layered text edit session）。
 *
 * 职责边界：唯一 owner 是会话本身，不持有 document / history / DOM / V2 / Skia；只 import
 * model/document.ts 的 Bounds / AffineTransform 类型并自行白名单校验；不做 controller 创建
 * 对象、allocator、DOM focus 或真实 IME。所有方法返回 Result，预期错误绝不 throw，失败不产生
 * 任何 mutation；输入永不被改写，begin/draft/target/candidate/snapshot 均深拷贝并冻结；
 * content 不做 trim / 规范化。
 *
 * 提交反馈约定：noop 与 delete 不产生新 objectId/revision 需求——noop 回执 id/rev 均为 null，
 * delete 回执携带既有 id 但 objectRevision 为 null；create/update 遵循单事务 +1 修订约定。
 */
import type { AffineTransform, Bounds } from '../model/document';
/** 会话内可替换的完整文字草稿；四个字段必填。 */
export type LayeredTextEditDraft = Readonly<{
    content: string;
    fontSize: number;
    color: string;
    localBounds: Bounds;
}>;
/** 草稿增量更新；只允许出现已定义的 known 字段。 */
export type LayeredTextEditDraftUpdate = Partial<LayeredTextEditDraft>;
/** 新建文字对象目标：锁定期望文档修订与初值变换。 */
type NewTarget = Readonly<{
    kind: 'new';
    expectedDocumentRevision: number;
    transform: AffineTransform;
}>;
/** 编辑既有文字对象目标：锁定期望文档修订与对象身份/修订。 */
type ExistingTarget = Readonly<{
    kind: 'existing';
    expectedDocumentRevision: number;
    objectId: string;
    expectedObjectRevision: number;
}>;
/** 文字编辑目标联合。 */
export type LayeredTextEditTarget = NewTarget | ExistingTarget;
/** 冻结候选：noop / create / update / delete；每个候选都携带其目标，便于 controller 校验文档修订。 */
export type LayeredTextEditCandidate = Readonly<{
    kind: 'noop';
    target: NewTarget;
}> | Readonly<{
    kind: 'create';
    target: NewTarget;
    draft: LayeredTextEditDraft;
}> | Readonly<{
    kind: 'update';
    target: ExistingTarget;
    draft: LayeredTextEditDraft;
}> | Readonly<{
    kind: 'delete';
    target: ExistingTarget;
}>;
/** 提交失败原因。 */
type CommitFailureReason = 'stale-target' | 'allocation-failed' | 'revision-exhausted' | 'internal';
/** 会话提交反馈：失败原因或成功回执。 */
export type LayeredTextEditFeedback = Readonly<{
    type: 'commit-failed';
    reason: CommitFailureReason;
}> | Readonly<{
    type: 'commit-succeeded';
    documentRevision: number;
    objectId: string | null;
    objectRevision: number | null;
}>;
/** 会话只读快照。 */
export type LayeredTextEditSnapshot = Readonly<{
    status: 'editing' | 'awaiting-commit' | 'committed' | 'canceled';
    target: LayeredTextEditTarget;
    draft: LayeredTextEditDraft;
    isComposing: boolean;
    commitRequested: boolean;
    candidate: LayeredTextEditCandidate | null;
}>;
/** 会话预期错误码。 */
export type LayeredTextEditErrorCode = 'invalid-input' | 'session-finalized' | 'composition-inactive' | 'candidate-not-ready' | 'feedback-mismatch';
/** 会话结果：成功携带值，失败携带错误码。 */
export type LayeredTextEditResult<T> = Readonly<{
    ok: true;
    value: T;
}> | Readonly<{
    ok: false;
    error: Readonly<{
        code: LayeredTextEditErrorCode;
    }>;
}>;
/** 文本编辑会话接口；实现由 beginLayeredTextEditSession 返回。 */
export interface LayeredTextEditSession {
    getSnapshot(): LayeredTextEditSnapshot;
    updateDraft(update: LayeredTextEditDraftUpdate): LayeredTextEditResult<void>;
    startComposition(): LayeredTextEditResult<void>;
    endComposition(finalUpdate: LayeredTextEditDraftUpdate & {
        content: string;
    }): LayeredTextEditResult<void>;
    requestCommit(): LayeredTextEditResult<void>;
    getCandidate(): LayeredTextEditResult<LayeredTextEditCandidate>;
    cancel(): LayeredTextEditResult<void>;
    applyCommitFeedback(feedback: LayeredTextEditFeedback): LayeredTextEditResult<void>;
}
/** 开始纯文字编辑会话；target/draft 非法时返回 invalid-input Result（不 throw、不创建会话）。 */
export declare function beginLayeredTextEditSession(target: LayeredTextEditTarget, draft: LayeredTextEditDraft): LayeredTextEditResult<LayeredTextEditSession>;
export {};
//# sourceMappingURL=layeredTextEditSession.d.ts.map