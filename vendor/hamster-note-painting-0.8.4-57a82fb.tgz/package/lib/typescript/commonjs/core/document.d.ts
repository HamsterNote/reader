import { type DrawingStrokeV2, type DrawingValueV2 } from '../model/strokes';
/**
 * 读取持久化绘图数据时发现的非致命问题。
 *
 * core 不拒绝读取未知数据，以便宿主能够展示或记录诊断；返回的 document 始终是
 * 可由当前 V2 core 使用的规范化副本。
 */
export type DrawingDocumentDiagnostic = Readonly<{
    type: 'unsupported-schema-version';
    schemaVersion: unknown;
}>;
/** V2 文档读取结果。diagnostics 不可变，且不会包含输入对象的引用。 */
export type ReadDrawingDocumentResult = Readonly<{
    document: DrawingValueV2;
    diagnostics: readonly DrawingDocumentDiagnostic[];
}>;
/**
 * 将任意持久化输入读取为当前唯一支持的 V2 文档。
 *
 * 缺失 schemaVersion 的旧 V1 数据以及显式 V2 数据都会交给既有迁移器处理，且绝不
 * 修改输入。显式的非 V2 版本仍会得到安全的 V2 规范化结果，但同时产生诊断，防止
 * 调用方将未来版本误认为 V1 而静默降级。
 */
export declare function readDrawingDocument(input: unknown): ReadDrawingDocumentResult;
/**
 * 在文档末尾追加一条 V2 笔迹，不改变原 document 或 strokes 数组。
 *
 * ID 可以重复：本模块将重复 ID 视为有序条目；仅 update/remove 会命中从前到后的第一条。
 */
export declare function addStroke(document: DrawingValueV2, stroke: DrawingStrokeV2): DrawingValueV2;
/**
 * 以 V2 笔迹替换其同 ID 的第一条现有笔迹，并保持其余笔迹的相对顺序。
 * 未找到目标时返回原 document 引用。
 */
export declare function updateStroke(document: DrawingValueV2, stroke: DrawingStrokeV2): DrawingValueV2;
/**
 * 删除指定 ID 的第一条笔迹，并保持其余笔迹顺序。
 * 未找到目标时返回原 document 引用。
 */
export declare function removeStroke(document: DrawingValueV2, id: string): DrawingValueV2;
/**
 * 清空文档中的笔迹。已经为空的文档无需产生新对象，直接保留原 document 引用。
 */
export declare function clearStrokes(document: DrawingValueV2): DrawingValueV2;
//# sourceMappingURL=document.d.ts.map