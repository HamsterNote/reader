import type { DocumentStrokeTarget } from './selectionTransform';
import type { DrawingValueV2 } from '../model/strokes';
/** 多选框是所选 stroke 保守世界 AABB 的并集，不是随内容旋转的 OBB。 */
export type SelectionFrame = Readonly<{
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
    width: number;
    height: number;
}>;
/** 退化 path 也需要可拖动的世界选框；screen handle 尺寸不会改变这个 document anchor。 */
export declare const MINIMUM_SELECTION_FRAME_EXTENT = 1;
/**
 * 根据已冻结的 index/id/tool targets 派生保守 world AABB。任意 stale、重复或无几何 target
 * 都返回 null，避免候选 UI 为与可提交集合不同的一组 stroke 绘制选框。
 */
export declare function deriveSelectionFrame(document: DrawingValueV2, targets: readonly DocumentStrokeTarget[]): SelectionFrame | null;
//# sourceMappingURL=selectionFrame.d.ts.map