import { type NormalizedPointerInput, type Point } from '../input';
import { type PointerOwnershipState } from './ownership';
import { type ViewportTransformIntent } from '../viewportTransform';
import type { DrawingPointV2, DrawingStrokeV2, DrawingToolModeV2, DrawingValueV2 } from '../../model/strokes';
/** GestureSession 当前仅真正提交 `pen`；其他既有工具会保留安全的无操作会话，不会假装已支持。 */
export type GestureSessionTool = DrawingToolModeV2;
/** 纯交互策略，不复用 legacy 组件的 options 类型。 */
export type GestureInteractionPolicy = Readonly<{
    singleTouch?: 'draw' | 'pan' | 'none';
    /** 默认 `pan-zoom`，与 legacy SAFE 的纸面双指平移加缩放语义兼容。 */
    twoTouch?: 'none' | 'pan' | 'zoom' | 'pan-zoom';
    mouseDragPan?: boolean;
    penPan?: boolean;
    /** 最小有效绘制距离，单位为宿主局部 DIP；仅显式提供时启用。 */
    drawCommitThreshold?: number;
}>;
type ResolvedGestureInteractionPolicy = Readonly<{
    singleTouch: 'draw' | 'pan' | 'none';
    twoTouch: 'none' | 'pan' | 'zoom' | 'pan-zoom';
    mouseDragPan: boolean;
    penPan: boolean;
    drawCommitThreshold: number | null;
}>;
/** 不依赖 viewport 或平台对象的尺子位姿。 */
export type GestureRulerState = Readonly<{
    center: Point;
    rotationRad: number;
}>;
/** 选框的纯几何描述；其中坐标与输入 `screen` 同为宿主局部 DIP。 */
export type SelectionBox = Readonly<{
    center: Point;
    width: number;
    height: number;
    rotationRad: number;
}>;
/** 由 adapter 的命中结果构造的选区手势，不包含元素、回调或 legacy selection 类型。 */
export type SelectionGestureDescriptor = Readonly<{
    kind: 'move';
    box: SelectionBox;
}> | Readonly<{
    /** 四个角手柄专用的等比缩放；所有字段均为 screen DIP。 */
    kind: 'uniform-scale';
    box: SelectionBox;
    /** 与被抓取的角手柄相对的固定角。 */
    anchor: Point;
    /** 手势开始前被抓取角手柄的稳定位置。 */
    handle: Point;
    /** 选框两条轴都不能低于的屏幕 DIP 尺寸。 */
    minimumScreenExtent?: number;
}> | Readonly<{
    kind: 'resize';
    box: SelectionBox;
    /** 不随拖动变化的对角锚点。 */
    anchor: Point;
    /** 被抓取手柄相对锚点的稳定象限。 */
    axis: Readonly<{
        x: -1 | 1;
        y: -1 | 1;
    }>;
    minimumSize?: number;
}> | Readonly<{
    kind: 'rotate';
    box: SelectionBox;
    pivot?: Point;
}>;
/** 由调用者提供的稳定笔迹构造器；不得依赖随机数或平台对象。 */
export type PenStrokeFactory = (request: Readonly<{
    pointerId: NormalizedPointerInput['pointerId'];
    points: readonly DrawingPointV2[];
    startedAt: number;
}>) => DrawingStrokeV2 | null;
/** 构造纯 GestureSession 时注入的静态领域数据。 */
export type CreateGestureSessionOptions = Readonly<{
    document: DrawingValueV2;
    tool?: GestureSessionTool;
    createPenStroke?: PenStrokeFactory;
    /** 缺失时 ruler owner 是显式安全 no-op，而非猜测尺子位置。 */
    ruler?: Readonly<{
        state: GestureRulerState;
        pivot?: Point;
    }>;
    /** adapter 在 selection down 前构造；本阶段不在 core 中进行命中或 document 变形。 */
    selection?: SelectionGestureDescriptor;
    interactionPolicy?: GestureInteractionPolicy;
}>;
export type GestureSessionStatus = 'idle' | 'active' | 'completed' | 'cancelled' | 'failed';
export type PaperGestureState = Readonly<{
    kind: 'pending-single';
    pointerId: string | number;
}> | Readonly<{
    kind: 'drawing';
    pointerId: string | number;
    points: readonly DrawingPointV2[];
}> | Readonly<{
    kind: 'navigating-single';
    pointerId: string | number;
}> | Readonly<{
    kind: 'navigating-two';
    pointerIds: readonly [string | number, string | number];
}> | Readonly<{
    kind: 'unsupported';
    pointerId: string | number;
    tool: GestureSessionTool;
}>;
export type NavigationPreview = Readonly<{
    pointerIds: readonly (string | number)[];
    startMidpoint: Point;
    currentMidpoint: Point;
    midpointDelta: Point;
    scaleRatio: number;
    intent: ViewportTransformIntent;
}>;
export type RulerPreview = Readonly<{
    pointerIds: readonly (string | number)[];
    state: GestureRulerState;
}>;
export type SelectionIntent = Readonly<{
    kind: 'move';
    delta: Point;
}> | Readonly<{
    kind: 'resize';
    anchor: Point;
    axis: Readonly<{
        x: -1 | 1;
        y: -1 | 1;
    }>;
    scale: Readonly<{
        x: number;
        y: number;
    }>;
}> | Readonly<{
    kind: 'rotate';
    pivot: Point;
    deltaRad: number;
}>;
/** 新选框手势使用的标量缩放语义，刻意不复用旧 `resize: { x, y }`。 */
export type UniformScaleSelectionIntent = Readonly<{
    kind: 'uniform-scale';
    anchor: Point;
    scale: number;
}>;
/** GestureSession 的 transient/effect 可包含新 scalar intent；旧 UI 类型仍是 SelectionIntent。 */
export type SelectionGestureIntent = SelectionIntent | UniformScaleSelectionIntent;
/** 高频预览。所有字段均不写入 `document`，也绝不代表 history 提交。 */
export type GestureTransientState = Readonly<{
    paper?: PaperGestureState;
    navigation?: NavigationPreview;
    ruler?: RulerPreview;
    /** 旧 selection transient 兼容接口；uniform-scale 在 `uniformScaleSelection` 中单独暴露。 */
    selection?: SelectionIntent;
    uniformScaleSelection?: UniformScaleSelectionIntent;
}>;
/** selection 的最终语义必须由后续 3/4 接缝原子应用到 V2 document，不能被当成 document commit。 */
export type GestureSessionEffect = Readonly<{
    type: 'document-commit';
    document: DrawingValueV2;
}> | Readonly<{
    type: 'selection-commit';
    intent: SelectionIntent;
}> | Readonly<{
    type: 'uniform-scale-commit';
    intent: UniformScaleSelectionIntent;
}> | Readonly<{
    type: 'ruler-complete';
    state: GestureRulerState;
}>;
type Position = Readonly<{
    pointerId: string | number;
    point: Point;
}>;
type PaperRuntime = Readonly<{
    kind: 'pending-single';
    pointerId: string | number;
    device: NormalizedPointerInput['device'];
    start: DrawingPointV2;
    startedAt: number;
    behavior: 'draw' | 'pan' | 'none';
}> | Readonly<{
    kind: 'drawing';
    pointerId: string | number;
    points: readonly DrawingPointV2[];
    startedAt: number;
}> | Readonly<{
    kind: 'navigating-single';
    pointerId: string | number;
    start: Position;
    current: Position;
}> | Readonly<{
    kind: 'navigating-two';
    pointerIds: readonly [string | number, string | number];
    start: readonly [Position, Position];
    current: readonly [Position, Position];
    behavior: 'pan' | 'zoom' | 'pan-zoom';
}> | Readonly<{
    kind: 'unsupported';
    pointerId: string | number;
    tool: GestureSessionTool;
}>;
type RulerRuntime = Readonly<{
    kind: 'mouse-translate';
    pointerId: string | number;
    initial: GestureRulerState;
    current: GestureRulerState;
    grabOffset: Point;
}> | Readonly<{
    kind: 'mouse-rotate';
    pointerId: string | number;
    initial: GestureRulerState;
    current: GestureRulerState;
    pivot: Point;
    startAngle: number;
}> | Readonly<{
    kind: 'touch-wait';
    pointerId: string | number;
    start: Point;
}> | Readonly<{
    kind: 'touch-pair';
    pointerIds: readonly [string | number, string | number];
    initial: GestureRulerState;
    start: readonly [Position, Position];
    current: readonly [Position, Position];
}>;
type SelectionRuntime = Readonly<{
    pointerId: string | number;
    descriptor: SelectionGestureDescriptor;
    start: Point;
    /** pointer 相对原始手柄的偏移，避免按在放大命中区内时跳变。 */
    grabOffset: Point;
    intent: SelectionGestureIntent;
}>;
/**
 * 平台无关的领域手势状态。调用方以替换整个值的方式使用，内部数组与预览都冻结。
 * `status` 表示最近可观察的生命周期结果；并发 owner 尚有活跃会话时始终为 `active`。
 */
export type GestureSession = Readonly<{
    document: DrawingValueV2;
    ownership: PointerOwnershipState;
    tool: GestureSessionTool;
    paper: PaperRuntime | null;
    ruler: RulerRuntime | null;
    selection: SelectionRuntime | null;
    transient: GestureTransientState;
    status: GestureSessionStatus;
    createPenStroke?: PenStrokeFactory;
    rulerOptions?: Readonly<{
        state: GestureRulerState;
        pivot?: Point;
    }>;
    selectionDescriptor?: SelectionGestureDescriptor;
    interactionPolicy: ResolvedGestureInteractionPolicy;
}>;
export type GestureSessionTransition = Readonly<{
    session: GestureSession;
    effects: readonly GestureSessionEffect[];
}>;
/**
 * 创建无副作用 GestureSession。它不持有平台对象，也不主动写 document/history；调用方只需把
 * 每个规范化样本依次交给 `reduceGestureSession`，并在收到 `document-commit` 时执行持久化。
 *
 * 选区最终只发 `selection-commit`：当前 core 没有可安全变形所有 V2 stroke 的公共操作，后续
 * 3/4 接缝必须把该 immutable intent 原子应用为唯一 `document-commit`，不能把预览当作提交。
 */
export declare function createGestureSession(options: CreateGestureSessionOptions): GestureSession;
/** 单步消费一个规范化 pointer 样本。无效、重复或未知生命周期不会抛出，也不会产生错误提交。 */
export declare function reduceGestureSession(session: GestureSession, input: unknown): GestureSessionTransition;
export {};
//# sourceMappingURL=session.d.ts.map