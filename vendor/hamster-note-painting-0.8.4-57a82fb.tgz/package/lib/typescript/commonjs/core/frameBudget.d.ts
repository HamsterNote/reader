import type { GeometryPoint } from './geometry';
import type { FrameGeometryProgram, FrameLocalClipRegion, FrameResourceBoxFragment, FrameTextProgram } from './frameClipping';
import type { Affine2D } from '../viewport';
/**
 * 单帧送入绘制后端的数值上限。这个边界同时约束 local program 和 local->screen
 * 仿射计算，避免某一层只验证几何而把样式、资源或矩阵溢出留给 Skia。
 */
export type FrameDrawBudget = Readonly<{
    maxCoordinate: number;
    localToScreen: Affine2D;
}>;
export type DrawStyleNumbers = Readonly<{
    strokeWidth: number;
    fillOpacity: number;
    dashArray?: readonly number[];
    dashOffset: number;
}>;
export declare function createFrameDrawBudget(maxCoordinate: number, localToScreen: Affine2D): FrameDrawBudget | null;
/** 兼容入口不拥有 frame 时使用同一套纯数值边界，而不是把未验证值交给 Skia。 */
export declare function createLegacyDrawBudget(maxCoordinate?: number): FrameDrawBudget;
export declare function isDrawNumber(value: number, budget: FrameDrawBudget): boolean;
export declare function isDrawPoint(point: GeometryPoint, budget: FrameDrawBudget): boolean;
export declare function isScreenPointForFrame(point: GeometryPoint, budget: FrameDrawBudget): boolean;
export declare function isDrawClip(clip: FrameLocalClipRegion, budget: FrameDrawBudget): boolean;
export declare function isDrawDash(dashArray: readonly number[] | undefined, dashOffset: number, budget: FrameDrawBudget): boolean;
/** 原始 dash 输入的范围 gate；格式无效时可由 adapter 安全地降级为无 dash。 */
export declare function isDrawDashInput(dashArray: readonly number[] | undefined, dashOffset: number, budget: FrameDrawBudget): boolean;
export declare function isDrawStyle(style: DrawStyleNumbers, budget: FrameDrawBudget): boolean;
export declare function isDrawResourceBox(fragment: FrameResourceBoxFragment, budget: FrameDrawBudget): boolean;
/** 文本 program 的锚点、绘制偏移、glyph 坐标与命中语义区域都必须经过同一最终预算。 */
export declare function isFrameTextProgramWithinBudget(program: FrameTextProgram, budget: FrameDrawBudget): boolean;
export declare function isFrameProgramWithinBudget(program: FrameGeometryProgram, budget: FrameDrawBudget): boolean;
//# sourceMappingURL=frameBudget.d.ts.map