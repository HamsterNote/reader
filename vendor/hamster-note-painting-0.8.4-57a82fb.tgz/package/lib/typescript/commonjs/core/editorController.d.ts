import type { DrawingPointV2, DrawingStrokeV2, DrawingToolModeV2, DrawingValueV2 } from '../model/strokes';
import { type CreateEditorInteractionOptions, type EditorInteractionDiagnostic, type EditorInteractionState } from './editorInteraction';
import { type EditorToolCreateId, type EditorToolSession, type EditorToolSessionDiagnostic, type EditorToolStrokeStyle } from './editorToolSession';
import type { EditorRuntimeDiagnostic } from './editorRuntime';
import type { DrawingFrame } from './drawingFrame';
import type { EditorDocumentCommand } from './editorDocument';
import type { NormalizedPointerInput } from './input';
import { type DrawingFrameQueryCoordinateSpace, type EraserTargetQueryOptions, type SelectionQueryDiagnostic } from './selectionQuery';
import type { DocumentStrokeTarget } from './selectionTransform';
import type { SelectionGestureDescriptor } from './gesture/session';
export type EditorControllerTool = DrawingToolModeV2 | 'image';
export type EditorControllerDiagnostic = EditorInteractionDiagnostic | EditorRuntimeDiagnostic | EditorToolSessionDiagnostic | SelectionQueryDiagnostic | Readonly<{
    type: 'active-interaction-conflict';
}> | Readonly<{
    type: 'no-active-tool-session';
}> | Readonly<{
    type: 'no-tool-candidate';
}> | Readonly<{
    type: 'no-eraser-targets';
}> | Readonly<{
    type: 'frame-document-identity-mismatch';
}>;
export type EditorEraserTransient = Readonly<{
    samples: readonly DrawingPointV2[];
    radius: number;
    topmostOnly: boolean;
}>;
/**
 * 未来 UI 的单一纯 core 协调状态。
 *
 * toolSession/strokeCandidate 仅用于构造和预览；任何持久变化都必须经过 interaction/runtime
 * 的 revision-aware 离散命令。lasso/eraser transient 也仅保存 world-DIP 查询输入。
 */
export type EditorControllerState = Readonly<{
    interaction: EditorInteractionState;
    tool: EditorControllerTool;
    toolStyle: EditorToolStrokeStyle;
    createId?: EditorToolCreateId;
    toolSession?: EditorToolSession;
    strokeCandidate?: DrawingStrokeV2;
    selectionTargets: readonly DocumentStrokeTarget[];
    lassoTransient?: readonly DrawingPointV2[];
    eraserTransient?: EditorEraserTransient;
    diagnostics: readonly EditorControllerDiagnostic[];
}>;
export type CreateEditorControllerOptions = Omit<CreateEditorInteractionOptions, 'tool'> & Readonly<{
    tool?: EditorControllerTool;
    toolStyle?: EditorToolStrokeStyle;
    createId?: EditorToolCreateId;
}>;
export type EditorControllerResult = Readonly<{
    state: EditorControllerState;
    diagnostics: readonly EditorControllerDiagnostic[];
}>;
/** 创建 controller；不会自动提交工具候选，也不会写入持久 document。 */
export declare function createEditorControllerState(document: DrawingValueV2, options?: CreateEditorControllerOptions): EditorControllerState;
/** 切换工具会清除候选与查询 transient；切换过程绝不会写 history。 */
export declare function setEditorControllerTool(state: EditorControllerState, tool: EditorControllerTool): EditorControllerResult;
/** 配置 selection 的稳定目标与可选 gesture descriptor；变换提交仍由 EditorInteraction 完成。 */
export declare function setEditorControllerSelection(state: EditorControllerState, targets: readonly DocumentStrokeTarget[], descriptor?: SelectionGestureDescriptor): EditorControllerResult;
/** 连续工具的 world-DIP down；candidate 必须通过 commitEditorControllerCandidate 显式提交。 */
export declare function beginEditorControllerToolPointer(state: EditorControllerState, point: DrawingPointV2): EditorControllerResult;
/** 连续工具的 world-DIP move；不会写 document/history。 */
export declare function moveEditorControllerToolPointer(state: EditorControllerState, point: DrawingPointV2): EditorControllerResult;
/** 连续工具的 world-DIP up；完成后仅保留 strokeCandidate，不会自动提交。 */
export declare function finishEditorControllerToolPointer(state: EditorControllerState, point: DrawingPointV2): EditorControllerResult;
/** polygon/bezier 的显式 world-DIP 顶点/控制点入口。 */
export declare function addEditorControllerToolVertex(state: EditorControllerState, point: DrawingPointV2): EditorControllerResult;
/** 完成 polygon，仅产生候选 stroke。 */
export declare function finishEditorControllerPolygon(state: EditorControllerState): EditorControllerResult;
/** 完成 Bézier，仅产生候选 stroke。 */
export declare function finishEditorControllerBezier(state: EditorControllerState): EditorControllerResult;
/** 取消工具构造及查询 transient；取消从不提交 document/history。 */
export declare function cancelEditorControllerTool(state: EditorControllerState): EditorControllerResult;
/**
 * 将候选笔迹作为一条 revision-aware append 命令提交。expectedRevision 用于让 UI 以显式的
 * optimistic revision 检测陈旧候选；缺省为当前 runtime revision。
 */
export declare function commitEditorControllerCandidate(state: EditorControllerState, expectedRevision?: number): EditorControllerResult;
/**
 * controller 的唯一离散 document 写入口，供文本删除、替换、clear 等非手势 producer 使用。
 * 具体 selection 生命周期由 interaction 统一处理，避免 UI 仅隐藏失效的选框。
 */
export declare function commitEditorControllerDocumentCommand(state: EditorControllerState, command: EditorDocumentCommand): EditorControllerResult;
/** 将 text session 等核心 producer 的完整 snapshot 接入统一的 selection 生命周期。 */
export declare function commitEditorControllerDocument(state: EditorControllerState, expectedRevision: number, document: DrawingValueV2): EditorControllerResult;
/** 仅查询 lasso 并更新稳定 selection targets；查询过程绝不写 history。 */
export declare function queryEditorControllerLasso(state: EditorControllerState, polygon: readonly DrawingPointV2[]): EditorControllerResult;
/** 仅查询 eraser 轨迹并更新稳定 targets；topmostOnly 完全遵循 selectionQuery 语义。 */
export declare function queryEditorControllerEraser(state: EditorControllerState, samples: readonly DrawingPointV2[], radius: number, options?: EraserTargetQueryOptions): EditorControllerResult;
/**
 * 供候选 UI 使用的 frame-only lasso 入口。frameRevision 必须是构建该 frame 时读取的 runtime
 * revision；此外 controller 会核对 prepared snapshot 与当前冻结 document 的值身份，避免同 revision
 * 的异源 frame 被误用于 selection 或后续删除。
 */
export declare function queryEditorControllerDrawingFrameLasso(state: EditorControllerState, frame: DrawingFrame, frameRevision: number, polygon: readonly DrawingPointV2[], coordinateSpace?: DrawingFrameQueryCoordinateSpace): EditorControllerResult;
/** frame-only 连续橡皮入口；topmostOnly 与 legacy query 相同，删除仍需显式 commit。 */
export declare function queryEditorControllerDrawingFrameEraser(state: EditorControllerState, frame: DrawingFrame, frameRevision: number, samples: readonly DrawingPointV2[], radius: number, options?: EraserTargetQueryOptions & Readonly<{
    coordinateSpace?: DrawingFrameQueryCoordinateSpace;
}>): EditorControllerResult;
/** 将当前 eraser query targets 删除为一条原子 runtime history 提交；空 target 不写 history。 */
export declare function commitEditorControllerEraser(state: EditorControllerState, expectedRevision?: number): EditorControllerResult;
/** 仅代理既有 EditorInteraction 的 GestureSession 开始逻辑，不复制手势数学。 */
export declare function beginEditorControllerGesture(state: EditorControllerState): EditorControllerResult;
/** 仅代理既有 EditorInteraction 的 normalized pointer reducer，不复制手势数学。 */
export declare function reduceEditorControllerGesture(state: EditorControllerState, input: NormalizedPointerInput): EditorControllerResult;
/** controller 层的 undo 入口；真实回退后 selection 必须一并清空。 */
export declare function undoEditorController(state: EditorControllerState): EditorControllerResult;
/** controller 层的 redo 入口；真实重放后 selection 必须一并清空。 */
export declare function redoEditorController(state: EditorControllerState): EditorControllerResult;
//# sourceMappingURL=editorController.d.ts.map