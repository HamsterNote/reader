import type { NormalizedPointerInput } from './input';
import { type PointerOwnershipState } from './gesture/ownership';
import type { LayeredInputSnapshot } from './layeredInputMode';
type Pointer = NormalizedPointerInput;
export type LayeredInputGesture = Readonly<{
    kind: 'single-tool' | 'pen-tool' | 'single-pan' | 'touch-pair';
    ids: readonly (string | number)[];
}>;
type Target = 'tool' | 'navigation';
export type LayeredInputResetReason = 'policy' | 'lifecycle';
export type LayeredInputIntent = {
    type: 'detect-pen';
} | {
    type: 'cancel';
    target: Target;
    reason?: LayeredInputResetReason;
} | {
    type: 'route';
    target: Target;
    input: Pointer;
} | {
    type: 'begin-navigation';
    pointers: readonly Pointer[];
};
export type LayeredInputArbitration = Readonly<{
    ownership: PointerOwnershipState;
    contacts: readonly Pointer[];
    suppressed: readonly (string | number)[];
    draining: boolean;
    gesture?: LayeredInputGesture;
    pending?: {
        gesture: LayeredInputGesture;
        input?: Pointer;
    };
}>;
export type LayeredInputArbitrationEvent = {
    type: 'pointer';
    input: Pointer;
    policy: LayeredInputSnapshot;
    panTool: boolean;
} | {
    type: 'cancel-result';
    ok: boolean;
} | {
    type: 'reset';
    reason?: LayeredInputResetReason;
};
export declare function createLayeredInputArbitration(): LayeredInputArbitration;
/** Cancellation is a handshake: no navigation intent exists before an affirmative ACK. */
export declare function reduceLayeredInputArbitration(state: LayeredInputArbitration, event: LayeredInputArbitrationEvent): {
    state: LayeredInputArbitration;
    intents: readonly LayeredInputIntent[];
};
export {};
//# sourceMappingURL=layeredInputArbitration.d.ts.map