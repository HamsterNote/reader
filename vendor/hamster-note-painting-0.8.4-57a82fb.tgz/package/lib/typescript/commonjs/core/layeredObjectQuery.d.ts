/**
 * 分层对象几何查询（Task 5.2–5.4 后续基础）
 *
 * 只读 prepared + 世界坐标 point/sweep/lasso 查询。不是 docstore / cache framework：
 * `prepareLayeredObjectQuery` 用共享 `readLayeredDocument` 做完整 schema3 白名单校验，
 * 再把每个对象的**真实**几何（PF final 轮廓、image/text 精确四边形、shape 中心线粗描边并集）
 * 编译为世界多边形 pieces，供查询逐个命中。
 *
 * 依赖仅：`model/document`、`model/documentReader`、共享 geometry
 * (affine/adaptiveContour/shape/worldBounds/freehandCache)、pure `./polygonBoolean` 与现有
 * `polyclip-ts`（union/intersection/difference）。无 DOM / V2 runtime / Skia / 新依赖。
 *
 * 语义要点：
 * - nonzero filled；PF 用 `cache.getPresentation(...,'final').transformedPolygon`，无中心线 fallback。
 * - shape 用未 dash 的连续中心线 + local 半宽圆帽/圆连接；**绝不**用 σmax 圆盘放大半径。
 * - shape 统一 errorMargin=.25（中心线 .125 + 帽 .125），contains 额外 .25 clearance；
 *   image/text/PF margin=0 精确 polygon。
 * - 失败原子且不 partial；数值溢出/环布尔异常 → geometry-failed，绝不降级为空/假阴性。
 */
import type { Bounds, DocumentObject, EditorDocument, Point } from '../model/document';
import type { FreehandGeometryCache } from '../geometry/freehandCache';
import { type PolygonBooleanMultiPolygon } from './polygonBoolean';
/** 查询错误码。 */
export type LayeredObjectQueryErrorCode = 'invalid-input' | 'invalid-document' | 'geometry-failed' | 'budget-exceeded';
/** 统一 Result；value/error 只读。 */
export type LayeredObjectQueryResult<T> = Readonly<{
    ok: true;
    value: T;
}> | Readonly<{
    ok: false;
    error: Readonly<{
        code: LayeredObjectQueryErrorCode;
    }>;
}>;
/** 命中记录（升序 order）；不携带遮挡信息。 */
export type LayeredObjectQueryHit = Readonly<{
    objectId: string;
    objectRevision: number;
    transformRevision: number;
    kind: DocumentObject['kind'];
    order: number;
}>;
/** 预处理后的只读查询快照；不含 document/history，不可变。 */
export type PreparedLayeredObjectQuery = Readonly<{
    documentRevision: number;
    entries: readonly PreparedEntry[];
}>;
/** 单个 occupied piece：一组世界多边形（stroke 矩形/圆盘或 fill 区域）。 */
type PreparedPiece = Readonly<{
    polygons: PolygonBooleanMultiPolygon;
}>;
/** 单个对象的预处理条目（私有派生类型）。 */
type PreparedEntry = Readonly<{
    objectId: string;
    objectRevision: number;
    transformRevision: number;
    kind: DocumentObject['kind'];
    order: number;
    /** 命中误差 margin：shape=.25，其它=0。 */
    margin: number;
    pieces: readonly PreparedPiece[];
    broadphase: Bounds;
}>;
/**
 * 预处理：完整 schema3 校验 + 逐对象原子编译几何。
 * 任一对象非法 → invalid-document；几何/缓存失败 → geometry-failed；预算 → budget-exceeded。
 */
export declare function prepareLayeredObjectQuery(document: EditorDocument, cache: FreehandGeometryCache): LayeredObjectQueryResult<PreparedLayeredObjectQuery>;
/** 点命中：region 内或到边界距离 <= tolerance+margin。 */
export declare function queryObjectPoint(prepared: PreparedLayeredObjectQuery, worldPoint: Point, tolerance: number): LayeredObjectQueryResult<readonly LayeredObjectQueryHit[]>;
/** 扫掠命中：path 点/段与 region 相交，或到边界距离 <= radius+margin。 */
export declare function queryObjectSweep(prepared: PreparedLayeredObjectQuery, fullWorldPath: readonly Point[], radius: number): LayeredObjectQueryResult<readonly LayeredObjectQueryHit[]>;
/**
 * lasso 查询。mode 非法 → invalid-input（不静默返回空）。
 * - intersects：polyclip 区域相交非空 / 边界接触 / 距离 <= margin / 任一包含。
 * - contains：`difference(piece,lasso)` 为空 + 采样点在内 + shape 额外 .25 clearance。
 */
export declare function queryObjectLasso(prepared: PreparedLayeredObjectQuery, worldPolygon: readonly Point[], mode: 'intersects' | 'contains'): LayeredObjectQueryResult<readonly LayeredObjectQueryHit[]>;
export {};
//# sourceMappingURL=layeredObjectQuery.d.ts.map