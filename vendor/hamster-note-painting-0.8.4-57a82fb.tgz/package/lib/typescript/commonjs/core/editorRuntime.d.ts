import type { DrawingValueV2 } from '../model/strokes';
import { type EditorDocumentCommand, type EditorDocumentDiagnostic, type EditorDocumentState } from './editorDocument';
import type { DocumentStrokeTarget } from './selectionTransform';
import type { SelectionGestureIntent } from './gesture/session';
/** 运行时只保存已提交的不可变文档 snapshot；栈尾是下一次 undo/redo 的目标。 */
export type EditorHistoryState = Readonly<{
    undoStack: readonly EditorDocumentState[];
    redoStack: readonly EditorDocumentState[];
}>;
/** 非持久编辑运行时。revision 仅位于 documentState，绝不会写入 DrawingValueV2。 */
export type EditorRuntimeState = EditorHistoryState & Readonly<{
    documentState: EditorDocumentState;
}>;
export type EditorRuntimeDiagnostic = EditorDocumentDiagnostic | Readonly<{
    type: 'cannot-undo';
}> | Readonly<{
    type: 'cannot-redo';
}> | Readonly<{
    type: 'invalid-editor-command';
}> | Readonly<{
    type: 'invalid-editor-document';
}> | Readonly<{
    type: 'editor-document-noop';
}>;
export type EditorRuntimeResult = Readonly<{
    state: EditorRuntimeState;
    diagnostics: readonly EditorRuntimeDiagnostic[];
}>;
export type CreateEditorRuntimeOptions = Readonly<{
    /** 为恢复已有运行时而提供；缺省 revision 为 0。 */
    revision?: number;
}>;
/** 创建纯 runtime；输入 document 会被复制为冻结 snapshot，防止后续外部数组修改泄露。 */
export declare function createEditorRuntimeState(document: DrawingValueV2, options?: CreateEditorRuntimeOptions): EditorRuntimeState;
/**
 * 运行一条离散 document 命令。仅 document revision 恰好递增时记录一个 undo snapshot，
 * 并在该真实提交时清空 redo 分支；所有诊断都原样交给调用方而不抛出异常。
 */
export declare function applyEditorRuntimeCommand(state: EditorRuntimeState, command: EditorDocumentCommand): EditorRuntimeResult;
/**
 * 将完整 document 作为一条离散、revision-checked 的 history 提交。
 *
 * 它只用于受信任的纯 core producer（例如 GestureSession 的 document-commit effect）；
 * 未匹配 revision 或结构无变化都不会覆盖当前 snapshot 或改变 history。
 *
 * 该路径是正式 pen pointerup 的落笔提交入口；它刻意保持对完整 document 的深拷贝+冻结
 * （createSnapshot），不做 append 前缀结构共享，因此性能特征与本文件命令式 append 快路径无关。
 */
export declare function commitEditorRuntimeDocument(state: EditorRuntimeState, expectedRevision: number, document: DrawingValueV2): EditorRuntimeResult;
/** 将一个 selection intent 包装为单条原子 document 命令，因此它只会生成一个 history 单元。 */
export declare function commitSelectionIntent(state: EditorRuntimeState, targets: readonly DocumentStrokeTarget[], intent: SelectionGestureIntent): EditorRuntimeResult;
/** 回到最近一次真实离散提交；空 undo 栈只返回明确诊断。 */
export declare function undoEditorRuntime(state: EditorRuntimeState): EditorRuntimeResult;
/** 重放最近被撤销的一条离散提交；空 redo 栈只返回明确诊断。 */
export declare function redoEditorRuntime(state: EditorRuntimeState): EditorRuntimeResult;
//# sourceMappingURL=editorRuntime.d.ts.map