export type LayeredInputMode = 'auto' | 'finger' | 'pen';
export type LayeredInputSnapshot = Readonly<{
    mode: LayeredInputMode;
    penSeen: boolean;
    effectiveTouch: 'draw' | 'pan';
}>;
export declare function isLayeredInputMode(value: unknown): value is LayeredInputMode;
export declare function createLayeredInputSnapshot(mode: LayeredInputMode, penSeen?: boolean): LayeredInputSnapshot;
//# sourceMappingURL=layeredInputMode.d.ts.map