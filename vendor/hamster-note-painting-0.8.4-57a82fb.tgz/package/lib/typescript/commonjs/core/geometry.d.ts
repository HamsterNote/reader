import type { DrawingStrokeV2, DrawingValueV2 } from '../model/strokes';
/** 仅用于缺失或退化文字框的世界 DIP 保守回退尺寸。 */
export declare const TEXT_GEOMETRY_FALLBACK_WIDTH = 160;
/** 文字没有有效高度时，以默认字号的一行高度保持可选中性。 */
export declare const TEXT_GEOMETRY_FALLBACK_HEIGHT = 28.8;
/** 图片模型没有持久化固有尺寸时使用的世界 DIP 保守回退尺寸。 */
export declare const IMAGE_GEOMETRY_FALLBACK_WIDTH = 160;
export declare const IMAGE_GEOMETRY_FALLBACK_HEIGHT = 120;
/** 世界 DIP 坐标点；geometry 不认识相机、设备像素或渲染器坐标。 */
export type GeometryPoint = Readonly<{
    x: number;
    y: number;
}>;
/** 轴对齐且闭合的世界 DIP 包围框。 */
export type GeometryBounds = Readonly<{
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
    width: number;
    height: number;
}>;
/**
 * 可审计的 V2 笔迹几何描述。bounds 与 hit 均只从这个描述派生，避免两个入口随时间
 * 演化出不同的工具语义。
 */
export type DrawingGeometryDescriptor = Readonly<{
    kind: 'path';
    points: readonly GeometryPoint[];
    closed: boolean;
}> | Readonly<{
    kind: 'cubic-bezier';
    points: readonly [GeometryPoint, GeometryPoint, GeometryPoint, GeometryPoint];
}> | Readonly<{
    kind: 'rect';
    center: GeometryPoint;
    halfWidth: number;
    halfHeight: number;
    rotationRad: number;
}> | Readonly<{
    kind: 'ellipse';
    center: GeometryPoint;
    radiusX: number;
    radiusY: number;
    rotationRad: number;
}>;
/**
 * 默认轮廓的源曲线到输出折线最大偏差（世界 DIP）。这个固定世界单位使渲染和命中
 * 无须了解设备像素或视口缩放；调用方若需要屏幕恒定的误差，应先自行换算为世界 DIP。
 */
export declare const DEFAULT_DRAWING_CONTOUR_MAX_DEVIATION = 0.25;
/**
 * 单个参数曲线生成的折线段硬上限。path 本身已是用户提供的折线，不会复制或重采样。
 */
export declare const MAX_DRAWING_CONTOUR_SEGMENTS = 65536;
export type DrawingGeometryContourOptions = Readonly<{
    /** 要求的源曲线到折线最大偏差，缺省为 DEFAULT_DRAWING_CONTOUR_MAX_DEVIATION。 */
    maxDeviation?: number;
    /** 段上限，闭合轮廓至少需要 4，且不能超过 MAX_DRAWING_CONTOUR_SEGMENTS。 */
    maxSegments?: number;
}>;
/**
 * renderer 与 hit 共享的可绘制折线。
 *
 * maxDeviation 是保守的“原始参数曲线 -> 此折线”距离上界：cubic 使用控制点到叶子弦的
 * 凸包上界，ellipse 使用每段的精确 sagitta。它不是双向 Hausdorff 距离。capped 为 true
 * 时上限先于 requestedMaxDeviation 达到，maxDeviation 仍是实际输出的明确保守上界。
 */
export type DrawingGeometryContour = Readonly<{
    points: readonly GeometryPoint[];
    closed: boolean;
    maxDeviation: number;
    requestedMaxDeviation: number;
    isWithinRequestedMaxDeviation: boolean;
    capped: boolean;
}>;
/**
 * 建立单条 V2 stroke 的唯一 geometry descriptor。
 *
 * pen、line、polygon 与 bezier 保留其路径/控制点语义；矩形类工具以首末点组成的框为
 * 基础并绕框中心旋转。text/image 缺点或没有正尺寸时分别采用上方导出的稳定回退框。
 */
export declare function describeDrawingStrokeGeometry(stroke: DrawingStrokeV2): DrawingGeometryDescriptor | null;
/** 从 descriptor 获取保守轴对齐 bounds；不接受原始 stroke，保证来源唯一。 */
export declare function getDrawingGeometryBounds(descriptor: DrawingGeometryDescriptor): GeometryBounds | null;
/** 由 V2 stroke 的唯一 descriptor 派生其保守世界 DIP bounds。 */
export declare function getDrawingStrokeBounds(stroke: DrawingStrokeV2): GeometryBounds | null;
/**
 * 从 descriptor 建立 renderer 与 hit 共用的有限轮廓。cubic 是自适应 de Casteljau
 * 分裂；ellipse 按最大半径的 sagitta 选择段数，因此旋转和长短轴都不会降低误差保证。
 *
 * cap 仅保护直接调用 API 的资源上限；frame 会以局部分支裁剪和更高安全预算完成普通可见
 * 曲线，不能因这里的历史 1024 限制丢弃可见对象。
 */
export declare function describeDrawingGeometryContour(descriptor: DrawingGeometryDescriptor, options?: DrawingGeometryContourOptions): DrawingGeometryContour | null;
/**
 * 使用公开共享轮廓命中世界 DIP 点。tolerance 是轮廓边界的额外世界 DIP 外扩距离；
 * closed 轮廓的内部恒命中。轮廓近似误差由 describeDrawingGeometryContour 明确返回，
 * 因此 caller 可审计“命中折线”和后续 renderer 应绘制的同一几何。
 */
export declare function hitTestDrawingGeometry(descriptor: DrawingGeometryDescriptor, point: GeometryPoint, tolerance: number): boolean;
/** 由 V2 stroke 的唯一 descriptor 命中世界 DIP 点。 */
export declare function hitTestDrawingStroke(stroke: DrawingStrokeV2, point: GeometryPoint, tolerance: number): boolean;
/** 文档命中结果保留索引，方便调用方在重复 ID 的有序文档中无歧义定位条目。 */
export type DrawingDocumentHit = Readonly<{
    stroke: DrawingStrokeV2;
    index: number;
}>;
/** 按 document 顺序倒序检查，因此最后命中的笔迹是视觉上的 topmost。 */
export declare function hitTestDrawingDocument(document: DrawingValueV2, point: GeometryPoint, tolerance: number): DrawingDocumentHit | null;
//# sourceMappingURL=geometry.d.ts.map