/** 使用半开 AABB 的通用空间索引 bounds。 */
export type SpatialBounds = Readonly<{
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
}>;
/** 世界坐标中的精确查询点。 */
export type SpatialPoint = Readonly<{
    x: number;
    y: number;
}>;
export type SparseSpatialIndexOptions = Readonly<{
    cellSize?: number;
    maxCellsPerObject?: number;
    maxCellsPerQuery?: number;
}>;
export type SpatialIndexMatch<T> = Readonly<{
    key: string | number;
    value: T;
    bounds: SpatialBounds;
    order: number;
}>;
/**
 * 只读空间查询契约。`SparseSpatialIndex` 与增量组合索引都实现它；
 * frame/hit 只依赖 query/queryPoint，不依赖任何可变 upsert/remove。
 */
export type SpatialQueryIndex<T> = Readonly<{
    query(bounds: SpatialBounds): readonly SpatialIndexMatch<T>[];
    queryPoint(point: SpatialPoint): readonly SpatialIndexMatch<T>[];
}>;
/** 链式 delta 的默认深度上限；超过时用一次全量重建压平，避免查询沿无界链退化。 */
export declare const DEFAULT_MAX_SPATIAL_DELTA_DEPTH = 32;
export type AppendSpatialQueryIndexOptions = SparseSpatialIndexOptions & Readonly<{
    /** 允许的最大 delta 链深；设为 1 表示每次 append 都重建。 */
    maxDeltaDepth?: number;
}>;
/** 半开区间相交；接触边界不算相交。 */
export declare function intersectsSpatialBounds(left: SpatialBounds, right: SpatialBounds): boolean;
/**
 * 无 document 语义的稀疏 hash。对象与查询的大范围情况回退为线性精确过滤，
 * 所以保护阈值只影响性能，不影响结果正确性。
 */
export declare class SparseSpatialIndex<T> implements SpatialQueryIndex<T> {
    private readonly cells;
    private readonly records;
    private readonly overflow;
    private nextOrder;
    readonly cellSize: number;
    readonly maxCellsPerObject: number;
    readonly maxCellsPerQuery: number;
    constructor(options?: SparseSpatialIndexOptions);
    get size(): number;
    upsert(key: string | number, value: T, bounds: SpatialBounds, order?: number): boolean;
    remove(key: string | number): boolean;
    query(bounds: SpatialBounds): readonly SpatialIndexMatch<T>[];
    /**
     * 精确点查询直接读取 point 所在的单个 bucket 与 overflow，不经半开 AABB query。
     * 这与 query(bounds) 的相交查询不同：点落在 record.maxX/maxY 上时不命中。
     */
    queryPoint(point: SpatialPoint): readonly SpatialIndexMatch<T>[];
}
export declare function createSparseSpatialIndex<T>(options?: SparseSpatialIndexOptions): SparseSpatialIndex<T>;
/** 简短别名，保留 sparse 实现细节在类型名称中可见。 */
export { SparseSpatialIndex as SpatialIndex };
/** 返回查询索引当前的 delta 链深；非组合索引（含全量 SparseSpatialIndex）为 0。 */
export declare function getSpatialQueryIndexDeltaDepth(index: SpatialQueryIndex<unknown>): number;
/**
 * append-only 增量空间索引：在不修改 previous 的前提下，把一条新记录组合到既有查询索引上。
 *
 * - 边界、overflow、query/queryPoint 的半开语义完全委托给底层 SparseSpatialIndex，结果与全量重建一致。
 * - 非法 bounds 直接返回 previous（不推进链）。
 * - 当链深达到 maxDeltaDepth 时，用一次全量重建（枚举 previous 所有记录）压平，返回新的
 *   SparseSpatialIndex；调用方可通过 getSpatialQueryIndexDeltaDepth 观察并自行控制上限。
 */
export declare function appendSpatialQueryIndex<T>(previous: SpatialQueryIndex<T>, key: string | number, value: T, bounds: SpatialBounds, order: number, options?: AppendSpatialQueryIndexOptions): SpatialQueryIndex<T>;
//# sourceMappingURL=spatialIndex.d.ts.map