/**
 * 自由笔输入会话（Task 2.3 整笔锁定基础 + Task 4.2 / 4.3 纯会话基础）。
 *
 * 范围约束（重要）：
 * - 纯 headless 状态机：不依赖 DOM / React / Canvas / Skia / history / document 事务。
 * - **不创建文档对象、不写 history、不做几何派生**：只把 adapter 归一化的 begin/update/end/cancel
 *   批次累积成只读 candidate，交给未来 controller 用 commitId 提交。
 * - viewport 只读，不改动唯一 viewport 的任何 API；本会话冻结落笔 revision。
 *
 * 会话生命周期（四态）：
 *   collecting --end--> awaiting-commit --commit-succeeded--> committed
 *   collecting --cancel--> canceled
 * commit-failed 留在 awaiting-commit（同 candidate / 同 commitId）供 controller 重试；
 * awaiting/committed 上的 cancel 被拒绝，不会丢候选或回滚；committed 后失败反馈不能回退。
 */
import { type FreehandRulerSnapshot, type AcceptedSample, type BrushSnapshot, type InputSource, type PressureCapability, type SamplePhase } from '../model/document';
import type { DrawingViewport } from '../viewport';
/** 单条输入样本；`pressure` 缺失时保持缺失，不在此层写回或补造。 */
export type FreehandSampleInput = Readonly<{
    sequence: number;
    x: number;
    y: number;
    pressure?: number;
    time: number;
    phase: SamplePhase;
}>;
/** adapter 归一化后的一个输入批次；同批次不可跨 source / 坐标空间 / viewport revision。 */
export type FreehandInputBatch = Readonly<{
    sessionId: string;
    pointerId: string | number;
    source: InputSource;
    batchSequence: number;
    coordinateSpace: 'screen' | 'world';
    viewportRevision: number;
    samples: readonly FreehandSampleInput[];
}>;
/** begin：落笔时记录 pointer、brush 快照、压力能力与稳定 viewport revision。 */
export type BeginFreehandSessionInput = Readonly<{
    type: 'begin';
    commitId: string;
    pressureCapability: PressureCapability;
    brush: BrushSnapshot;
    rulerSnapshot?: FreehandRulerSnapshot;
    viewportSnapshot: Readonly<{
        revision: number;
        viewport: DrawingViewport;
    }>;
    batch: FreehandInputBatch;
}>;
/** update：追加移动批次。 */
export type FreehandSessionUpdate = Readonly<{
    type: 'update';
    batch: FreehandInputBatch;
}>;
/** end：收尾批次，最后一帧且仅最后一帧为 up。 */
export type FreehandSessionEnd = Readonly<{
    type: 'end';
    batch: FreehandInputBatch;
}>;
/** 取消原因；取消只可用于尚未提交的 collecting。 */
type FreehandCancelReason = 'pointercancel' | 'unmount' | 'background' | 'tool-change' | 'explicit';
/** cancel：不携带样本，identity 与下一批次序号必须匹配。 */
export type FreehandSessionCancel = Readonly<{
    type: 'cancel';
    sessionId: string;
    pointerId: string | number;
    source: InputSource;
    batchSequence: number;
    reason: FreehandCancelReason;
}>;
/** 未来 controller 的提交反馈；错误 commitId 必须被拒绝。 */
export type FreehandCommitFeedback = Readonly<{
    type: 'commit-failed';
    commitId: string;
}> | Readonly<{
    type: 'commit-succeeded';
    commitId: string;
    objectId: string;
    documentRevision: number;
}>;
/** 会话拒绝码；仅用于本模块 Result。 */
type FreehandSessionErrorCode = 'invalid-input' | 'identity-mismatch' | 'coordinate-space-mismatch' | 'viewport-revision-mismatch' | 'batch-sequence-mismatch' | 'sample-sequence-mismatch' | 'phase-mismatch' | 'not-collecting' | 'commit-id-mismatch';
/** 统一 Result：成功携带值，失败只给可测 code，不抛异常。 */
export type FreehandSessionResult<T> = Readonly<{
    ok: true;
    value: T;
}> | Readonly<{
    ok: false;
    code: FreehandSessionErrorCode;
}>;
/** 整笔冻结后的提交候选；source 由 begin owner 填入，pressure 缺失保持缺失。 */
export type FreehandCandidate = Readonly<{
    commitId: string;
    sessionId: string;
    pointerId: string | number;
    source: InputSource;
    lockedViewportRevision: number;
    brushSnapshot: BrushSnapshot;
    rulerSnapshot?: FreehandRulerSnapshot;
    resolvedPressureMode: 'real' | 'simulated' | 'constant';
    samples: readonly AcceptedSample[];
}>;
/** 会话快照四态；collecting 内联展开 owner/brush/mode/viewport 与序号。 */
export type FreehandSessionSnapshot = Readonly<{
    status: 'collecting';
    commitId: string;
    sessionId: string;
    pointerId: string | number;
    source: InputSource;
    brushSnapshot: BrushSnapshot;
    rulerSnapshot?: FreehandRulerSnapshot;
    resolvedPressureMode: 'real' | 'simulated' | 'constant';
    lockedViewport: DrawingViewport;
    lockedViewportRevision: number;
    coordinateSpace: 'screen' | 'world';
    samples: readonly AcceptedSample[];
    nextBatchSequence: number;
    nextSampleSequence: number;
}> | Readonly<{
    status: 'awaiting-commit';
    candidate: FreehandCandidate;
}> | Readonly<{
    status: 'committed';
    candidate: FreehandCandidate;
    objectId: string;
    documentRevision: number;
}> | Readonly<{
    status: 'canceled';
    commitId: string;
    sessionId: string;
    pointerId: string | number;
    source: InputSource;
    reason: FreehandCancelReason;
}>;
/** 会话接口：getSnapshot 与四个命令；所有命令在失败时不改变任何 state。 */
export interface FreehandSession {
    getSnapshot(): FreehandSessionSnapshot;
    update(input: FreehandSessionUpdate): FreehandSessionResult<void>;
    end(input: FreehandSessionEnd): FreehandSessionResult<FreehandSessionSnapshot>;
    cancel(input: FreehandSessionCancel): FreehandSessionResult<FreehandSessionSnapshot>;
    applyCommitFeedback(feedback: FreehandCommitFeedback): FreehandSessionResult<FreehandSessionSnapshot>;
}
/**
 * begin 自由笔会话：验证输入、按落笔 source/capability 解析压力模式并锁定整笔、
 * 冻结 brush/viewport 快照，返回 collecting 会话。
 *
 * - auto 解析只在此调用一次 `resolvePressureMode`；不新增默认、不改现有 resolver。
 * - viewport 严格校验：必须已是规范形态（normalize 返回 null 或发生 clamp 都拒绝）。
 * - 任一步失败返回对应 code，不产生任何 state。
 */
export declare function beginFreehandSession(input: BeginFreehandSessionInput): FreehandSessionResult<FreehandSession>;
export {};
//# sourceMappingURL=freehandSession.d.ts.map