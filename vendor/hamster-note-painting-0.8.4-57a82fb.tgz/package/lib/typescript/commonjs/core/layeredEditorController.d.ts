/**
 * 分层编辑器控制器（Task 3.1 / 4.4）。
 *
 * 实现范围：
 * - 公开类型契约 + 私有 typed schema3 document adopter / copy helpers。
 * - 私有 document/history/commit kernel：registry/tombstone、exact canonical 提交、
 *   revision 单调 undo/redo、presentation identity 查询。
 * - 导出的 `createLayeredEditorController`：组合 kernel 与 session/settings/selection/viewport
 *   及 channel 订阅，作为 headless 单一真源。
 *
 * 边界（design.md 决策 1 / 5 / 6）：
 * - 不依赖 DOM / React / Canvas / SVG / Skia / 旧 controller / reader / protocol。
 * - 只预留 `LayeredPresentationIdentity`，不实现 ACK / handoff / native / 像素渲染。
 * - 2.2 持久 reader 未完成：本模块只接受已是 typed schema3 的内存文档，不做 JSON reader/migration。
 */
import { type BrushSnapshot, type DocumentObject, type EditorDocument, type Point, type ShapeStyle } from '../model/document';
import { type DrawingViewport } from '../viewport';
import { type BeginFreehandSessionInput, type FreehandCandidate, type FreehandSessionCancel, type FreehandSessionEnd, type FreehandSessionResult, type FreehandSessionSnapshot, type FreehandSessionUpdate } from './freehandSession';
import { type ViewportTransformIntent } from './viewportTransform';
import { FreehandGeometryCache } from '../geometry/freehandCache';
import { type LayeredInputMode, type LayeredInputSnapshot } from './layeredInputMode';
import { type DrawingSurfaceVirtualPaperInteraction } from '../virtualPaperOptions';
/** 活动工具：自由笔、形状、图片、文字与交互工具（选择/套索/橡皮/平移）。 */
export type LayeredEditorTool = 'freehand' | 'line' | 'rect' | 'ellipse' | 'polygon' | 'bezier' | 'image' | 'text' | 'selection' | 'lasso' | 'eraser' | 'pan';
/** 工具设置：自由笔使用不可变 brush 快照，形状使用独立样式（dash 只属于形状）。 */
export type LayeredEditorSettings = Readonly<{
    freehand: BrushSnapshot;
    shape: ShapeStyle;
}>;
/** 唯一 viewport 的单调 revision 快照。 */
export type LayeredViewportSnapshot = Readonly<{
    revision: number;
    viewport: DrawingViewport;
}>;
/**
 * viewport 命令：结构先校验，`expectedRevision` 不匹配按 stale 拒绝。
 * `replace` 直接给出目标 viewport；`transform` 应用一个手势 intent。
 */
export type LayeredViewportCommand = Readonly<{
    type: 'replace';
    expectedRevision: number;
    viewport: DrawingViewport;
}> | Readonly<{
    type: 'transform';
    expectedRevision: number;
    intent: ViewportTransformIntent;
}>;
/**
 * begin 输入：由 controller 覆写 brush 与 viewportSnapshot（唯一权威），
 * 调用方只提供 commitId / 压力能力 / 输入批次。
 */
export type LayeredBeginInput = Omit<BeginFreehandSessionInput, 'brush' | 'viewportSnapshot'>;
/** 呈现身份四字段；非保存数据，用于未来 presentation handoff（本期不实现 ACK）。 */
export type LayeredPresentationIdentity = Readonly<{
    objectId: string;
    commitId: string;
    documentRevision: number;
    geometryRevision: string;
}>;
/** 提交回执：created 或 duplicate；`presentationIdentity` 仅在对象存在于当前文档时非 null。 */
export type LayeredCommitReceipt = Readonly<{
    status: 'created' | 'duplicate';
    objectId: string;
    commitId: string;
    documentRevision: number;
    presentInDocument: boolean;
    presentationIdentity: LayeredPresentationIdentity | null;
}>;
/** 控制器拒绝码；覆盖输入、文档、会话、提交、viewport、selection、history 与不变量。 */
export type LayeredEditorErrorCode = 'invalid-input' | 'invalid-document' | 'active-session-conflict' | 'no-active-session' | 'tool-not-freehand' | 'commit-id-in-flight' | 'pending-commit-not-found' | 'pending-commit-out-of-order' | 'commit-id-conflict' | 'object-id-conflict' | 'object-id-allocation-failed' | 'final-geometry-failed' | 'stale-viewport-revision' | 'selection-target-missing' | 'nothing-to-undo' | 'nothing-to-redo' | 'revision-exhausted' | 'session-rejected' | 'internal-invariant';
/** 会话层错误码（从 session Result 推导），随 `session-rejected` 一起返回。 */
export type LayeredSessionErrorCode = Extract<FreehandSessionResult<unknown>, {
    ok: false;
}>['code'];
/** 统一 Result：成功携带值，失败给可测 code；会话失败另带 sessionCode。 */
export type LayeredEditorResult<T> = Readonly<{
    ok: true;
    value: T;
}> | Readonly<{
    ok: false;
    error: Readonly<{
        code: LayeredEditorErrorCode;
        sessionCode?: LayeredSessionErrorCode;
    }>;
}>;
/** 订阅频道；除 interaction 外均按 state 返回稳定引用，适合 useSyncExternalStore。 */
export type LayeredEditorChannel = 'input' | 'document' | 'history' | 'tools' | 'selection' | 'viewport' | 'preview' | 'interaction' | 'navigation';
export type LayeredNavigationSnapshot = Readonly<{
    paper: boolean;
    minimap: boolean;
    ruler: Readonly<{
        visible: boolean;
        center: Point;
        rotationRad: number;
        height: number;
    }>;
    rotationFeedback: Readonly<{
        point: Point;
        rotationRad: number;
    }> | null;
    zoomFeedback: Readonly<{
        point: Point;
        scale: number;
        token: number;
    }> | null;
    virtualPaper: Readonly<{
        enabled: boolean;
        initialPlacement: 'top-left' | 'top-center' | 'center';
        minScale: number;
        maxScale: number;
        enabledInteractions: readonly DrawingSurfaceVirtualPaperInteraction[];
    }>;
}>;
/** history 频道快照。 */
export type LayeredHistorySnapshot = Readonly<{
    canUndo: boolean;
    canRedo: boolean;
}>;
/** tools 频道快照：活动工具与设置。 */
export type LayeredToolsSnapshot = Readonly<{
    activeTool: LayeredEditorTool;
    settings: LayeredEditorSettings;
}>;
/** selection 频道快照：文档内存在的对象 id（只读）。 */
export type LayeredSelectionSnapshot = readonly string[];
export type LayeredPreviewSnapshot = Readonly<{
    objects: readonly DocumentObject[];
    hiddenIds: readonly string[];
    path: readonly Point[];
}>;
/**
 * interaction 频道快照：当前 collecting 会话快照与等待提交的候选。
 * 该频道按需构造（下一 UI 阶段再验证缓存策略），不承诺稳定引用。
 */
export type LayeredInteractionSnapshot = Readonly<{
    activeFreehand?: FreehandSessionSnapshot;
    pendingCandidates: readonly FreehandCandidate[];
}>;
/** 频道 → 快照类型映射，供泛型 `getSnapshot` 精确返回。 */
export type LayeredEditorSnapshotMap = Readonly<{
    input: LayeredInputSnapshot;
    document: EditorDocument;
    history: LayeredHistorySnapshot;
    tools: LayeredToolsSnapshot;
    selection: LayeredSelectionSnapshot;
    viewport: LayeredViewportSnapshot;
    preview: LayeredPreviewSnapshot;
    navigation: LayeredNavigationSnapshot;
    interaction: LayeredInteractionSnapshot;
}>;
/** updateViewport 结果：是否实际应用；未应用时给出原因。 */
export type LayeredViewportUpdateResult = Readonly<{
    applied: boolean;
    reason?: 'active-freehand' | 'unchanged';
}>;
/**
 * 控制器公开接口。
 *
 * - `getSnapshot` 按频道泛型返回；除 interaction 外为稳定引用。
 * - `subscribe` 返回取消订阅函数；订阅者抛错被隔离，不影响已完成事务。
 * - 会话命令（begin/update/end/cancel）返回 Result；update 成功为 `Result<void>`，
 *   不主动复制快照（热路径），需要观察由调用方显式 `getSnapshot('interaction')`。
 * - `commitFreehand` 使用 commitId 幂等；`undo/redo` 返回新文档。
 * - `getPresentationIdentity` 只查当前文档：无对象时成功返回 null；final 几何准备失败时
 *   返回 `final-geometry-failed`（几何派生可能 throw，不能吞掉）。
 */
export interface LayeredEditorController {
    getSnapshot<C extends LayeredEditorChannel>(channel: C): LayeredEditorSnapshotMap[C];
    subscribe(channel: LayeredEditorChannel, listener: () => void): () => void;
    setTool(tool: LayeredEditorTool): LayeredEditorResult<void>;
    setInputMode(mode: LayeredInputMode): LayeredEditorResult<void>;
    initializeInputMode(mode: LayeredInputMode): LayeredEditorResult<void>;
    recordPenDown(): void;
    setFreehandSettings(settings: BrushSnapshot): LayeredEditorResult<void>;
    setShapeSettings(settings: ShapeStyle): LayeredEditorResult<void>;
    setSelection(ids: readonly string[]): LayeredEditorResult<void>;
    setPreview(preview: LayeredPreviewSnapshot | null): LayeredEditorResult<void>;
    setNavigation(patch: Partial<LayeredNavigationSnapshot>): LayeredEditorResult<void>;
    updateViewport(command: LayeredViewportCommand): LayeredEditorResult<LayeredViewportUpdateResult>;
    beginFreehand(input: LayeredBeginInput): LayeredEditorResult<void>;
    updateFreehand(input: FreehandSessionUpdate): LayeredEditorResult<void>;
    endFreehand(input: FreehandSessionEnd): LayeredEditorResult<FreehandCandidate>;
    cancelFreehand(input: FreehandSessionCancel): LayeredEditorResult<void>;
    commitFreehand(commitId: string): LayeredEditorResult<LayeredCommitReceipt>;
    editObjects(edit: LayeredObjectEdit): LayeredEditorResult<EditorDocument>;
    undo(): LayeredEditorResult<EditorDocument>;
    redo(): LayeredEditorResult<EditorDocument>;
    getPresentationIdentity(commitId: string): LayeredEditorResult<LayeredPresentationIdentity | null>;
}
/** One reversible object edit. Freehand creation remains exclusive to raw commit. */
export type LayeredObjectEdit = Readonly<{
    expectedDocumentRevision: number;
    upsert?: readonly DocumentObject[];
    removeIds?: readonly string[];
}>;
/**
 * factory 选项：初始文档、viewport 快照、活动工具、设置、可选 selection、
 * 提交时分配 objectId 的注入函数，以及可选几何缓存。
 */
export type LayeredEditorControllerOptions = Readonly<{
    inputMode?: LayeredInputMode;
    document: EditorDocument;
    viewport: LayeredViewportSnapshot;
    activeTool: LayeredEditorTool;
    settings: LayeredEditorSettings;
    selection?: readonly string[];
    allocateObjectId: (commitId: string) => string;
    geometryCache?: FreehandGeometryCache;
}>;
/**
 * 创建分层编辑器控制器。
 *
 * 校验 options、adopt typed schema3 文档、冻结 brush/shape/viewport/selection、创建私有 kernel
 * 与缓存，随后组合为 controller。默认新建 `FreehandGeometryCache`。
 */
export declare function createLayeredEditorController(options: LayeredEditorControllerOptions): LayeredEditorResult<LayeredEditorController>;
//# sourceMappingURL=layeredEditorController.d.ts.map