import { type GeometryPoint } from './geometry';
import type { PreparedDrawingEntry } from './preparedDocument';
/** 单帧局部坐标的闭合安全区域。所有 program/fragment 坐标必须位于此区域内。 */
export type FrameLocalClipRegion = Readonly<{
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
}>;
export type FrameStrokeFragment = Readonly<{
    kind: 'stroke';
    points: readonly [GeometryPoint, GeometryPoint, ...GeometryPoint[]];
    closed: boolean;
    sourceSegmentIndex: number;
    sourceSegmentStart: number;
    sourceSegmentEnd: number;
    sourceDistanceStart: number;
    sourceDistanceEnd: number;
    /** pressure 是每个源段终点的固定宽度契约，裁剪点 pressure 只作审计。 */
    sourcePressures: Readonly<{
        start?: number;
        end?: number;
    }>;
    clip?: Readonly<{
        startT: number;
        endT: number;
        insertedPressures: Readonly<{
            start?: number;
            end?: number;
        }>;
    }>;
}>;
export type FrameSemanticAreaFragment = Readonly<{
    kind: 'semantic-area';
    points: readonly GeometryPoint[];
}>;
/** 资源的原始完整 local 布局。它只用于认证与映射，不能假定可直接交给 Skia。 */
export type FrameResourceLayout = Readonly<{
    center: GeometryPoint;
    halfWidth: number;
    halfHeight: number;
    rotationRad: number;
}>;
/** partial resource 的可见区域：polygon 是 render/hit 的共同权威，clipBounds 仅为有界审计裁剪区。 */
export type FrameResourceVisibleRegion = Readonly<{
    polygon: readonly GeometryPoint[];
    clipBounds: FrameLocalClipRegion;
}>;
/** 图片 source 使用归一化 [0, 1] 坐标，避免把完整巨大图片的像素或布局数传给 Skia。 */
export type FrameImageSourceWindow = Readonly<{
    x: number;
    y: number;
    width: number;
    height: number;
}>;
/** 已解析文本与命中共用的局部语义区域；文本资源框本身不再自动成为命中区。 */
export type FrameTextSemanticRegion = Readonly<{
    polygon: readonly GeometryPoint[];
}>;
/** core 只产生纯文本/layout 请求；平台 provider 必须用真实 shaping 兑现或明确拒绝。 */
export type FrameTextRequest = Readonly<{
    revision: string;
    text: string;
    fontSize: number;
    paragraphOrigin: GeometryPoint;
    /** 原始完整 paragraph 宽度，仅用于保留原资源布局语义与认证。 */
    paragraphWidth: number;
    /** 实际允许交给平台 Paragraph.layout 的宽度，始终不大于 frame draw budget。 */
    paragraphLayoutWidth: number;
    /** 超原始宽度预算时，仅固定 LTR/start-left 布局允许通过 metrics 认证。 */
    paragraphDirection: 'auto' | 'ltr';
    paragraphAlignment: 'start';
    rotationRad: number;
    visiblePolygon: readonly GeometryPoint[];
}>;
/**
 * 平台已解析的 glyph run；位置属于 paragraph-local 坐标。typeface 是平台不透明句柄，core
 * 只能保存和转交，不能检查、调用或依赖其具体实现。
 */
export type FrameShapedGlyphRun = Readonly<{
    glyphs: Uint16Array;
    positions: Float32Array;
    /** CanvasKit 的 UTF-8 byte offsets（含 glyphCount + 1 个尾槽），绝非 JS 字符串下标。 */
    offsets?: Uint32Array;
    /** 兼容平台提供的 cluster byte 数据；同样不能被 core 当作 JS 字符串下标。 */
    clusters?: Uint32Array;
    /** 平台已验证的实际 run typeface；它可以是任意平台对象。 */
    typeface: unknown;
    /** Web provider 已在真实 Skia 上构造并验证的 opaque font handle。 */
    font: unknown;
    /** core 只消费此判别结果，绝不调用或检查平台 font/typeface 对象。 */
    fontReady: boolean;
    size: number;
    scaleX: number;
}>;
/**
 * 文本的唯一 render/hit 语义。paragraph-slice 只允许完整原宽的安全 Paragraph；shaped-runs
 * 必须来自真实 Paragraph shaping，绝不能通过截取字符串重新排版得到。
 */
export type FrameTextProgram = Readonly<{
    kind: 'empty-text';
}> | Readonly<{
    kind: 'paragraph-slice';
    text: string;
    anchor: GeometryPoint;
    paintOffset: GeometryPoint;
    paragraphWidth: number;
    rotationRad: number;
    semanticRegions: readonly FrameTextSemanticRegion[];
}> | Readonly<{
    kind: 'shaped-runs';
    anchor: GeometryPoint;
    rotationRad: number;
    runs: readonly FrameShapedGlyphRun[];
    semanticRegions: readonly FrameTextSemanticRegion[];
}>;
export type FrameResourceBoxFragment = FrameSemanticAreaFragment & Readonly<{
    resourceBox: Readonly<{
        kind: 'resource-box';
        tool: 'text' | 'image';
        /** 永远保留资源本身的完整布局，partial 不以可见 AABB 替换它。 */
        layout: FrameResourceLayout;
        /** partial 的有限可见区域；renderer 与 hit 必须消费同一个 polygon。 */
        visible?: FrameResourceVisibleRegion;
        /**
         * 仅 image partial 使用。source 是完整图片坐标中的归一化窗口，destination 是相同内容
         * 在当前 frame 的有限局部绘制框；两者保持完整图片的 scale/rotation 映射，不会 re-fit。
         */
        imageMapping?: Readonly<{
            source: FrameImageSourceWindow;
            destination: FrameResourceLayout;
        }>;
        /** partial text 的待解析请求与已解析 program；二者都不以 visible polygon 的 AABB 重排。 */
        textRequest?: FrameTextRequest;
        textProgram?: FrameTextProgram;
        source: Readonly<{
            text?: string;
            fontSize?: number;
            resourceId?: string;
            src?: string;
        }>;
    }>;
}>;
export type DrawingFrameFragment = FrameStrokeFragment | FrameSemanticAreaFragment;
/** 一个对象一次 fill 的后端无关复合区域，绝不按 island/hole 拆成多次 fill。 */
export type FrameFillRegion = Readonly<{
    kind: 'fill-region';
    fillRule: 'nonzero';
    polygons: readonly Readonly<{
        outer: readonly GeometryPoint[];
        holes: readonly (readonly GeometryPoint[])[];
    }>[];
}>;
export type FrameGeometryProgram = Readonly<{
    strokes: readonly FrameStrokeFragment[];
    fills: readonly FrameFillRegion[];
    /** 源曲线到本 program 折线的已认证世界 DIP 偏差；原始线段/多边形恒为 0。 */
    maxDeviation: number;
}>;
export type FrameFragmentStatus = 'unchanged' | 'rebased' | 'clipped' | 'segmented' | 'empty' | 'pending' | 'unresolved';
export type FrameClippingDiagnostic = Readonly<{
    type: 'unresolved-clipping';
    reason: 'unsafe-number' | 'partial-resource-box' | 'invalid-geometry' | 'clip-failed' | 'unrepresentable-geometry';
}>;
export type FrameClippingResult = Readonly<{
    status: FrameFragmentStatus;
    fragments: readonly DrawingFrameFragment[];
    program: FrameGeometryProgram;
    diagnostic?: FrameClippingDiagnostic;
}>;
/** 仅从 immutable prepared 几何生成 transient frame program；不会回写 document/effects。 */
export declare function clipPreparedDrawingEntry(entry: PreparedDrawingEntry, origin: GeometryPoint, region: FrameLocalClipRegion, limit: number, maxDeviation?: number): FrameClippingResult;
//# sourceMappingURL=frameClipping.d.ts.map