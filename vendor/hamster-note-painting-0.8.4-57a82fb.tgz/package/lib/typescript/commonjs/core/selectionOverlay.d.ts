import type { DrawingViewport } from '../viewport';
import type { Point } from './input';
import type { SelectionGestureDescriptor } from './gesture/session';
import type { SelectionFrame } from './selectionFrame';
export declare const DEFAULT_SELECTION_HANDLE_SIZE = 10;
export declare const DEFAULT_SELECTION_HIT_SLOP = 6;
export declare const DEFAULT_SELECTION_ROTATE_OFFSET = 24;
export type SelectionOverlayHandle = Readonly<{
    kind: 'rotate' | 'uniform-scale';
    corner?: 'top-left' | 'top-right' | 'bottom-right' | 'bottom-left';
    center: Point;
    size: number;
    hitSize: number;
    gesture: SelectionGestureDescriptor;
}>;
/** screen DIP 的同源 visual/hit 数据；host 可直接渲染和命中，不能另行猜测几何。 */
export type SelectionOverlayModel = Readonly<{
    frame: Readonly<{
        minX: number;
        minY: number;
        maxX: number;
        maxY: number;
    }>;
    handles: readonly SelectionOverlayHandle[];
    moveGesture: SelectionGestureDescriptor;
}>;
export type SelectionOverlayHit = Readonly<{
    kind: 'rotate' | 'uniform-scale' | 'move';
    gesture: SelectionGestureDescriptor;
}>;
export type SelectionOverlayOptions = Readonly<{
    handleSize?: number;
    hitSlop?: number;
    rotateOffset?: number;
    minimumScreenExtent?: number;
}>;
/**
 * 将 world AABB 变为 screen-DIP 选框。AABB 保持轴对齐，故 rotationRad 恒为零；这不是 OBB。
 * 四角是唯一 scale hit，边中点不产生 resize 手势。
 */
export declare function deriveSelectionOverlayModel(worldFrame: SelectionFrame, viewport: DrawingViewport, options?: SelectionOverlayOptions): SelectionOverlayModel | null;
/** 按 rotate > 四角 uniform-scale > move body 的固定优先级返回命中；未命中即由宿主视为 paper。 */
export declare function hitTestSelectionOverlay(model: SelectionOverlayModel, screen: Point): SelectionOverlayHit | null;
//# sourceMappingURL=selectionOverlay.d.ts.map