import type { GeometryPoint } from './geometry';
export type PolygonRing = readonly GeometryPoint[];
export type PolygonBooleanPolygon = Readonly<{
    outer: PolygonRing;
    holes: readonly PolygonRing[];
}>;
export type PolygonBooleanMultiPolygon = readonly PolygonBooleanPolygon[];
export type ClosedRingKind = 'simple-convex' | 'simple-concave' | 'complex';
/** 在 prepared 阶段调用一次；frame 不再为每帧裁剪重复 O(n²) 自交检查。 */
export declare function classifyClosedRing(points: readonly GeometryPoint[]): ClosedRingKind | null;
/**
 * canonical fill rule 始终是 nonzero。先测试边界，随后以 robust orient2d 累积绕数，避免
 * even-odd 在反向绕行或自交轮廓上改变语义。
 */
export declare function hitTestNonzeroRings(rings: readonly PolygonRing[], point: GeometryPoint, tolerance: number): boolean;
export type PolygonBooleanResult = Readonly<{
    ok: true;
    polygons: PolygonBooleanMultiPolygon;
}> | Readonly<{
    ok: false;
}>;
/** polyclip 异常绝不降级为空区域；调用方必须将失败诊断为 clip-failed。 */
export declare function canonicalizeClosedRing(ring: PolygonRing): PolygonBooleanResult;
export declare function intersectClosedRingWithRect(ring: PolygonRing, region: Readonly<{
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
}>): PolygonBooleanResult;
//# sourceMappingURL=polygonBoolean.d.ts.map