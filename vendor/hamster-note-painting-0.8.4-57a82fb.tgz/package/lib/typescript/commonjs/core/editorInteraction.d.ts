import { type DrawingViewport } from '../viewport';
import { type CreateGestureSessionOptions, type GestureRulerState, type GestureSession, type GestureSessionTool, type GestureTransientState, type SelectionGestureDescriptor, type SelectionGestureIntent } from './gesture/session';
import type { NormalizedPointerInput } from './input';
import { type EditorRuntimeDiagnostic, type EditorRuntimeState } from './editorRuntime';
import { type EditorDocumentCommand } from './editorDocument';
import { type DocumentStrokeTarget } from './selectionTransform';
import type { DrawingValueV2 } from '../model/strokes';
export type EditorInteractionDiagnostic = EditorRuntimeDiagnostic | Readonly<{
    type: 'gesture-already-active';
}> | Readonly<{
    type: 'no-active-gesture';
}> | Readonly<{
    type: 'active-gesture-conflict';
}> | Readonly<{
    type: 'stale-gesture-revision';
    expectedRevision: number;
    actualRevision: number;
}> | Readonly<{
    type: 'no-selection-targets';
}> | Readonly<{
    type: 'invalid-interaction-viewport';
}>;
export type ActiveEditorGesture = Readonly<{
    session: GestureSession;
    beginRevision: number;
    beginViewport: DrawingViewport;
}>;
/** 仅供候选界面渲染的 world-DIP replacement 集；它从不写 document 或 history。 */
export type EditorSelectionPreview = Readonly<{
    intent: SelectionGestureIntent;
    /** 唯一可渲染的冻结预览快照；UI 必须直接读取它而不是自行回放 replacement。 */
    document: DrawingValueV2;
}>;
/** 交互层只协调纯 session、history 与 viewport；它不持有平台事件或 renderer 对象。 */
export type EditorInteractionState = Readonly<{
    runtime: EditorRuntimeState;
    viewport: DrawingViewport;
    tool: GestureSessionTool;
    selectionTargets: readonly DocumentStrokeTarget[];
    selectionDescriptor?: SelectionGestureDescriptor;
    ruler?: Readonly<{
        state: GestureRulerState;
        pivot?: Readonly<{
            x: number;
            y: number;
        }>;
    }>;
    interactionPolicy?: CreateGestureSessionOptions['interactionPolicy'];
    activeGesture?: ActiveEditorGesture;
    transient: GestureTransientState;
    selectionPreview?: EditorSelectionPreview;
    diagnostics: readonly EditorInteractionDiagnostic[];
}>;
export type CreateEditorInteractionOptions = Readonly<{
    viewport?: DrawingViewport;
    tool?: GestureSessionTool;
    selectionTargets?: readonly DocumentStrokeTarget[];
    selectionDescriptor?: SelectionGestureDescriptor;
    ruler?: Readonly<{
        state: GestureRulerState;
        pivot?: Readonly<{
            x: number;
            y: number;
        }>;
    }>;
    interactionPolicy?: CreateGestureSessionOptions['interactionPolicy'];
}>;
export type EditorInteractionResult = Readonly<{
    state: EditorInteractionState;
    diagnostics: readonly EditorInteractionDiagnostic[];
}>;
/**
 * GestureSession 只处理宿主 screen DIP；交互层以手势起始 viewport 将其一次映射为 world DIP。
 * 缩放标量与视口无关，旧 resize 的两个轴保持原样以维持 non-uniform 拒绝防线。
 */
export declare function selectionIntentToWorld(intent: SelectionGestureIntent, beginViewport: DrawingViewport): SelectionGestureIntent | null;
/** 创建纯交互协调状态；初始 document 与 runtime snapshot 均不会共享调用方可变数组。 */
export declare function createEditorInteractionState(document: DrawingValueV2, options?: CreateEditorInteractionOptions): EditorInteractionState;
/** 设置下一次 selection gesture 所用的稳定 targets/descriptor；激活手势期间拒绝重配。 */
export declare function setEditorSelection(state: EditorInteractionState, targets: readonly DocumentStrokeTarget[], descriptor?: SelectionGestureDescriptor): EditorInteractionResult;
/** 设置下一次 gesture 的工具；现有 GestureSession 仍会对未实现工具产生安全 unsupported 状态。 */
export declare function setEditorInteractionTool(state: EditorInteractionState, tool: GestureSessionTool): EditorInteractionResult;
/** 直接设置经过既有 viewport 边界规范化的临时视口，不影响 document 或 history。 */
export declare function setEditorInteractionViewport(state: EditorInteractionState, viewport: DrawingViewport): EditorInteractionResult;
/**
 * 在交互边界提交离散 document 命令并同步 selection 生命周期。
 * `append-stroke` 是唯一不清空已验证 selection 的普通命令；其余真实写入全部失效。
 */
export declare function commitEditorInteractionCommand(state: EditorInteractionState, command: EditorDocumentCommand): EditorInteractionResult;
/**
 * 提交 trusted core producer 的完整 document snapshot（例如 text session）。完整 snapshot 无法
 * 证明只是 append，因此所有真实提交保守清空 selection；陈旧/no-op 保持原 interaction 引用。
 */
export declare function commitEditorInteractionDocument(state: EditorInteractionState, expectedRevision: number, document: DrawingValueV2): EditorInteractionResult;
/** 从当前 runtime document 创建并锁定一段 GestureSession。 */
export declare function beginEditorGesture(state: EditorInteractionState): EditorInteractionResult;
/**
 * 消费一个已规范化 pointer 输入。viewport preview 永远以 beginViewport 为基准，history 只由
 * GestureSession 的 document/selection 完成 effect 触发，cancel 与 navigation 不会写 document。
 */
export declare function reduceEditorGesture(state: EditorInteractionState, input: NormalizedPointerInput): EditorInteractionResult;
/** undo 与活动 session 不可混用，避免使用旧 begin revision 覆盖已经回退的 document。 */
export declare function undoEditorInteraction(state: EditorInteractionState): EditorInteractionResult;
/** redo 与活动 session 不可混用，避免使用旧 begin revision 覆盖重放后的 document。 */
export declare function redoEditorInteraction(state: EditorInteractionState): EditorInteractionResult;
//# sourceMappingURL=editorInteraction.d.ts.map