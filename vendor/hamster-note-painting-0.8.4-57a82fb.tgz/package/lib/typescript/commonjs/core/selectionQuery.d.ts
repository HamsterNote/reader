import { type GeometryPoint } from './geometry';
import type { DrawingFrameFragment } from './frameClipping';
import type { DrawingStrokeV2, DrawingValueV2 } from '../model/strokes';
/** 以文档索引而非 ID 定位目标，因此重复 ID 不会产生歧义。 */
export type DocumentStrokeTarget = Readonly<{
    index: number;
    stroke: DrawingStrokeV2;
}>;
/** 查询不会修改文档；无法安全解释的输入只以诊断报告并跳过。 */
export type SelectionQueryDiagnostic = Readonly<{
    type: 'invalid-lasso-polygon';
}> | Readonly<{
    type: 'invalid-eraser-samples';
}> | Readonly<{
    type: 'invalid-eraser-radius';
}> | Readonly<{
    type: 'unsupported-stroke-tool';
    index: number;
}> | Readonly<{
    type: 'unsupported-stroke-geometry';
    index: number;
}> | Readonly<{
    type: 'contour-capped';
    index: number;
}> | Readonly<{
    type: 'invalid-frame-query-revision';
}> | Readonly<{
    type: 'frame-revision-mismatch';
    frameRevision: number;
    expectedRevision: number;
}> | Readonly<{
    type: 'invalid-frame-query-coordinate-space';
}>;
export type DocumentStrokeTargetQuery = Readonly<{
    targets: readonly DocumentStrokeTarget[];
    diagnostics: readonly SelectionQueryDiagnostic[];
}>;
export type EraserTargetQueryOptions = Readonly<{
    /** true 时只返回最后一个命中的文档条目；缺省返回全部命中条目。 */
    topmostOnly?: boolean;
}>;
/** frame 查询只返回稳定文档定位信息，不将 prepared 的原始 stroke 重新暴露为几何输入。 */
export type DrawingFrameTarget = Readonly<{
    index: number;
    id: string;
    tool: DrawingStrokeV2['tool'];
}>;
export type DrawingFrameTargetQuery = Readonly<{
    targets: readonly DrawingFrameTarget[];
    diagnostics: readonly SelectionQueryDiagnostic[];
}>;
export type DrawingFrameQueryCoordinateSpace = 'world' | 'screen';
/**
 * frame 由 renderer 在某个 document revision 产出。调用者必须同时提供该 revision 与当前要
 * 消费的 revision；不相同的 frame 永远只产生空目标。坐标会一次映射到 frame local DIP，之后
 * 查询只读取 renderable entry 的 program/semantic region。
 */
export type DrawingFrameTargetQueryOptions = Readonly<{
    frameRevision: number;
    expectedRevision: number;
    coordinateSpace?: DrawingFrameQueryCoordinateSpace;
}>;
/**
 * 查询所需的 DrawingFrame 最小只读投影。故意不导入 drawingFrame，避免 selectionQuery 反向带入
 * viewport 实现；完整 `DrawingFrame` 在结构上满足此接口，且查询不会读取其余任何字段。
 */
export type DrawingFrameRenderableQueryInput = Readonly<{
    frameOrigin: GeometryPoint;
    localToScreen: Readonly<{
        a: number;
        b: number;
        c: number;
        d: number;
        tx: number;
        ty: number;
    }>;
    renderableEntries: readonly DrawingFrameRenderableQueryEntry[];
}>;
type DrawingFrameRenderableQueryEntry = Readonly<{
    source: Readonly<{
        key: number;
        stroke: DrawingStrokeV2;
    }>;
    status: 'unchanged' | 'rebased' | 'clipped' | 'segmented' | 'empty' | 'pending' | 'unresolved';
    fragments: readonly DrawingFrameFragment[];
    program: Readonly<{
        strokes: readonly Readonly<{
            points: readonly GeometryPoint[];
            closed: boolean;
        }>[];
        fills: readonly Readonly<{
            polygons: readonly Readonly<{
                outer: readonly GeometryPoint[];
                holes: readonly (readonly GeometryPoint[])[];
            }>[];
        }>[];
    }>;
}>;
/**
 * 查询与 world-DIP lasso 接触、被其包住或完整包住它的 V2 文档对象。
 *
 * 简单与复杂 lasso 都先由 polygonBoolean 规范化；如果某个曲线轮廓达到资源上限，返回其
 * bounds 相交的保守候选并报告 contour-capped，避免在选择阶段无声漏选。
 */
export declare function queryLassoStrokeTargets(document: DrawingValueV2, lassoPolygon: readonly GeometryPoint[]): DocumentStrokeTargetQuery;
/** 仅使用本帧 renderable geometry program 与资源/文字语义区域查询套索目标。 */
export declare function queryDrawingFrameLassoTargets(frame: DrawingFrameRenderableQueryInput, polygon: readonly GeometryPoint[], options: DrawingFrameTargetQueryOptions): DrawingFrameTargetQuery;
/** 仅使用本帧 renderable geometry program 与资源/文字语义区域查询连续橡皮轨迹。 */
export declare function queryDrawingFrameEraserTargets(frame: DrawingFrameRenderableQueryInput, samples: readonly GeometryPoint[], radius: number, options: DrawingFrameTargetQueryOptions & EraserTargetQueryOptions): DrawingFrameTargetQuery;
/**
 * 查询被 world-DIP 半径橡皮轨迹扫到的 V2 文档对象。轨迹按连续线段而非孤立采样点判定；
 * topmostOnly 为 true 时仅保留最后一个命中的文档条目，否则所有目标均按文档索引升序返回。
 */
export declare function queryEraserStrokeTargets(document: DrawingValueV2, samples: readonly GeometryPoint[], radius: number, options?: EraserTargetQueryOptions): DocumentStrokeTargetQuery;
export {};
//# sourceMappingURL=selectionQuery.d.ts.map