import { type DrawingGeometryDescriptor, type GeometryPoint } from './geometry';
import { type DrawingFrameFragment, type FrameGeometryProgram, type FrameClippingDiagnostic, type FrameFragmentStatus, type FrameLocalClipRegion, type FrameTextProgram, type FrameTextRequest } from './frameClipping';
import { type FrameDrawBudget } from './frameBudget';
import type { DrawingBounds, PreparedDrawingDocument, PreparedDrawingEntry } from './preparedDocument';
import { type AppendSpatialQueryIndexOptions, type SparseSpatialIndexOptions, type SpatialQueryIndex } from './spatialIndex';
import type { DrawingStrokeV2 } from '../model/strokes';
import { type Affine2D, type DrawingViewport } from '../viewport';
export declare const DEFAULT_CULL_GUARD_SCREEN_DIP = 1;
export declare const DEFAULT_MAX_LOCAL_COORDINATE = 1000000;
export type DrawingFrameDiagnostic = Readonly<{
    type: 'invalid-input' | 'prepared-index-mismatch' | 'non-finite-transform' | 'requires-clipping' | 'unresolved-clipping' | 'draw-budget-exceeded';
    field?: string;
    entryKey?: number;
    reason?: FrameClippingDiagnostic['reason'];
}>;
export type PreparedDrawingSpatialIndex = Readonly<{
    prepared: PreparedDrawingDocument;
    preparedRevision: number;
    /** 只读查询索引；可能是全量 sparse 或 append-only 组合索引，frame/hit 只调用 query/queryPoint。 */
    index: SpatialQueryIndex<PreparedDrawingEntry>;
}>;
export type DrawingFrameEntry = Readonly<{
    source: PreparedDrawingEntry;
    /**
     * 仅供审计和尚未迁移的旧适配器读取的完整 local descriptor，不可作为渲染或命中输入。
     * 对超出局部预算的 canonical geometry，此字段为 null，防止创建完整巨大 local geometry。
     */
    canonicalLocalGeometry: DrawingGeometryDescriptor | null;
    /**
     * @deprecated 仅为阶段 5 Skia adapter 的编译兼容保留，始终是安全局部 geometry 的单片段
     * 投影，不能表达 segmented/semantic 完整语义；新 renderer 必须只消费 `fragments`。
     */
    geometry: DrawingGeometryDescriptor;
    status: FrameFragmentStatus;
    fragments: readonly DrawingFrameFragment[];
    /** render 与 hit 共用的对象级 geometry program；复杂 fill 不能回退为多个 area fragment。 */
    program: FrameGeometryProgram;
    diagnostic?: FrameClippingDiagnostic;
}>;
export type DrawingFrame = Readonly<{
    prepared: PreparedDrawingDocument;
    spatialIndex: PreparedDrawingSpatialIndex;
    globalToScreen: Affine2D;
    localToScreen: Affine2D;
    frameOrigin: GeometryPoint;
    visibleWorldBounds: DrawingBounds;
    localClipRegion: FrameLocalClipRegion;
    /** 索引召回的完整可见候选，含 empty/unresolved，供审计。 */
    visibleEntries: readonly DrawingFrameEntry[];
    /** 只包含至少一个可安全消费 fragment 的条目；render 与 hit 必须使用本集合。 */
    renderableEntries: readonly DrawingFrameEntry[];
    /**
     * 兼容字段：表示本帧曾需要几何裁剪（成功或未解决均可），不表示失败，也不等价于
     * `hasUnresolvedClipping`。新调用方应分别读取 status 与 hasUnresolvedClipping。
     */
    requiresClipping: boolean;
    /** 未能在本轮安全表达的裁剪条目；它们绝不进入 renderable/hit。 */
    hasUnresolvedClipping: boolean;
    unresolvedClippingKeys: readonly number[];
    /** @deprecated 保留为历史审计名；其值为需要 fragment 裁剪或无法裁剪的 entry key。 */
    unsafeEntryKeys: readonly number[];
    maxLocalCoordinate: number;
    /** frame 与 Skia adapter 共用的最终数值输入预算。 */
    drawBudget: FrameDrawBudget;
    diagnostics: readonly DrawingFrameDiagnostic[];
}>;
export type CreateDrawingFrameOptions = Readonly<{
    prepared: PreparedDrawingDocument;
    spatialIndex: PreparedDrawingSpatialIndex;
    viewport: DrawingViewport;
    layoutSize: Readonly<{
        width: number;
        height: number;
    }>;
    cullGuardScreenDip?: number;
    maxLocalCoordinate?: number;
    /** 平台层可同步注入已缓存的纯文本 program；未准备的 partial text 明确保持不可渲染。 */
    resolveTextProgram?: (request: FrameTextRequest) => FrameTextProgram | null;
}>;
export type DrawingFrameHit = Readonly<{
    entry: DrawingFrameEntry;
    point: GeometryPoint;
}>;
export type CreateDrawingFrameResult = Readonly<{
    ok: true;
    frame: DrawingFrame;
}> | Readonly<{
    ok: false;
    diagnostics: readonly DrawingFrameDiagnostic[];
}>;
export declare function createPreparedDrawingSpatialIndex(prepared: PreparedDrawingDocument, options?: SparseSpatialIndexOptions): PreparedDrawingSpatialIndex;
/**
 * append-only 增量准备 + 索引：把一条新 stroke 追加到既有 prepared/index 快照。
 *
 * 不变量：
 * - 返回全新冻结的 PreparedDrawingSpatialIndex，previous（及其 index、既有 frame）保持不变。
 * - preparedRevision 与 prepared.revision 同步，满足 tryCreateDrawingFrame 的 identity/revision 校验。
 * - 几何无效的 stroke 只追加诊断：prepared revision 前进但索引复用 previous.index，frame 仍可正常构建。
 * - 索引用不可变组合实现追加；链深超过 maxDeltaDepth 时内部全量重建压平，语义不变。
 */
export declare function appendPreparedDrawingEntry(previous: PreparedDrawingSpatialIndex, stroke: DrawingStrokeV2, options?: AppendSpatialQueryIndexOptions): PreparedDrawingSpatialIndex;
/** 严格 frame 构建：只从 indexed canonical global geometry 生成单帧 transient fragments。 */
export declare function tryCreateDrawingFrame(options: CreateDrawingFrameOptions): CreateDrawingFrameResult;
export declare function createDrawingFrame(options: CreateDrawingFrameOptions): DrawingFrame | null;
/** 同一份 frame fragments 是唯一命中来源；canonical geometry 绝不可在这里 fallback 重建。 */
export declare function hitTestDrawingFrame(frame: DrawingFrame, screenPoint: GeometryPoint, toleranceScreenDip?: number): DrawingFrameHit | null;
//# sourceMappingURL=drawingFrame.d.ts.map