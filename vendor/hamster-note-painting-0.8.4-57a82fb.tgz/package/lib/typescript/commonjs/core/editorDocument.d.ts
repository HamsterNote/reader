import type { DrawingStrokeV2, DrawingValueV2 } from '../model/strokes';
import { type DocumentStrokeReplacement, type DocumentStrokeTarget, type SelectionTransformDiagnostic } from './selectionTransform';
import type { SelectionGestureIntent } from './gesture/session';
export type { DocumentStrokeReplacement, DocumentStrokeTarget } from './selectionTransform';
/** 编辑器运行期的文档版本；revision 不属于持久化 DrawingValueV2 schema。 */
export type EditorDocumentState = Readonly<{
    document: DrawingValueV2;
    revision: number;
}>;
export type EditorDocumentCommand = Readonly<{
    type: 'append-stroke';
    expectedRevision: number;
    stroke: DrawingStrokeV2;
}> | Readonly<{
    type: 'replace-strokes';
    expectedRevision: number;
    replacements: readonly DocumentStrokeReplacement[];
}> | Readonly<{
    type: 'remove-strokes';
    expectedRevision: number;
    targets: readonly DocumentStrokeTarget[];
}> | Readonly<{
    type: 'clear-strokes';
    expectedRevision: number;
}> | Readonly<{
    type: 'apply-selection-transform';
    expectedRevision: number;
    targets: readonly DocumentStrokeTarget[];
    intent: SelectionGestureIntent;
}>;
export type EditorDocumentDiagnostic = Readonly<{
    type: 'revision-mismatch';
    expectedRevision: number;
    actualRevision: number;
}> | Readonly<{
    type: 'document-target-mismatch';
    target: DocumentStrokeTarget;
}> | Readonly<{
    type: 'duplicate-document-target';
    index: number;
}> | SelectionTransformDiagnostic;
export type ApplyEditorDocumentCommandResult = Readonly<{
    state: EditorDocumentState;
    diagnostics: readonly EditorDocumentDiagnostic[];
}>;
/**
 * 未提交 selection 的唯一物化文档快照。它沿用正式命令的 revision、target 与重复目标规则，
 * 但不会写入 revision 或 history；renderer 应直接读取 `document`，不能自行应用 replacement。
 */
export type EditorDocumentPreview = Readonly<{
    document: DrawingValueV2;
    diagnostics: readonly EditorDocumentDiagnostic[];
}>;
/** 创建非持久编辑器状态，不复制 document，也不改变外部文档。 */
export declare function createEditorDocumentState(document: DrawingValueV2, revision?: number): EditorDocumentState;
/**
 * 原子执行单个 revision-aware 编辑命令。
 *
 * revision 或任一 target 不匹配时直接返回原 state 引用；成功命令仅在 document 真正变更时
 * 增加 revision。history、手势预览和持久化由上层负责。
 */
export declare function applyEditorDocumentCommand(state: EditorDocumentState, command: EditorDocumentCommand): ApplyEditorDocumentCommandResult;
/**
 * 在不提交的前提下物化一条 revision-aware 命令的结果。
 *
 * 此函数刻意复用 `applyEditorDocumentCommand`，以保证 preview 与最终提交对 stale revision、
 * duplicate target、replacement copy 及 no-op 的判断完全相同。任何拒绝或 no-op 都不产生 preview。
 */
export declare function materializeEditorDocumentPreview(state: EditorDocumentState, command: EditorDocumentCommand): EditorDocumentPreview | null;
//# sourceMappingURL=editorDocument.d.ts.map