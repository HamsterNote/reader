import { type DrawingPointV2, type DrawingValueV2 } from '../model/strokes';
/** 文本编辑期间可替换的草稿字段；字符串不做 trim、规范化或测量修正。 */
export type TextEditDraft = Readonly<{
    text: string;
    measuredHeight?: number;
    points?: readonly DrawingPointV2[];
    strokeColor?: string;
    strokeWidth?: number;
    dashArray?: readonly number[];
    dashOffset?: number;
    fillColor?: string;
    fillOpacity?: number;
    rotationRad?: number;
    fontSize?: number;
}>;
/** 编辑既有文本时锁定的有序目标，避免重复 ID 被错误命中。 */
export type ExistingTextEditTarget = Readonly<{
    index: number;
    expectedStrokeId: string;
    expectedTool: 'text';
}>;
/** 创建新文本笔迹所需的稳定 ID 与基础几何。 */
export type NewTextEditTarget = Readonly<{
    id: string;
    points: readonly DrawingPointV2[];
    fontSize: number;
}>;
export type TextEditSession = Readonly<{
    target: ExistingTextEditTarget | NewTextEditTarget;
    mode: 'existing' | 'new';
    draft: TextEditDraft;
    isComposing: boolean;
    commitRequested: boolean;
    status: 'editing' | 'committed' | 'cancelled';
}>;
export type TextEditSessionDiagnostic = Readonly<{
    type: 'commit-not-requested' | 'composition-active' | 'stale-target' | 'session-finalized';
}>;
/** 文本提交结果。草稿与 composing 转换不会产生此类 document 写入。 */
export type CommitTextEditSessionResult = Readonly<{
    document: DrawingValueV2;
    session: TextEditSession;
    diagnostics: readonly TextEditSessionDiagnostic[];
}>;
/** 从新笔迹目标开始纯文本编辑会话。 */
export declare function beginNewTextEditSession(target: NewTextEditTarget, draft: TextEditDraft): TextEditSession;
/** 从显式 index/ID/tool 三元组开始既有文本编辑会话。 */
export declare function beginExistingTextEditSession(target: ExistingTextEditTarget, draft: TextEditDraft): TextEditSession;
/** 替换草稿的给定字段。已结束会话不可重新打开。 */
export declare function updateTextEditDraft(session: TextEditSession, update: Partial<TextEditDraft>): TextEditSession;
/** 标记输入法 composition 开始；它不会写入 document。 */
export declare function startTextEditComposition(session: TextEditSession): TextEditSession;
/** 标记 composition 结束。已挂起的提交现在可由 commit 消费。 */
export declare function endTextEditComposition(session: TextEditSession): TextEditSession;
/** 请求一次提交；composition 期间仅挂起请求，绝不写入 document。 */
export declare function requestTextEditCommit(session: TextEditSession): TextEditSession;
/** 取消会话。它不接触 document，且已结束会话保持幂等。 */
export declare function cancelTextEditSession(session: TextEditSession): TextEditSession;
/**
 * 消费已请求且不在 composition 中的提交。
 *
 * 成功或空草稿都会结束会话，因而同一 session 最多造成一次写入。既有目标必须同时匹配
 * index、ID 与 tool；任一不匹配均返回 stale diagnostic 并严格保留 document 引用。
 */
export declare function commitTextEditSession(document: DrawingValueV2, session: TextEditSession): CommitTextEditSessionResult;
//# sourceMappingURL=textEditSession.d.ts.map