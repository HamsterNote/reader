import { type DrawingViewport } from '../viewport';
import type { Point } from '../model/document';
/** 用户可进一步收紧、但绝不能放宽全局 [0.25, 8] 缩放边界的限制。 */
export type ViewportScaleLimits = Readonly<{
    min?: number;
    max?: number;
}>;
/**
 * 一个完整的屏幕空间视口变换意图。
 *
 * `startFocal` 对应手势开始时的屏幕焦点，`currentFocal` 对应当前焦点；比例为 1 时即为
 * 平移。应用时会保持 startFocal 下的世界点位于 currentFocal，因而 pinch 焦点不会漂移。
 */
export type ViewportTransformIntent = Readonly<{
    startFocal: Point;
    currentFocal: Point;
    scaleRatio: number;
}>;
export type ResolvedViewportScaleLimits = Readonly<{
    min: number;
    max: number;
}>;
/**
 * 求全局边界与可选用户边界的交集。非有限值、倒置区间或空交集返回 null；调用者不应猜测
 * 回退值，避免无效外部配置静默改变视口。
 */
export declare function resolveViewportScaleLimits(limits?: ViewportScaleLimits): ResolvedViewportScaleLimits | null;
/** 严格检查并夹紧已有 viewport；无变化时返回原对象，非法输入返回 null。 */
export declare function normalizeViewportTransform(viewport: DrawingViewport, limits?: ViewportScaleLimits): DrawingViewport | null;
/** 创建不可变 transform intent；非有限点或非正比例返回 null。 */
export declare function createViewportTransformIntent(startFocal: Point, currentFocal: Point, scaleRatio?: number): ViewportTransformIntent | null;
/**
 * 将完整手势 intent 应用于 `DrawingViewport`。结果 scale 会先与全局/用户限制求交再夹紧；
 * 实际夹紧后的比例用于重新计算 tx/ty，保证焦点所指向的世界点仍落在 currentFocal。
 */
export declare function applyViewportTransformIntent(viewport: DrawingViewport, intent: ViewportTransformIntent, limits?: ViewportScaleLimits): DrawingViewport | null;
/** 在屏幕空间平移 viewport；零增量返回已验证的原对象。 */
export declare function panViewport(viewport: DrawingViewport, delta: Point, limits?: ViewportScaleLimits): DrawingViewport | null;
/** 在固定屏幕焦点处缩放；焦点位置在变换前后保持不变。 */
export declare function zoomViewportAt(viewport: DrawingViewport, focal: Point, scaleRatio: number, limits?: ViewportScaleLimits): DrawingViewport | null;
//# sourceMappingURL=viewportTransform.d.ts.map