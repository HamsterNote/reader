import { type DrawingPointV2, type DrawingStrokeToolV2, type DrawingStrokeV2, type DrawingToolModeV2 } from '../model/strokes';
/** 可复制到新 V2 笔迹的基础样式；不引入任何工具专属或额外持久字段。 */
export type EditorToolStrokeStyle = Readonly<{
    strokeColor?: string;
    strokeWidth?: number;
    dashArray?: readonly number[];
    dashOffset?: number;
    fillColor?: string;
    fillOpacity?: number;
    /** 仅当调用方显式提供时保留，rect/ellipse 不会自行创建 rotationRad。 */
    rotationRad?: number;
}>;
/** 稳定 ID 必须由宿主策略提供；core 永不使用随机数或时间戳生成可持久 ID。 */
export type EditorToolCreateId = (tool: DrawingStrokeToolV2) => string | null | undefined;
export type EditorToolSessionOptions = Readonly<{
    /** image 不是连续 DrawingToolModeV2，但仍须显式转交资源导入流程。 */
    tool: DrawingToolModeV2 | 'image';
    createId?: EditorToolCreateId;
    style?: EditorToolStrokeStyle;
}>;
export type EditorToolSessionDiagnostic = Readonly<{
    type: 'invalid-world-point';
}> | Readonly<{
    type: 'tool-session-finalized';
}> | Readonly<{
    type: 'tool-session-not-started';
}> | Readonly<{
    type: 'degenerate-tool-geometry';
    tool: DrawingStrokeToolV2;
}> | Readonly<{
    type: 'polygon-requires-three-vertices';
}> | Readonly<{
    type: 'polygon-degenerate';
}> | Readonly<{
    type: 'bezier-requires-four-controls';
    count: number;
}> | Readonly<{
    type: 'stable-id-required';
    tool: DrawingStrokeToolV2;
}> | Readonly<{
    type: 'requires-text-session';
}> | Readonly<{
    type: 'requires-resource-import';
}> | Readonly<{
    type: 'requires-query';
    tool: 'eraser' | 'lasso';
}>;
type ContinuousTool = 'pen' | 'line' | 'rect' | 'ellipse';
type VertexTool = 'polygon' | 'bezier';
export type EditorToolSession = Readonly<{
    kind: 'continuous';
    tool: ContinuousTool;
    style: EditorToolStrokeStyle;
    createId?: EditorToolCreateId;
    points: readonly DrawingPointV2[];
    status: 'idle' | 'active' | 'finished' | 'cancelled';
}> | Readonly<{
    kind: 'vertices';
    tool: VertexTool;
    style: EditorToolStrokeStyle;
    createId?: EditorToolCreateId;
    points: readonly DrawingPointV2[];
    status: 'idle' | 'active' | 'finished' | 'cancelled';
}> | Readonly<{
    kind: 'handoff';
    tool: 'text' | 'image' | 'eraser' | 'lasso';
    style: EditorToolStrokeStyle;
    createId?: EditorToolCreateId;
    points: readonly DrawingPointV2[];
    status: 'idle' | 'finished' | 'cancelled';
}>;
export type EditorToolSessionResult = Readonly<{
    session: EditorToolSession;
    /** 仅是候选值，调用方必须用 revision-aware EditorRuntime append 命令离散提交。 */
    stroke?: DrawingStrokeV2;
    preview: readonly DrawingPointV2[];
    diagnostics: readonly EditorToolSessionDiagnostic[];
}>;
/** 创建纯工具会话。它只构造候选笔迹，绝不写 document/history。 */
export declare function createEditorToolSession(options: EditorToolSessionOptions): EditorToolSessionResult;
/** 连续工具的 world-DIP down；polygon/bezier 请调用 addEditorToolVertex。 */
export declare function beginEditorToolPointer(session: EditorToolSession, point: DrawingPointV2): EditorToolSessionResult;
/** 连续工具的 world-DIP move；pen 去重相邻点，shape 始终保留稳定的首末点。 */
export declare function moveEditorToolPointer(session: EditorToolSession, point: DrawingPointV2): EditorToolSessionResult;
/** 连续工具的 up。只有有效非退化几何会带回候选 stroke。 */
export declare function finishEditorToolPointer(session: EditorToolSession, point: DrawingPointV2): EditorToolSessionResult;
/** 为 polygon/bezier 显式添加一个 world-DIP 顶点/控制点；不会自动添加闭合重复点。 */
export declare function addEditorToolVertex(session: EditorToolSession, point: DrawingPointV2): EditorToolSessionResult;
/** 显式结束 polygon；它必须有至少三个非共线顶点，且不自动闭合。 */
export declare function finishEditorPolygon(session: EditorToolSession): EditorToolSessionResult;
/** 显式结束 cubic Bézier；严格要求恰好四个控制点，不猜测或补造控制点。 */
export declare function finishEditorBezier(session: EditorToolSession): EditorToolSessionResult;
/** 取消任何未结束会话。取消从不产生候选 stroke。 */
export declare function cancelEditorToolSession(session: EditorToolSession): EditorToolSessionResult;
export {};
//# sourceMappingURL=editorToolSession.d.ts.map