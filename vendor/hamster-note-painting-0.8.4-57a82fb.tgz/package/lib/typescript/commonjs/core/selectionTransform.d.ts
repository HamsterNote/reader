import type { DrawingStrokeToolV2, DrawingStrokeV2, DrawingValueV2 } from '../model/strokes';
import type { SelectionGestureIntent } from './gesture/session';
/** 以索引、ID 与可选工具三元组定位文档中的单条笔迹，重复 ID 也不会歧义。 */
export type DocumentStrokeTarget = Readonly<{
    index: number;
    expectedId: string;
    expectedTool?: DrawingStrokeToolV2;
}>;
/** 原子替换集中的一项；调用方应在所有项有效后一次性提交。 */
export type DocumentStrokeReplacement = Readonly<{
    target: DocumentStrokeTarget;
    stroke: DrawingStrokeV2;
}>;
export type SelectionTransformDiagnostic = Readonly<{
    type: 'selection-target-mismatch';
    target: DocumentStrokeTarget;
}> | Readonly<{
    type: 'duplicate-selection-target';
    index: number;
}> | Readonly<{
    type: 'invalid-selection-intent';
}> | Readonly<{
    type: 'non-uniform-selection-scale';
    scale: Readonly<{
        x: number;
        y: number;
    }>;
}> | Readonly<{
    type: 'invalid-selection-scale';
    scale: number;
}> | Readonly<{
    type: 'invalid-selection-stroke';
    target: DocumentStrokeTarget;
}> | Readonly<{
    type: 'selection-transform-noop';
}>;
export type SelectionTransformResult = Readonly<{
    replacements: readonly DocumentStrokeReplacement[];
    diagnostics: readonly SelectionTransformDiagnostic[];
}>;
/**
 * 依据 selection intent 构造一次性替换集，不直接写 document。
 *
 * uniform-scale 是新的 scalar 语义。旧 resize 仅接受 uniform scale，保留其拒绝非均匀
 * 防线；两者都因统一缩放在任意选框局部坐标系和世界坐标系中等价，
 * 可以安全地围绕 intent 的固定 anchor 直接计算，不会产生 shear 或新的持久化表示。
 */
export declare function transformSelection(document: DrawingValueV2, targets: readonly DocumentStrokeTarget[], intent: SelectionGestureIntent): SelectionTransformResult;
//# sourceMappingURL=selectionTransform.d.ts.map