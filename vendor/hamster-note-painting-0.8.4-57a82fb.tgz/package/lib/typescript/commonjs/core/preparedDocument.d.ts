import type { DrawingGeometryDescriptor } from './geometry';
import { type ClosedRingKind, type PolygonBooleanMultiPolygon } from './polygonBoolean';
import type { DrawingStrokeV2, DrawingValueV2 } from '../model/strokes';
/** 世界 DIP 的保守轴对齐包围盒，采用半开区间供空间索引精确过滤。 */
export type DrawingBounds = Readonly<{
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
}>;
export type PreparedDrawingDiagnostic = Readonly<{
    type: 'invalid-geometry' | 'invalid-bounds';
    index: number;
}>;
/**
 * 已准备的条目只由 document 下标标识。stroke.id 可以重复，不能用作索引键。
 * `stroke` 是冻结的值副本，调用方之后修改原 document 不会改变该快照。
 */
export type PreparedDrawingEntry = Readonly<{
    key: number;
    order: number;
    stroke: DrawingStrokeV2;
    geometry: DrawingGeometryDescriptor;
    bounds: DrawingBounds;
    /** 闭合 path 的拓扑仅在 prepared 阶段分析，避免 frame 重复进行 O(n²) 自交检测。 */
    closedPath?: Readonly<{
        kind: ClosedRingKind;
        /** complex ring 的 nonzero canonical islands/holes；失败要留给 frame 报 clip-failed。 */
        canonicalFill?: PolygonBooleanMultiPolygon;
        canonicalizationFailed?: true;
    }>;
}>;
export type PreparedDrawingDocument = Readonly<{
    revision: number;
    /**
     * 已准备的源 document stroke 总数（含几何无效、未进入 entries 的条目）。
     * append 从这个计数推导下一条 stroke 的正确 document 下标；key/order 始终等于该下标，
     * 因此重复 id 也天然合法，绝不能用 entries.length 代替。
     */
    strokeCount: number;
    entries: readonly PreparedDrawingEntry[];
    diagnostics: readonly PreparedDrawingDiagnostic[];
}>;
/** 从已生成的 descriptor 得到语义 hull；绝不再次描述原始 stroke。 */
export declare function getPreparedGeometryBounds(geometry: DrawingGeometryDescriptor): DrawingBounds | null;
/**
 * 一次性准备 document。每一条 stroke 恰好调用一次 describeDrawingStrokeGeometry；
 * geometry 为 null 的条目不会进入 entries，但其 document 下标仍会记录在诊断中。
 */
export declare function prepareDrawingDocument(document: DrawingValueV2): PreparedDrawingDocument;
/**
 * append-only 增量准备：只处理新追加的一条 stroke，复用 previous 中既有的 frozen entry 引用。
 *
 * 不变量：
 * - previous 绝不被修改；返回的是带新 revision 的全新冻结 snapshot，旧 snapshot/index/frame 继续有效。
 * - 新条目 key/order 等于 previous.strokeCount（正确 document 下标），几何无效时只追加诊断、
 *   复用 previous.entries 引用，但 strokeCount 仍前进，保证后续下标正确。
 * - 输入 stroke 会被 copyStroke 深拷贝并冻结，调用方之后修改原 document 不会回写。
 */
export declare function appendPreparedDrawingStroke(previous: PreparedDrawingDocument, stroke: DrawingStrokeV2): PreparedDrawingDocument;
/** 与阶段设计术语一致的别名，保持主 API 语义为“准备 document”。 */
export declare const createPreparedDrawingDocument: typeof prepareDrawingDocument;
//# sourceMappingURL=preparedDocument.d.ts.map