import type { LayeredEditorController } from './layeredEditorController';
import { type DocumentObject, type Point } from '../model/document';
export type SelectionOperation = 'move' | 'resize' | 'rotate';
/** The same geometry-driven gesture path is used by DOM and future semantic batches. */
export declare function createLayeredToolSession(controller: LayeredEditorController, allocateId: () => string): {
    pointHits: (point: Point) => readonly Readonly<{
        objectId: string;
        objectRevision: number;
        transformRevision: number;
        kind: DocumentObject["kind"];
        order: number;
    }>[];
    begin(point: Point, operation?: SelectionOperation, extendSelection?: boolean, targetId?: string): boolean;
    update: (points: readonly Point[]) => void;
    hover(point: Point): void;
    isPlacing: () => boolean;
    completePolygon(doubleClick?: boolean): boolean;
    end(): void;
    cancel: () => void;
    destroy(): void;
};
//# sourceMappingURL=layeredToolSession.d.ts.map