export type RulerTicksProps = {
    readonly length: number;
    readonly height: number;
    readonly pixelsPerInch?: number;
    readonly originX?: number;
};
export declare function RulerTicks({ length, height, pixelsPerInch, originX }: RulerTicksProps): import("react").JSX.Element;
//# sourceMappingURL=RulerTicks.d.ts.map