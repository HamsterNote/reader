export declare const DEFAULT_RULER_PIXELS_PER_INCH = 96;
export type RulerTickKind = 'millimeter' | 'half-centimeter' | 'centimeter';
export type RulerTick = {
    readonly localX: number;
    readonly millimeter: number;
    readonly kind: RulerTickKind;
};
export type GenerateRulerTicksOptions = {
    readonly length: number;
    readonly pixelsPerInch?: number;
    readonly originX?: number;
};
export declare function millimetersToPixels(millimeters: number, pixelsPerInch?: number): number;
export declare function generateRulerTicks(options: GenerateRulerTicksOptions): readonly RulerTick[];
//# sourceMappingURL=ticks.d.ts.map