/**
 * Ruler 几何模块 — 纯数学，不依赖 React / DOM。
 *
 * 约定：
 * - 输入点与尺子必须位于同一坐标系；当前尺子使用宿主局部 CSS 像素
 * - 尺子按无限长条处理；`length` 只控制屏幕上用于覆盖视口的渲染长度
 */
/** 二维点，兼容 DrawingPoint 但不含 pressure */
export interface RulerPoint {
    readonly x: number;
    readonly y: number;
}
export interface RulerRect {
    /** ruler 中心位置；单位与命中点一致 */
    readonly center: RulerPoint;
    readonly length: number;
    /** ruler 高度（沿 y 轴方向，旋转前） */
    readonly height: number;
    /** 顺时针旋转弧度；省略时保持向后兼容并按 0 处理 */
    readonly rotationRad?: number;
}
export type RulerState = {
    readonly center: RulerPoint;
    readonly rotationRad: number;
};
export type RulerEdgeConstraint = {
    readonly ruler: RulerRect;
    readonly edgeNormal: -1 | 1;
    readonly phase: 'approaching' | 'constrained';
};
export type RulerEdgeConstraintResult = {
    readonly point: RulerPoint;
    readonly constraint: RulerEdgeConstraint;
};
export type InfiniteRulerLayout = {
    readonly visualCenter: RulerPoint;
    readonly renderLength: number;
    readonly tickOriginX: number;
};
export type InfiniteRulerLayoutOptions = {
    readonly logicalCenter: RulerPoint;
    readonly rotationRad: number;
    readonly height: number;
    readonly viewport: {
        readonly width: number;
        readonly height: number;
    };
};
export declare function snapRulerRotation(rotationRad: number): number;
/**
 * 判断同坐标系中的点是否在 ruler 矩形区域内。
 */
export declare function isInsideRuler(point: RulerPoint, ruler: RulerRect): boolean;
/**
 * 记录一次绘制手势所选择的物理尺边。尺边只在手势越过它后锁定，
 * 因而指针从尺子外侧接近时仍保持自然轨迹。
 */
export declare function createRulerEdgeConstraint(start: RulerPoint, ruler: RulerRect): RulerEdgeConstraint;
export declare function constrainPointToRulerEdge(point: RulerPoint, constraint: RulerEdgeConstraint): RulerEdgeConstraintResult;
export declare function projectPointToRulerEdge(point: RulerPoint, constraint: RulerEdgeConstraint): RulerPoint;
export declare function projectPointToRulerCenterline(point: RulerPoint, ruler: Pick<RulerRect, 'center' | 'rotationRad'>): RulerPoint;
export declare function getInfiniteRulerLayout(options: InfiniteRulerLayoutOptions): InfiniteRulerLayout;
export declare function rotateRulerAround(ruler: RulerState, pivot: RulerPoint, deltaRad: number): RulerState;
//# sourceMappingURL=geometry.d.ts.map