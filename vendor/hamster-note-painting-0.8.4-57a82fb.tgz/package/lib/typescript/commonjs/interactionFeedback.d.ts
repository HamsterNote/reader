export type InteractionFeedbackPoint = {
    readonly x: number;
    readonly y: number;
};
export declare const TOUCH_ZOOM_FEEDBACK_WIDTH = 64;
export declare const TOUCH_ZOOM_FEEDBACK_HEIGHT = 32;
export type InteractionFeedbackViewport = {
    readonly width: number;
    readonly height: number;
};
export declare function formatScalePercent(scale: number): string;
export declare function formatAngleDegrees(rotationRad: number): string;
export declare function getMouseZoomFeedbackPoint(pointer: InteractionFeedbackPoint): InteractionFeedbackPoint;
export declare function getTouchZoomFeedbackPoint(first: InteractionFeedbackPoint, second: InteractionFeedbackPoint, viewport: InteractionFeedbackViewport): InteractionFeedbackPoint;
//# sourceMappingURL=interactionFeedback.d.ts.map