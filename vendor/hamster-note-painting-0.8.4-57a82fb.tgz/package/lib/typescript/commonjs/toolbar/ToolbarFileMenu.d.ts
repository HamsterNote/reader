import type { PaneToolbarLayout, ToolbarFileNavigationProps } from './types';
export type ToolbarFileMenuProps = ToolbarFileNavigationProps & {
    layout?: PaneToolbarLayout;
    /** Close sibling tool panels before opening this menu. Outside focus/pointer closes it in reverse. */
    onOpen?: () => void;
};
/** Controlled file navigation: only a host snapshot may change the current file or list. */
export declare function ToolbarFileMenu({ files, currentFileKey, paneId, busy, onSelectFile, onRequestRemove, layout, onOpen, }: ToolbarFileMenuProps): import("react").JSX.Element | null;
//# sourceMappingURL=ToolbarFileMenu.d.ts.map