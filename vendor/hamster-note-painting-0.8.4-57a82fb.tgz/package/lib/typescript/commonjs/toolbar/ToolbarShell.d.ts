import { type HTMLAttributes, type ReactNode } from 'react';
import type { PaneToolbarLayout, ToolbarOccupiedSpace } from './types';
export type ToolbarShellProps = {
    children: ReactNode;
    auxiliary?: ReactNode;
    overlay?: ReactNode;
    collapsed?: boolean;
    placement?: 'inline' | 'floating';
    layout?: PaneToolbarLayout;
    label?: string;
    className?: string;
    toolbarProps?: HTMLAttributes<HTMLDivElement>;
    onOccupiedSpaceChange?: (space: ToolbarOccupiedSpace) => void;
};
/** DOM shell shared by content libraries; no editor, storage or routing dependencies. */
export declare const ToolbarShell: import("react").ForwardRefExoticComponent<ToolbarShellProps & import("react").RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=ToolbarShell.d.ts.map