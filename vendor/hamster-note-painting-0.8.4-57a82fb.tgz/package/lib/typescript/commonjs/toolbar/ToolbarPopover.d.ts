import type { PaneToolbarLayout } from './types';
import { type ReactNode, type RefObject } from 'react';
/** No backdrop: an outside pointer closes the panel without consuming the canvas event. */
export declare function ToolbarPopover({ id, label, menu, anchor, boundary, onClose, children, layout, className, }: {
    id: string;
    label: string;
    menu: boolean;
    anchor: RefObject<HTMLButtonElement | null>;
    boundary: RefObject<HTMLDivElement | null>;
    onClose: (restoreFocus: boolean) => void;
    children: ReactNode;
    layout?: PaneToolbarLayout;
    className?: string;
}): import("react").JSX.Element;
//# sourceMappingURL=ToolbarPopover.d.ts.map