import type { DrawingPointV2, DrawingStrokeToolV2, DrawingToolModeV2 } from '../model/strokes';
export type CanvasPoint = Pick<DrawingPointV2, 'x' | 'y'>;
export type InteractionTool = DrawingToolModeV2;
export type DragShapeTool = 'line' | 'rect' | 'ellipse';
export type BezierControlPoints = [
    start?: CanvasPoint,
    cp1?: CanvasPoint,
    cp2?: CanvasPoint,
    end?: CanvasPoint
];
export type CompletedInteractionStroke = {
    tool: DrawingStrokeToolV2;
    points: CanvasPoint[];
};
export type IdleInteractionState = {
    phase: 'idle';
    tool: InteractionTool;
    completedStroke?: CompletedInteractionStroke;
    shouldResetViewport?: true;
};
export type DrawingPenInteractionState = {
    phase: 'drawingPen';
    tool: 'pen';
    pointerId?: number;
    points: CanvasPoint[];
    cursorPoint: CanvasPoint;
    shiftHeld: boolean;
};
export type DrawingDragShapeInteractionState = {
    phase: 'drawingDragShape';
    tool: DragShapeTool;
    pointerId?: number;
    startPoint: CanvasPoint;
    cursorPoint: CanvasPoint;
    shiftHeld: boolean;
};
export type PlacingPolygonInteractionState = {
    phase: 'placingPolygon';
    tool: 'polygon';
    vertices: CanvasPoint[];
    cursorPoint?: CanvasPoint;
    shiftHeld: boolean;
};
export type PlacingLineInteractionState = {
    phase: 'placingLine';
    tool: 'line';
    vertices: CanvasPoint[];
    cursorPoint?: CanvasPoint;
    shiftHeld: boolean;
};
export type BezierCreationPhase = 'line' | 'control1' | 'control2';
export type PlacingBezierInteractionState = {
    phase: 'placingBezier';
    tool: 'bezier';
    creationPhase: BezierCreationPhase;
    points: BezierControlPoints;
    cursorPoint?: CanvasPoint;
    pointerId?: number;
    dragging: boolean;
    shiftHeld: boolean;
};
export type InteractionState = IdleInteractionState | DrawingPenInteractionState | DrawingDragShapeInteractionState | PlacingPolygonInteractionState | PlacingLineInteractionState | PlacingBezierInteractionState;
export type PointerDownInteractionAction = {
    type: 'POINTER_DOWN';
    point?: CanvasPoint;
    pointerId?: number;
    detail?: number;
    mode?: 'drag' | 'place';
};
export type PointerMoveInteractionAction = {
    type: 'POINTER_MOVE';
    point?: CanvasPoint;
    pointerId?: number;
};
export type PointerUpInteractionAction = {
    type: 'POINTER_UP';
    point?: CanvasPoint;
    pointerId?: number;
    detail?: number;
};
export type InteractionAction = PointerDownInteractionAction | PointerMoveInteractionAction | PointerUpInteractionAction | {
    type: 'POINTER_CANCEL';
    pointerId?: number;
} | {
    type: 'KEY_DOWN';
    key: string;
} | {
    type: 'TOOL_CHANGE';
    tool: InteractionTool;
} | {
    type: 'BLUR';
} | {
    type: 'RESET_REQUEST';
} | {
    type: 'SHIFT_CHANGE';
    held: boolean;
};
export declare function createInitialState(tool: InteractionTool): InteractionState;
export declare function isValidCompletion(state: InteractionState): boolean;
export declare function interactionReducer(state: InteractionState, action: InteractionAction): InteractionState;
//# sourceMappingURL=reducer.d.ts.map