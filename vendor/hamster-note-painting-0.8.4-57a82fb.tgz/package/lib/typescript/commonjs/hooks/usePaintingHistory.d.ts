import type { DrawingValue } from '../model/geometryTypes';
export type PaintingHistoryValues = Readonly<Record<string, DrawingValue>>;
export interface PaintingHistoryControls {
    readonly canUndo: boolean;
    readonly canRedo: boolean;
    readonly undo: () => void;
    readonly redo: () => void;
}
export interface PaintingHistory extends PaintingHistoryControls {
    readonly values: PaintingHistoryValues;
    readonly setValue: (boardId: string, value: DrawingValue) => void;
    readonly setValues: (values: PaintingHistoryValues) => void;
    readonly reset: (values: PaintingHistoryValues) => void;
    /** 开始把连续预览更新合并为一个可撤销操作。 */
    readonly beginTransaction: () => void;
    /** 结束当前连续更新事务。 */
    readonly endTransaction: () => void;
}
/** 创建可由一个或多个 PaintingBoard 共用的按操作排序历史栈。 */
export declare function usePaintingHistory(initialValues: PaintingHistoryValues): PaintingHistory;
//# sourceMappingURL=usePaintingHistory.d.ts.map